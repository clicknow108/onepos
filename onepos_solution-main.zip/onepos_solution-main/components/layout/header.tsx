'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronDown, Menu, X, ArrowRight } from 'lucide-react';
import { Logo } from './logo';
import { Navigation } from '@/content/site-config';
import { cn } from '@/lib/utils';

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openMega, setOpenMega] = useState<string | null>(null);
  const [openMobileSection, setOpenMobileSection] = useState<string | null>(null);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setOpenMega(null);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  const navItems: Array<{
    label: string;
    href: string;
    columns?: { title: string; items: { label: string; href: string; description?: string }[] }[];
    children?: { label: string; href: string }[];
  }> = [
    Navigation.products,
    Navigation.solutions,
    Navigation.pricing,
    Navigation.resources,
    Navigation.about,
  ];

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-300',
        scrolled
          ? 'border-b border-border bg-background/80 backdrop-blur-xl shadow-sm'
          : 'border-b border-transparent bg-background/50 backdrop-blur-sm'
      )}
    >
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Logo />

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => (
            <div
              key={item.label}
              className="relative"
              onMouseEnter={() => item.children && setOpenMega(item.label)}
              onMouseLeave={() => setOpenMega(null)}
            >
              {item.columns ? (
                <button
                  className="flex items-center gap-1 px-3.5 py-2 text-sm font-medium text-foreground/70 hover:text-foreground transition-colors"
                  onClick={() => setOpenMega(openMega === item.label ? null : item.label)}
                >
                  {item.label}
                  <ChevronDown className={cn('h-3.5 w-3.5 transition-transform', openMega === item.label && 'rotate-180')} />
                </button>
              ) : (
                <Link
                  href={item.href}
                  className="px-3.5 py-2 text-sm font-medium text-foreground/70 hover:text-foreground transition-colors"
                >
                  {item.label}
                </Link>
              )}

              {/* Mega menu */}
              {item.columns && openMega === item.label && (
                <div className="absolute left-1/2 top-full z-50 -translate-x-1/2 pt-3">
                  <div className="w-[720px] rounded-2xl border border-border bg-popover p-6 shadow-2xl shadow-foreground/5 animate-fade-in">
                    <div className="grid grid-cols-3 gap-x-6 gap-y-1">
                      {item.columns.map((col) => (
                        <div key={col.title}>
                          <p className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                            {col.title}
                          </p>
                          {col.items.map((sub) => (
                            <Link
                              key={sub.label + sub.href}
                              href={sub.href}
                              className="group flex flex-col rounded-lg px-3 py-2 hover:bg-secondary transition-colors"
                            >
                              <span className="text-sm font-medium text-foreground">{sub.label}</span>
                              {sub.description && (
                                <span className="text-xs text-muted-foreground">{sub.description}</span>
                              )}
                            </Link>
                          ))}
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 flex items-center justify-between rounded-xl bg-secondary/50 px-4 py-3">
                      <p className="text-sm text-muted-foreground">Khám phá toàn bộ hệ sinh thái OnePOS</p>
                      <Link
                        href="/san-pham"
                        className="flex items-center gap-1 text-sm font-semibold text-primary hover:gap-2 transition-all"
                      >
                        Xem tất cả <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                </div>
              )}

              {/* Simple dropdown */}
              {item.children && !item.columns && openMega === item.label && (
                <div className="absolute left-0 top-full z-50 pt-3">
                  <div className="w-56 rounded-xl border border-border bg-popover p-2 shadow-2xl shadow-foreground/5 animate-fade-in">
                    {item.children.map((sub) => (
                      <Link
                        key={sub.label + sub.href}
                        href={sub.href}
                        className="block rounded-lg px-3 py-2 text-sm font-medium text-foreground/80 hover:bg-secondary hover:text-foreground transition-colors"
                      >
                        {sub.label}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Desktop CTAs */}
        <div className="hidden lg:flex items-center gap-2">
          <Link
            href="/lien-he"
            className="px-4 py-2 text-sm font-semibold text-foreground/80 hover:text-foreground transition-colors"
          >
            Đăng ký tư vấn
          </Link>
          <Link
            href="/dung-thu"
            className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-primary/30 hover:bg-primary/90 transition-all"
          >
            Dùng thử miễn phí
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary transition-colors"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Mở menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-x-0 top-16 bottom-0 z-40 overflow-y-auto bg-background border-t border-border animate-fade-in">
          <div className="container-page py-6 space-y-1">
            {navItems.map((item) => (
              <div key={item.label} className="border-b border-border/50 py-1">
                {item.children || item.columns ? (
                  <>
                    <button
                      className="flex w-full items-center justify-between py-3 text-base font-semibold"
                      onClick={() =>
                        setOpenMobileSection(openMobileSection === item.label ? null : item.label)
                      }
                    >
                      {item.label}
                      <ChevronDown
                        className={cn(
                          'h-4 w-4 transition-transform',
                          openMobileSection === item.label && 'rotate-180'
                        )}
                      />
                    </button>
                    {openMobileSection === item.label && (
                      <div className="pb-3 pl-3 space-y-0.5">
                        {item.columns
                          ? item.columns.flatMap((col) =>
                              col.items.map((sub) => (
                                <Link
                                  key={col.title + sub.label + sub.href}
                                  href={sub.href}
                                  className="block py-2 text-sm text-foreground/70"
                                >
                                  {sub.label}
                                </Link>
                              ))
                            )
                          : item.children?.map((sub) => (
                              <Link
                                key={sub.label + sub.href}
                                href={sub.href}
                                className="block py-2 text-sm text-foreground/70"
                              >
                                {sub.label}
                              </Link>
                            ))}
                      </div>
                    )}
                  </>
                ) : (
                  <Link href={item.href} className="block py-3 text-base font-semibold">
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
            <div className="pt-6 space-y-3">
              <Link
                href="/dung-thu"
                className="block rounded-xl bg-primary px-4 py-3 text-center text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20"
              >
                Dùng thử miễn phí
              </Link>
              <Link
                href="/lien-he"
                className="block rounded-xl border border-border px-4 py-3 text-center text-sm font-semibold"
              >
                Đăng ký tư vấn
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
