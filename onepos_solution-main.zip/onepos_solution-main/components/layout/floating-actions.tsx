'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Phone, MessageCircle, Calendar, X } from 'lucide-react';
import { SiteConfig } from '@/content/site-config';
import { cn } from '@/lib/utils';

export function FloatingActions() {
  const [open, setOpen] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div
      className={cn(
        'fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 transition-all duration-300',
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
      )}
    >
      {open && (
        <div className="flex flex-col items-end gap-2 animate-fade-in">
          <Link
            href={`tel:${SiteConfig.contact.hotline}`}
            className="flex items-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-sm font-medium text-background shadow-lg"
          >
            <Phone className="h-4 w-4" /> Gọi ngay
          </Link>
          <Link
            href="/lien-he"
            className="flex items-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-sm font-medium text-background shadow-lg"
          >
            <Calendar className="h-4 w-4" /> Đăng ký demo
          </Link>
          <Link
            href="/dung-thu"
            className="flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-lg"
          >
            <MessageCircle className="h-4 w-4" /> Dùng thử miễn phí
          </Link>
        </div>
      )}
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          'flex h-14 w-14 items-center justify-center rounded-full shadow-xl transition-all duration-300',
          open ? 'bg-foreground text-background rotate-90' : 'bg-primary text-primary-foreground hover:scale-105'
        )}
        aria-label={open ? 'Đóng' : 'Mở hỗ trợ'}
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>
    </div>
  );
}
