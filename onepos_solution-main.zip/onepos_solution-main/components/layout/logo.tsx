import Link from 'next/link';
import { cn } from '@/lib/utils';

export function Logo({ className, showText = true }: { className?: string; showText?: boolean }) {
  return (
    <Link href="/" className={cn('flex items-center gap-2.5 group', className)} aria-label="OnePOS - Trang chủ">
      <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-sky-600 shadow-lg shadow-primary/20 transition-transform group-hover:scale-105">
        <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 12a8 8 0 0 1 16 0" />
          <path d="M8 12a4 4 0 0 1 8 0" />
          <circle cx="12" cy="12" r="1.2" fill="currentColor" />
        </svg>
      </div>
      {showText && (
        <span className="text-xl font-bold tracking-tight">
          One<span className="text-primary">POS</span>
        </span>
      )}
    </Link>
  );
}
