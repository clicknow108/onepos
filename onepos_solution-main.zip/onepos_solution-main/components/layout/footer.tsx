import Link from 'next/link';
import { Logo } from './logo';
import { SiteConfig } from '@/content/site-config';

const footerSections: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: 'Sản phẩm',
    links: [
      { label: 'Tổng đài Cloud', href: '/san-pham/tong-dai-cloud' },
      { label: 'Call Center', href: '/san-pham/call-center' },
      { label: 'Contact Center', href: '/san-pham/contact-center' },
      { label: 'Omnichannel', href: '/san-pham/omnichannel' },
      { label: 'CRM', href: '/san-pham/crm' },
      { label: 'Telesales', href: '/san-pham/telesales' },
      { label: 'Auto Call', href: '/san-pham/auto-call' },
      { label: 'AI Voice Agent', href: '/san-pham/ai-voice-agent' },
      { label: 'AI Chatbot', href: '/san-pham/ai-chatbot' },
    ],
  },
  {
    title: 'Viễn thông',
    links: [
      { label: 'Đầu số tổng đài', href: '/san-pham/sip-trunk' },
      { label: 'SIP Trunk', href: '/san-pham/sip-trunk' },
      { label: 'SMS Brandname', href: '/san-pham/sms-brandname' },
      { label: 'Zalo ZNS', href: '/san-pham/zalo-zns' },
      { label: 'Voice Brandname', href: '/san-pham/sip-trunk' },
    ],
  },
  {
    title: 'Giải pháp',
    links: [
      { label: 'Bán lẻ', href: '/giai-phap/ban-le' },
      { label: 'E-commerce', href: '/giai-phap/ecommerce' },
      { label: 'Bất động sản', href: '/giai-phap/bat-dong-san' },
      { label: 'Giáo dục', href: '/giai-phap/giao-duc' },
      { label: 'Y tế', href: '/giai-phap/y-te' },
      { label: 'F&B', href: '/giai-phap/fnb' },
      { label: 'Logistics', href: '/giai-phap/logistics' },
    ],
  },
  {
    title: 'Tài nguyên',
    links: [
      { label: 'Blog', href: '/blog' },
      { label: 'Case Study', href: '/case-study' },
      { label: 'Hướng dẫn', href: '/blog' },
      { label: 'Tài liệu API', href: '/developers' },
    ],
  },
  {
    title: 'Công ty',
    links: [
      { label: 'Giới thiệu', href: '/ve-onepos' },
      { label: 'Liên hệ', href: '/lien-he' },
      { label: 'Đối tác', href: '/ve-onepos#doi-tac' },
      { label: 'Tuyển dụng', href: '/ve-onepos#tuyen-dung' },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-navy-950 text-navy-100">
      <div className="container-page py-16">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-3 lg:grid-cols-6">
          <div className="col-span-2 lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-sky-600">
                <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 12a8 8 0 0 1 16 0" />
                  <path d="M8 12a4 4 0 0 1 8 0" />
                  <circle cx="12" cy="12" r="1.2" fill="currentColor" />
                </svg>
              </div>
              <span className="text-xl font-bold text-white">One<span className="text-sky-400">POS</span></span>
            </div>
            <p className="text-sm text-navy-300 max-w-xs leading-relaxed">
              {SiteConfig.tagline}. Hợp nhất Tổng đài, Call Center, CRM, Omnichannel và AI trên một nền tảng.
            </p>
            <div className="mt-6 space-y-2 text-sm text-navy-300">
              <p>Hotline: <span className="text-white font-medium">{SiteConfig.contact.hotline}</span></p>
              <p>Email: <span className="text-white font-medium">{SiteConfig.contact.email}</span></p>
              <p>{SiteConfig.contact.address}</p>
              <p>Hỗ trợ: {SiteConfig.contact.supportHours}</p>
            </div>
          </div>

          {footerSections.map((section) => (
            <div key={section.title}>
              <h3 className="mb-4 text-sm font-semibold text-white">{section.title}</h3>
              <ul className="space-y-2.5">
                {section.links.map((link) => (
                  <li key={link.label + link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-navy-300 hover:text-sky-400 transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-navy-800 pt-8 md:flex-row">
          <p className="text-sm text-navy-400">
            © {new Date().getFullYear()} {SiteConfig.name}. Bản quyền đã được bảo hộ.
          </p>
          <div className="flex items-center gap-6 text-sm text-navy-400">
            <Link href="/chinh-sach-bao-mat" className="hover:text-sky-400 transition-colors">Chính sách bảo mật</Link>
            <Link href="/dieu-khoan-su-dung" className="hover:text-sky-400 transition-colors">Điều khoản sử dụng</Link>
            <Link href="/chinh-sach-cookie" className="hover:text-sky-400 transition-colors">Chính sách cookie</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
