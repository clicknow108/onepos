'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle2 } from 'lucide-react';

export function ContactForm() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-50">
          <CheckCircle2 className="h-8 w-8 text-green-500" />
        </div>
        <h3 className="mt-4 text-lg font-bold text-foreground">Đã gửi thành công</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Cảm ơn bạn đã liên hệ. Đội ngũ OnePOS sẽ liên hệ trong thời gian sớm nhất.
        </p>
        <Button onClick={() => setSubmitted(false)} variant="outline" className="mt-6">
          Gửi lại
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-6 space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="name">Họ tên *</Label>
          <Input id="name" name="name" required placeholder="Nguyễn Văn A" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="company">Công ty</Label>
          <Input id="company" name="company" placeholder="Tên công ty" />
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="phone">Số điện thoại *</Label>
          <Input id="phone" name="phone" required placeholder="0901 234 567" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" required placeholder="email@congty.vn" />
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="scale">Quy mô nhân sự</Label>
          <Select>
            <SelectTrigger id="scale"><SelectValue placeholder="Chọn quy mô" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="1-10">1-10 người</SelectItem>
              <SelectItem value="11-50">11-50 người</SelectItem>
              <SelectItem value="51-200">51-200 người</SelectItem>
              <SelectItem value="200+">200+ người</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="product">Sản phẩm quan tâm</Label>
          <Select>
            <SelectTrigger id="product"><SelectValue placeholder="Chọn sản phẩm" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="tong-dai-cloud">Tổng đài Cloud</SelectItem>
              <SelectItem value="call-center">Call Center</SelectItem>
              <SelectItem value="contact-center">Contact Center</SelectItem>
              <SelectItem value="omnichannel">Omnichannel</SelectItem>
              <SelectItem value="crm">CRM</SelectItem>
              <SelectItem value="telesales">Telesales</SelectItem>
              <SelectItem value="ai-voice-agent">AI Voice Agent</SelectItem>
              <SelectItem value="ai-chatbot">AI Chatbot</SelectItem>
              <SelectItem value="auto-call">Auto Call</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="message">Nội dung</Label>
        <Textarea id="message" name="message" placeholder="Mô tả nhu cầu của bạn..." rows={4} />
      </div>
      <Button type="submit" className="w-full" size="lg">
        Đăng ký tư vấn
      </Button>
      <p className="text-center text-xs text-muted-foreground">
        Bằng việc gửi form, bạn đồng ý với chính sách bảo mật của OnePOS.
      </p>
    </form>
  );
}
