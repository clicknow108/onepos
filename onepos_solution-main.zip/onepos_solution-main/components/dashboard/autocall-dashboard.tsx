import { PhoneOutgoing, Users, CheckCircle2, PhoneMissed, Clock, BarChart3, ArrowRight } from 'lucide-react';

export function AutoCallDashboard() {
  const stats = [
    { label: 'Tổng cuộc gọi', value: '1,250', icon: PhoneOutgoing, color: 'text-sky-500' },
    { label: 'Bắt máy', value: '842', icon: CheckCircle2, color: 'text-green-500' },
    { label: 'Không liên lạc', value: '408', icon: PhoneMissed, color: 'text-red-500' },
    { label: 'Tỷ lệ bắt máy', value: '67%', icon: BarChart3, color: 'text-accent' },
  ];

  const flow = ['Danh sách KH', 'Campaign', 'Call Queue', 'Auto Dial', 'AI / Agent', 'Recording', 'Report'];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Auto Call Campaign</h3>
          <p className="text-xs text-muted-foreground">Chiến dịch gọi tự động</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-sky-50 px-2.5 py-1 text-xs font-medium text-sky-600">
          <Clock className="h-3 w-3" /> Đang chạy
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-secondary/30 p-3">
            <s.icon className={`h-4 w-4 ${s.color}`} />
            <p className="mt-2 text-xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-xl border border-border bg-secondary/30 p-4">
        <p className="mb-3 text-xs font-semibold text-foreground">Luồng chiến dịch</p>
        <div className="flex flex-wrap items-center gap-1">
          {flow.map((step, i) => (
            <div key={step} className="flex items-center gap-1">
              <span className="rounded-lg bg-background border border-border px-2.5 py-1.5 text-xs font-medium text-foreground">
                {step}
              </span>
              {i < flow.length - 1 && <ArrowRight className="h-3 w-3 text-muted-foreground" />}
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold text-foreground">Tiến độ realtime</p>
        <div className="flex items-center gap-3 rounded-xl border border-border bg-secondary/30 p-3">
          <div className="flex-1">
            <div className="h-2 rounded-full bg-secondary overflow-hidden">
              <div className="h-full rounded-full bg-gradient-to-r from-primary to-sky-400" style={{ width: '67%' }} />
            </div>
          </div>
          <span className="text-xs font-semibold text-foreground">67%</span>
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2 text-center">
          <div className="rounded-lg border border-border bg-secondary/20 p-2">
            <p className="text-sm font-bold text-green-500">842</p>
            <p className="text-[10px] text-muted-foreground">Thành công</p>
          </div>
          <div className="rounded-lg border border-border bg-secondary/20 p-2">
            <p className="text-sm font-bold text-amber-500">128</p>
            <p className="text-[10px] text-muted-foreground">Đang gọi</p>
          </div>
          <div className="rounded-lg border border-border bg-secondary/20 p-2">
            <p className="text-sm font-bold text-muted-foreground">280</p>
            <p className="text-[10px] text-muted-foreground">Còn lại</p>
          </div>
        </div>
      </div>
    </div>
  );
}
