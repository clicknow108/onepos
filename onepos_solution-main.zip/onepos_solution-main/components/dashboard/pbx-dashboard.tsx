import { Phone, PhoneIncoming, PhoneOutgoing, PhoneMissed, Users, Activity, Clock, Voicemail } from 'lucide-react';

export function PBXDashboard() {
  const stats = [
    { label: 'Cuộc gọi hoạt động', value: '12', icon: Phone, color: 'text-green-500' },
    { label: 'Máy lẻ online', value: '24/30', icon: Users, color: 'text-sky-500' },
    { label: 'Hàng đợi', value: '3', icon: Activity, color: 'text-amber-500' },
    { label: 'Voicemail', value: '5', icon: Voicemail, color: 'text-purple-500' },
  ];

  const calls = [
    { number: '0901 234 567', name: 'Nguyễn Văn A', type: 'in', duration: '3:24', status: 'active' },
    { number: '0902 345 678', name: 'Trần Thị B', type: 'out', duration: '1:52', status: 'active' },
    { number: '0903 456 789', name: 'Le Văn C', type: 'in', duration: '5:10', status: 'active' },
    { number: '0904 567 890', name: 'Phạm Thị D', type: 'missed', duration: '0:00', status: 'missed' },
    { number: '0905 678 901', name: 'Hoàng Văn E', type: 'out', duration: '2:45', status: 'done' },
  ];

  const volume = [40, 55, 68, 72, 85, 92, 78, 65, 58, 70, 82, 88];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Tổng đài Cloud PBX</h3>
          <p className="text-xs text-muted-foreground">Dashboard realtime</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">
          <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" /> Online
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-secondary/30 p-3">
            <s.icon className={`h-4 w-4 ${s.color}`} />
            <p className="mt-2 text-xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-xl border border-border bg-secondary/30 p-4">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-xs font-semibold text-foreground">Lưu lượng cuộc gọi</p>
          <span className="text-xs text-muted-foreground">24 giờ qua</span>
        </div>
        <div className="flex h-20 items-end gap-1">
          {volume.map((v, i) => (
            <div
              key={i}
              className="flex-1 rounded-t bg-gradient-to-t from-primary/40 to-primary"
              style={{ height: `${v}%` }}
            />
          ))}
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold text-foreground">Cuộc gọi gần đây</p>
        <div className="space-y-1.5">
          {calls.map((c, i) => (
            <div key={i} className="flex items-center gap-3 rounded-lg border border-border bg-secondary/20 px-3 py-2">
              {c.type === 'in' && <PhoneIncoming className="h-3.5 w-3.5 text-green-500" />}
              {c.type === 'out' && <PhoneOutgoing className="h-3.5 w-3.5 text-sky-500" />}
              {c.type === 'missed' && <PhoneMissed className="h-3.5 w-3.5 text-red-500" />}
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                <p className="text-xs text-muted-foreground">{c.number}</p>
              </div>
              <span className={`text-xs ${c.status === 'active' ? 'text-green-600 font-medium' : 'text-muted-foreground'}`}>
                {c.duration}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
