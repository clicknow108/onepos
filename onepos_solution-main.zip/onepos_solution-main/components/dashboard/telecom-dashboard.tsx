import { Network, Phone, MessageSquare, Send, Server, Activity } from 'lucide-react';

export function TelecomDashboard() {
  const services = [
    { name: 'Đầu số 1900', number: '1900 1234', status: 'active', icon: Phone },
    { name: 'SIP Trunk', number: '50 kênh', status: 'active', icon: Network },
    { name: 'SMS Brandname', number: 'ONEPOS', status: 'active', icon: MessageSquare },
    { name: 'Zalo ZNS', number: 'OA OnePOS', status: 'active', icon: Send },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Server className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-foreground">Viễn thông</h3>
            <p className="text-xs text-muted-foreground">Hạ tầng liên lạc</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">
          <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" /> Hoạt động
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {services.map((s) => (
          <div key={s.name} className="rounded-xl border border-border bg-secondary/30 p-3">
            <div className="flex items-center justify-between">
              <s.icon className="h-4 w-4 text-primary" />
              <span className="h-1.5 w-1.5 rounded-full bg-green-500" />
            </div>
            <p className="mt-2 text-sm font-bold text-foreground">{s.number}</p>
            <p className="text-xs text-muted-foreground">{s.name}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-xl border border-border bg-secondary/30 p-4">
        <p className="mb-3 text-xs font-semibold text-foreground">Lưu lượng kênh SIP</p>
        <div className="flex h-16 items-end gap-1">
          {[30, 45, 60, 75, 85, 90, 70, 55, 65, 80, 88, 72, 60, 50, 65, 78].map((v, i) => (
            <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-primary/30 to-primary" style={{ height: `${v}%` }} />
          ))}
        </div>
        <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
          <span>50 kênh</span>
          <span className="flex items-center gap-1"><Activity className="h-3 w-3" /> 38/50 đang dùng</span>
        </div>
      </div>
    </div>
  );
}
