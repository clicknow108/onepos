import { Headphones, Users, Clock, TrendingUp, PhoneCall, PhoneMissed } from 'lucide-react';

export function CallCenterDashboard() {
  const stats = [
    { label: 'Agent online', value: '18/20', icon: Users, color: 'text-green-500', bg: 'bg-green-50' },
    { label: 'Cuộc gọi chờ', value: '4', icon: Clock, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Tỷ lệ trả lời', value: '96%', icon: TrendingUp, color: 'text-sky-500', bg: 'bg-sky-50' },
    { label: 'Bỏ cuộc gọi', value: '2', icon: PhoneMissed, color: 'text-red-500', bg: 'bg-red-50' },
  ];

  const agents = [
    { name: 'Agent 01', status: 'busy', call: '3:24', avatar: 'A1' },
    { name: 'Agent 02', status: 'available', call: '—', avatar: 'A2' },
    { name: 'Agent 03', status: 'busy', call: '1:52', avatar: 'A3' },
    { name: 'Agent 04', status: 'break', call: '—', avatar: 'A4' },
    { name: 'Agent 05', status: 'busy', call: '5:10', avatar: 'A5' },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Headphones className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-foreground">Call Center Wallboard</h3>
            <p className="text-xs text-muted-foreground">Giám sát realtime</p>
          </div>
        </div>
        <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">SLA 96%</span>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border p-3">
            <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${s.bg}`}>
              <s.icon className={`h-3.5 w-3.5 ${s.color}`} />
            </div>
            <p className="mt-2 text-xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <p className="mb-2 text-xs font-semibold text-foreground">Thời gian đàm thoại TB</p>
          <p className="text-2xl font-bold text-primary">3:42</p>
          <div className="mt-2 flex gap-0.5">
            {[60, 75, 50, 85, 70, 90, 65, 80, 72, 88].map((h, i) => (
              <div key={i} className="flex-1 rounded-sm bg-primary/30" style={{ height: `${h * 0.3}px` }} />
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <p className="mb-2 text-xs font-semibold text-foreground">Cuộc gọi / giờ</p>
          <p className="text-2xl font-bold text-accent">142</p>
          <div className="mt-2 flex gap-0.5">
            {[40, 55, 68, 72, 85, 92, 78, 65, 70, 88].map((h, i) => (
              <div key={i} className="flex-1 rounded-sm bg-accent/30" style={{ height: `${h * 0.3}px` }} />
            ))}
          </div>
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold text-foreground">Trạng thái Agent</p>
        <div className="space-y-1.5">
          {agents.map((a) => (
            <div key={a.name} className="flex items-center gap-3 rounded-lg border border-border bg-secondary/20 px-3 py-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                {a.avatar}
              </div>
              <span className="flex-1 text-xs font-medium text-foreground">{a.name}</span>
              {a.status === 'busy' && (
                <span className="flex items-center gap-1 text-xs text-green-600">
                  <PhoneCall className="h-3 w-3" /> {a.call}
                </span>
              )}
              {a.status === 'available' && (
                <span className="flex items-center gap-1 text-xs text-sky-600">
                  <span className="h-1.5 w-1.5 rounded-full bg-sky-500" /> Sẵn sàng
                </span>
              )}
              {a.status === 'break' && (
                <span className="flex items-center gap-1 text-xs text-amber-600">
                  <span className="h-1.5 w-1.5 rounded-full bg-amber-500" /> Nghỉ
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
