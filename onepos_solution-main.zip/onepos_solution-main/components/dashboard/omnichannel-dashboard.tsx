import { Facebook, MessageCircle, Mail, Globe, Send, Paperclip, Smile } from 'lucide-react';

export function OmnichannelDashboard() {
  const channels = [
    { name: 'Facebook', icon: Facebook, count: 12, color: 'text-blue-600', bg: 'bg-blue-50' },
    { name: 'Zalo', icon: MessageCircle, count: 8, color: 'text-sky-600', bg: 'bg-sky-50' },
    { name: 'Live Chat', icon: Globe, count: 5, color: 'text-green-600', bg: 'bg-green-50' },
    { name: 'Email', icon: Mail, count: 3, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  const conversations = [
    { name: 'Nguyễn Văn A', channel: 'Facebook', msg: 'Cho tôi hỏi giá gói Call Center', time: '2 phút', unread: true },
    { name: 'Trần Thị B', channel: 'Zalo', msg: 'Cảm ơn bạn đã tư vấn', time: '15 phút', unread: true },
    { name: 'Le Văn C', channel: 'Live Chat', msg: 'Tôi cần hỗ trợ kỹ thuật', time: '1 giờ', unread: false },
    { name: 'Phạm Thị D', channel: 'Email', msg: 'Gửi báo giá chi tiết', time: '3 giờ', unread: false },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Omnichannel Inbox</h3>
          <p className="text-xs text-muted-foreground">Hợp nhất mọi kênh</p>
        </div>
        <span className="rounded-full bg-accent/10 px-2.5 py-1 text-xs font-medium text-accent">28 tin chờ</span>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {channels.map((c) => (
          <div key={c.name} className="rounded-lg border border-border bg-secondary/30 p-2.5 text-center">
            <div className={`mx-auto flex h-7 w-7 items-center justify-center rounded-lg ${c.bg}`}>
              <c.icon className={`h-3.5 w-3.5 ${c.color}`} />
            </div>
            <p className="mt-1.5 text-sm font-bold text-foreground">{c.count}</p>
            <p className="text-[10px] text-muted-foreground">{c.name}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        {/* Conversation list */}
        <div className="sm:col-span-1 space-y-1.5">
          <p className="mb-1 text-xs font-semibold text-foreground">Hội thoại</p>
          {conversations.map((c, i) => (
            <div key={i} className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 ${c.unread ? 'border-primary/30 bg-primary/5' : 'border-border bg-secondary/20'}`}>
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-xs font-semibold text-foreground">
                {c.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                <p className="text-[10px] text-muted-foreground truncate">{c.msg}</p>
              </div>
              {c.unread && <span className="h-1.5 w-1.5 rounded-full bg-primary" />}
            </div>
          ))}
        </div>

        {/* Chat window */}
        <div className="sm:col-span-2 rounded-xl border border-border bg-secondary/20 p-3">
          <div className="mb-3 flex items-center gap-2 border-b border-border pb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">N</div>
            <div>
              <p className="text-xs font-semibold text-foreground">Nguyễn Văn A</p>
              <p className="text-[10px] text-muted-foreground">Facebook Messenger</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="max-w-[80%] rounded-lg rounded-tl-sm bg-secondary px-3 py-2 text-xs text-foreground">
              Xin chào, cho tôi hỏi giá gói Call Center
            </div>
            <div className="ml-auto max-w-[80%] rounded-lg rounded-tr-sm bg-primary px-3 py-2 text-xs text-primary-foreground">
              Chào bạn! OnePOS Call Center có 3 gói. Bạn vui lòng cho biết quy mô đội ngũ?
            </div>
            <div className="max-w-[80%] rounded-lg rounded-tl-sm bg-secondary px-3 py-2 text-xs text-foreground">
              Đội ngũ khoảng 20 agent
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2">
            <Paperclip className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="flex-1 text-xs text-muted-foreground">Nhập tin nhắn...</span>
            <Smile className="h-3.5 w-3.5 text-muted-foreground" />
            <Send className="h-3.5 w-3.5 text-primary" />
          </div>
        </div>
      </div>
    </div>
  );
}
