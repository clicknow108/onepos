import { Bot, AudioLines, FileText, Smile, Frown, Meh, CheckCircle2, AlertCircle } from 'lucide-react';

export function AIDashboard() {
  const transcript = [
    { speaker: 'AI', text: 'Xin chào, tôi là trợ lý AI của OnePOS. Tôi có thể giúp gì cho bạn?', time: '00:01' },
    { speaker: 'KH', text: 'Cho tôi hỏi giá gói Call Center', time: '00:04' },
    { speaker: 'AI', text: 'OnePOS Call Center có 3 gói: Starter, Pro và Enterprise. Quy mô đội ngũ của bạn khoảng bao nhiêu agent?', time: '00:08' },
    { speaker: 'KH', text: 'Khoảng 20 người', time: '00:12' },
    { speaker: 'AI', text: 'Với 20 agent, gói Pro sẽ phù hợp nhất. Bạn muốn tôi gửi chi tiết qua email không?', time: '00:15' },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Bot className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-foreground">AI Call Analysis</h3>
            <p className="text-xs text-muted-foreground">Phân tích cuộc gọi</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">
          <AudioLines className="h-3 w-3" /> 3:24
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <Smile className="h-4 w-4 text-green-500" />
          <p className="mt-2 text-lg font-bold text-foreground">Tích cực</p>
          <p className="text-xs text-muted-foreground">Cảm xúc</p>
        </div>
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <FileText className="h-4 w-4 text-sky-500" />
          <p className="mt-2 text-lg font-bold text-foreground">92%</p>
          <p className="text-xs text-muted-foreground">Độ chính xác</p>
        </div>
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <CheckCircle2 className="h-4 w-4 text-green-500" />
          <p className="mt-2 text-lg font-bold text-foreground">85/100</p>
          <p className="text-xs text-muted-foreground">Điểm chất lượng</p>
        </div>
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <AlertCircle className="h-4 w-4 text-amber-500" />
          <p className="mt-2 text-lg font-bold text-foreground">2</p>
          <p className="text-xs text-muted-foreground">Cảnh báo</p>
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-border bg-secondary/30 p-4">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-xs font-semibold text-foreground">Chuyển đổi giọng nói → văn bản</p>
          <span className="text-xs text-muted-foreground">Tiếng Việt</span>
        </div>
        <div className="space-y-2">
          {transcript.map((t, i) => (
            <div key={i} className="flex gap-2">
              <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold ${t.speaker === 'AI' ? 'bg-primary/10 text-primary' : 'bg-secondary text-foreground'}`}>
                {t.speaker === 'AI' ? 'AI' : 'KH'}
              </span>
              <div className="flex-1">
                <p className="text-xs text-foreground">{t.text}</p>
                <span className="text-[10px] text-muted-foreground">{t.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <p className="mb-2 text-xs font-semibold text-foreground">Tóm tắt cuộc gọi</p>
          <p className="text-xs text-foreground/80 leading-relaxed">
            Khách hàng hỏi về giá gói Call Center cho đội ngũ 20 agent. AI tư vấn gói Pro và đề xuất gửi chi tiết qua email.
          </p>
        </div>
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <p className="mb-2 text-xs font-semibold text-foreground">Từ khóa phát hiện</p>
          <div className="flex flex-wrap gap-1.5">
            {['Call Center', 'Giá', '20 agent', 'Gói Pro', 'Email'].map((kw) => (
              <span key={kw} className="rounded-md bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                {kw}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
