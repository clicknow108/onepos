import { Users, TrendingUp, DollarSign, Target, Phone, Mail, MessageSquare, FileText } from 'lucide-react';

export function CRMDashboard() {
  const stats = [
    { label: 'Khách hàng', value: '1,284', icon: Users, color: 'text-sky-500' },
    { label: 'Lead mới', value: '86', icon: Target, color: 'text-amber-500' },
    { label: 'Deal đang mở', value: '32', icon: DollarSign, color: 'text-green-500' },
    { label: 'Tỷ lệ chốt', value: '24%', icon: TrendingUp, color: 'text-purple-500' },
  ];

  const pipeline = [
    { stage: 'Tiếp xúc', count: 120, value: '₫480M', color: 'bg-sky-400' },
    { stage: 'Tư vấn', count: 64, value: '₫320M', color: 'bg-sky-500' },
    { stage: 'Báo giá', count: 32, value: '₫180M', color: 'bg-primary' },
    { stage: 'Đàm phán', count: 18, value: '₫120M', color: 'bg-indigo-500' },
    { stage: 'Chốt', count: 12, value: '₫85M', color: 'bg-green-500' },
  ];

  const activities = [
    { type: 'call', text: 'Gọi cho Nguyễn Văn A', time: '5 phút trước', icon: Phone },
    { type: 'email', text: 'Gửi báo giá cho Trần Thị B', time: '20 phút trước', icon: Mail },
    { type: 'chat', text: 'Chat với Le Văn C qua Zalo', time: '1 giờ trước', icon: MessageSquare },
    { type: 'note', text: 'Ghi chú: KH quan tâm gói Enterprise', time: '2 giờ trước', icon: FileText },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-foreground">CRM — Customer 360</h3>
          <p className="text-xs text-muted-foreground">Dashboard quản lý khách hàng</p>
        </div>
        <span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">Tổng quan</span>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-secondary/30 p-3">
            <s.icon className={`h-4 w-4 ${s.color}`} />
            <p className="mt-2 text-xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-xl border border-border bg-secondary/30 p-4">
        <p className="mb-3 text-xs font-semibold text-foreground">Sales Pipeline</p>
        <div className="space-y-2">
          {pipeline.map((p) => (
            <div key={p.stage} className="flex items-center gap-3">
              <span className="w-20 text-xs text-muted-foreground">{p.stage}</span>
              <div className="flex-1 h-6 rounded-md bg-secondary overflow-hidden">
                <div className={`h-full ${p.color} rounded-md flex items-center px-2`} style={{ width: `${(p.count / 120) * 100}%` }}>
                  <span className="text-xs font-medium text-white">{p.count}</span>
                </div>
              </div>
              <span className="w-16 text-right text-xs font-medium text-foreground">{p.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold text-foreground">Hoạt động gần đây</p>
        <div className="space-y-1.5">
          {activities.map((a, i) => (
            <div key={i} className="flex items-center gap-3 rounded-lg border border-border bg-secondary/20 px-3 py-2">
              <a.icon className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="flex-1 text-xs text-foreground">{a.text}</span>
              <span className="text-xs text-muted-foreground">{a.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
