import { PBXDashboard } from './pbx-dashboard';
import { CallCenterDashboard } from './callcenter-dashboard';
import { CRMDashboard } from './crm-dashboard';
import { OmnichannelDashboard } from './omnichannel-dashboard';
import { TelesalesDashboard } from './telesales-dashboard';
import { AIDashboard } from './ai-dashboard';
import { AutoCallDashboard } from './autocall-dashboard';
import { TelecomDashboard } from './telecom-dashboard';

export type DashboardType = 'pbx' | 'callcenter' | 'crm' | 'omnichannel' | 'telesales' | 'ai' | 'autocall' | 'telecom' | 'generic';

export function DashboardMockup({ type }: { type: DashboardType }) {
  switch (type) {
    case 'pbx':
      return <PBXDashboard />;
    case 'callcenter':
      return <CallCenterDashboard />;
    case 'crm':
      return <CRMDashboard />;
    case 'omnichannel':
      return <OmnichannelDashboard />;
    case 'telesales':
      return <TelesalesDashboard />;
    case 'ai':
      return <AIDashboard />;
    case 'autocall':
      return <AutoCallDashboard />;
    case 'telecom':
      return <TelecomDashboard />;
    default:
      return <PBXDashboard />;
  }
}
