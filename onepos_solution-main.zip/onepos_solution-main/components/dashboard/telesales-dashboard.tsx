import { Phone, PhoneCall, CheckCircle2, Clock, Target, TrendingUp } from 'lucide-react';

export function TelesalesDashboard() {
  const leads = [
    { name: 'Nguyễn Văn A', phone: '0901 234 567', status: 'calling', color: 'bg-green-500' },
    { name: 'Trần Thị B', phone: '0902 345 678', status: 'pending', color: 'bg-amber-500' },
    { name: 'Le Văn C', phone: '0903 456 789', status: 'called', color: 'bg-sky-500' },
    { name: 'Phạm Thị D', phone: '0904 567 890', status: 'pending', color: 'bg-amber-500' },
    { name: 'Hoàng Văn E', phone: '0905 678 901', status: 'called', color: 'bg-sky-500' },
  ];

  const kpis = [
    { label: 'Đã gọi', value: '42', target: '/60', icon: PhoneCall, color: 'text-sky-500' },
    { label: 'Liên lạc', value: '28', target: '/42', icon: CheckCircle2, color: 'text-green-500' },
    { label: 'Chốt', value: '7', target: '/28', icon: Target, color: 'text-accent' },
    { label: 'Thời gian TB', value: '4:12', target: '', icon: Clock, color: 'text-purple-500' },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Telesales Workspace</h3>
          <p className="text-xs text-muted-foreground">Chiến dịch: Tháng 8</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">
          <PhoneCall className="h-3 w-3" /> Đang gọi
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="rounded-xl border border-border bg-secondary/30 p-3">
            <k.icon className={`h-4 w-4 ${k.color}`} />
            <p className="mt-2 text-lg font-bold text-foreground">
              {k.value}<span className="text-xs text-muted-foreground font-normal">{k.target}</span>
            </p>
            <p className="text-xs text-muted-foreground">{k.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 lg:grid-cols-2">
        {/* Lead list */}
        <div>
          <p className="mb-2 text-xs font-semibold text-foreground">Danh sách Lead</p>
          <div className="space-y-1.5">
            {leads.map((l, i) => (
              <div key={i} className="flex items-center gap-3 rounded-lg border border-border bg-secondary/20 px-3 py-2">
                <span className={`h-2 w-2 rounded-full ${l.color}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground">{l.name}</p>
                  <p className="text-[10px] text-muted-foreground">{l.phone}</p>
                </div>
                {l.status === 'calling' && (
                  <button className="flex items-center gap-1 rounded-md bg-green-500 px-2 py-1 text-[10px] font-medium text-white">
                    <Phone className="h-2.5 w-2.5" /> Đang gọi
                  </button>
                )}
                {l.status === 'pending' && (
                  <button className="flex items-center gap-1 rounded-md bg-primary px-2 py-1 text-[10px] font-medium text-primary-foreground">
                    <PhoneCall className="h-2.5 w-2.5" /> Gọi
                  </button>
                )}
                {l.status === 'called' && (
                  <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> Đã gọi
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Script + Notes */}
        <div className="space-y-3">
          <div className="rounded-xl border border-border bg-secondary/30 p-3">
            <p className="mb-2 text-xs font-semibold text-foreground">Kịch bản gọi</p>
            <div className="space-y-1.5 text-xs text-foreground/80">
              <p>1. Chào khách hàng, giới thiệu OnePOS</p>
              <p>2. Hỏi nhu cầu: tổng đài / call center / CRM</p>
              <p>3. Tư vấn gói phù hợp theo quy mô</p>
              <p>4. Mời dùng thử miễn phí</p>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-secondary/30 p-3">
            <p className="mb-2 text-xs font-semibold text-foreground">Ghi chú</p>
            <div className="h-16 rounded-md border border-dashed border-border bg-background p-2 text-xs text-muted-foreground">
              Khách quan tâm gói Call Center, đội 20 agent...
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
