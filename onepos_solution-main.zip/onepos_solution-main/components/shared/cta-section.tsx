import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export function CTASection({
  title = 'Sẵn sàng trải nghiệm OnePOS?',
  description = 'Bắt đầu dùng thử miễn phí hoặc đăng ký tư vấn để khám phá cách OnePOS giúp doanh nghiệp của bạn kết nối khách hàng tốt hơn.',
  primaryLabel = 'Dùng thử miễn phí',
  primaryHref = '/dung-thu',
  secondaryLabel = 'Đăng ký tư vấn',
  secondaryHref = '/lien-he',
}: {
  title?: string;
  description?: string;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
}) {
  return (
    <section className="section-pad">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy-950 via-navy-900 to-primary px-6 py-16 sm:px-12 sm:py-20 lg:py-24">
          <div className="absolute inset-0 grid-pattern opacity-10" />
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-accent/20 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-sky-400/20 blur-3xl" />
          <div className="relative mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-[2.75rem] lg:leading-[1.1]">
              {title}
            </h2>
            <p className="mt-4 text-base text-navy-200 sm:text-lg leading-relaxed">
              {description}
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link
                href={primaryHref}
                className="group inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-navy-950 shadow-xl transition-all hover:shadow-2xl hover:scale-105"
              >
                {primaryLabel}
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                href={secondaryHref}
                className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/10"
              >
                {secondaryLabel}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
