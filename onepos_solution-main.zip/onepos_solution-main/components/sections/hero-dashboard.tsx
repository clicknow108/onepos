import { Phone, Users, MessageSquare, Activity, TrendingUp, Clock, Headphones, Bot } from 'lucide-react';

export function HeroDashboard() {
  return (
    <div className="relative">
      <div className="rounded-2xl border border-border bg-card p-4 shadow-2xl shadow-foreground/10 sm:p-5">
        {/* Top bar */}
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Headphones className="h-3.5 w-3.5 text-primary" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">OnePOS Dashboard</p>
              <p className="text-[10px] text-muted-foreground">Realtime</p>
            </div>
          </div>
          <span className="flex items-center gap-1.5 rounded-full bg-green-50 px-2 py-0.5 text-[10px] font-medium text-green-600">
            <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" /> Live
          </span>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {[
            { label: 'Cuộc gọi', value: '142', icon: Phone, color: 'text-sky-500', bg: 'bg-sky-50' },
            { label: 'Agent online', value: '18/20', icon: Users, color: 'text-green-500', bg: 'bg-green-50' },
            { label: 'Chat', value: '28', icon: MessageSquare, color: 'text-amber-500', bg: 'bg-amber-50' },
            { label: 'AI đang xử lý', value: '7', icon: Bot, color: 'text-purple-500', bg: 'bg-purple-50' },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-secondary/30 p-2.5">
              <div className={`flex h-6 w-6 items-center justify-center rounded-lg ${s.bg}`}>
                <s.icon className={`h-3 w-3 ${s.color}`} />
              </div>
              <p className="mt-1.5 text-base font-bold text-foreground">{s.value}</p>
              <p className="text-[10px] text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Chart + Queue */}
        <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <div className="rounded-xl border border-border bg-secondary/30 p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-semibold text-foreground">Lưu lượng cuộc gọi</p>
              <TrendingUp className="h-3 w-3 text-green-500" />
            </div>
            <div className="flex h-16 items-end gap-1">
              {[40, 55, 68, 72, 85, 92, 78, 65, 58, 70, 82, 88].map((v, i) => (
                <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-primary/30 to-primary" style={{ height: `${v}%` }} />
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-border bg-secondary/30 p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-semibold text-foreground">Hàng đợi</p>
              <Clock className="h-3 w-3 text-amber-500" />
            </div>
            <div className="space-y-1.5">
              {[
                { name: 'Sales', count: 3, wait: '1:20' },
                { name: 'CSKH', count: 1, wait: '0:45' },
                { name: 'Kỹ thuật', count: 0, wait: '—' },
              ].map((q) => (
                <div key={q.name} className="flex items-center gap-2 text-[10px]">
                  <span className="flex-1 text-foreground">{q.name}</span>
                  <span className="text-muted-foreground">{q.count} chờ</span>
                  <span className="w-8 text-right text-muted-foreground">{q.wait}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Insight */}
        <div className="mt-3 flex items-center gap-2.5 rounded-xl border border-primary/20 bg-primary/5 p-3">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
            <Bot className="h-3.5 w-3.5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-[10px] font-semibold text-primary">AI Insight</p>
            <p className="text-[10px] text-foreground/70">Phát hiện: 3 cuộc gọi có cảm xúc tiêu cực, cần can thiệp</p>
          </div>
          <Activity className="h-3.5 w-3.5 text-primary" />
        </div>
      </div>

      {/* Floating cards */}
      <div className="absolute -right-3 -top-3 hidden rounded-xl border border-border bg-card p-2.5 shadow-lg sm:block animate-float">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-green-50">
            <Phone className="h-3.5 w-3.5 text-green-500" />
          </div>
          <div>
            <p className="text-[10px] font-semibold text-foreground">Cuộc gọi mới</p>
            <p className="text-[10px] text-muted-foreground">0901 234 567</p>
          </div>
        </div>
      </div>
      <div className="absolute -bottom-3 -left-3 hidden rounded-xl border border-border bg-card p-2.5 shadow-lg sm:block animate-float" style={{ animationDelay: '2s' }}>
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-50">
            <MessageSquare className="h-3.5 w-3.5 text-amber-500" />
          </div>
          <div>
            <p className="text-[10px] font-semibold text-foreground">Tin nhắn Zalo</p>
            <p className="text-[10px] text-muted-foreground">Khách hỏi giá</p>
          </div>
        </div>
      </div>
    </div>
  );
}
