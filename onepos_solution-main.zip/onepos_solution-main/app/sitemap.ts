import type { MetadataRoute } from 'next';
import { Products } from '@/content/products';
import { AllSolutions } from '@/content/solutions';
import { BlogPosts } from '@/content/blog';
import { SiteConfig } from '@/content/site-config';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = SiteConfig.url;
  const now = new Date();

  const staticPages: MetadataRoute.Sitemap = [
    { url: `${base}/`, lastModified: now, changeFrequency: 'weekly', priority: 1 },
    { url: `${base}/san-pham`, lastModified: now, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${base}/giai-phap`, lastModified: now, changeFrequency: 'weekly', priority: 0.8 },
    { url: `${base}/bang-gia`, lastModified: now, changeFrequency: 'monthly', priority: 0.8 },
    { url: `${base}/blog`, lastModified: now, changeFrequency: 'daily', priority: 0.7 },
    { url: `${base}/case-study`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/faq`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/lien-he`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/dung-thu`, lastModified: now, changeFrequency: 'monthly', priority: 0.9 },
    { url: `${base}/developers`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/ve-onepos`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
  ];

  const productPages: MetadataRoute.Sitemap = Products.map((p) => ({
    url: `${base}/san-pham/${p.slug}`,
    lastModified: now,
    changeFrequency: 'weekly' as const,
    priority: 0.9,
  }));

  const solutionPages: MetadataRoute.Sitemap = AllSolutions.map((s) => ({
    url: `${base}/giai-phap/${s.slug}`,
    lastModified: now,
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }));

  const blogPages: MetadataRoute.Sitemap = BlogPosts.map((p) => ({
    url: `${base}/blog/${p.slug}`,
    lastModified: new Date(p.date),
    changeFrequency: 'monthly' as const,
    priority: 0.6,
  }));

  return [...staticPages, ...productPages, ...solutionPages, ...blogPages];
}
