import type { Metadata } from 'next';
import { Cloud, Headphones, Users, Bot, Network, Code2, Target, Heart, Zap, Shield } from 'lucide-react';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Về OnePOS — Nền tảng kết nối khách hàng cho doanh nghiệp',
  description: 'OnePOS là nền tảng kết nối và tự động hóa giao tiếp khách hàng cho doanh nghiệp Việt Nam — Tổng đài, Call Center, CRM, Omnichannel và AI.',
  alternates: { canonical: '/ve-onepos' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/ve-onepos`,
    title: 'Về OnePOS — Nền tảng kết nối khách hàng cho doanh nghiệp',
    description: 'OnePOS là nền tảng kết nối và tự động hóa giao tiếp khách hàng cho doanh nghiệp Việt Nam.',
  },
};

const values = [
  { icon: Target, title: 'Khách hàng là trung tâm', desc: 'Mọi tính năng được xây dựng xoay quanh trải nghiệm khách hàng.' },
  { icon: Zap, title: 'Đơn giản & Hiệu quả', desc: 'Công nghệ phức tạp, trải nghiệm đơn giản. Agent làm việc hiệu quả hơn.' },
  { icon: Shield, title: 'Đáng tin cậy', desc: 'Bảo mật dữ liệu, ổn định và hỗ trợ tận tâm.' },
  { icon: Heart, title: 'Tận tâm phục vụ', desc: 'Đồng hành cùng doanh nghiệp Việt Nam trên hành trình phát triển.' },
];

const stats = [
  { label: 'Sản phẩm', value: '12+' },
  { label: 'Kênh tích hợp', value: '6+' },
  { label: 'Tính năng', value: '100+' },
  { label: 'API & SDK', value: '4' },
];

export default function AboutPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
              Về OnePOS
            </span>
            <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl lg:leading-[1.1]">
              Nền tảng kết nối khách hàng cho doanh nghiệp Việt Nam
            </h1>
            <p className="mt-4 text-base text-muted-foreground leading-relaxed">
              OnePOS không chỉ là phần mềm tổng đài — đây là nền tảng kết nối và tự động hóa giao tiếp khách hàng, giúp doanh nghiệp bán hàng tốt hơn, chăm sóc khách hàng nhanh hơn và vận hành hiệu quả hơn.
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12">
        <div className="container-page">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="rounded-2xl border border-border bg-card p-6 text-center">
                <p className="text-3xl font-bold text-primary sm:text-4xl">{s.value}</p>
                <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <SectionHeading
              eyebrow="Sứ mệnh"
              title="Kết nối doanh nghiệp với khách hàng"
              description="OnePOS ra đời với sứ mệnh giúp doanh nghiệp Việt Nam tiếp cận công nghệ chăm sóc khách hàng hiện đại — không cần đầu tư lớn, không cần hạ tầng phức tạp."
            />
            <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2">
              {[
                { icon: Cloud, title: 'Cloud-first', desc: 'Xây dựng trên Cloud, mở rộng linh hoạt, không cần phần cứng.' },
                { icon: Headphones, title: 'Call Center chuyên nghiệp', desc: 'Đầy đủ tính năng Call Center cho đội ngũ Sales & CSKH.' },
                { icon: Users, title: 'CRM tập trung', desc: 'Dữ liệu khách hàng tập trung, tầm nhìn 360°.' },
                { icon: Bot, title: 'AI Ready', desc: 'Sẵn sàng tích hợp AI Voice Agent, Chatbot và Call Analytics.' },
                { icon: Network, title: 'Omnichannel', desc: 'Hợp nhất mọi kênh giao tiếp trên một nền tảng.' },
                { icon: Code2, title: 'API First', desc: 'Dễ tích hợp với hệ thống doanh nghiệp qua API và SDK.' },
              ].map((item) => (
                <div key={item.title} className="flex gap-4 rounded-2xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-foreground">{item.title}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-pad">
        <div className="container-page">
          <SectionHeading
            eyebrow="Giá trị cốt lõi"
            title="Giá trị OnePOS"
            description="Những nguyên tắc định hướng mọi quyết định của chúng tôi."
          />
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v) => (
              <div key={v.title} className="rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-accent/10">
                  <v.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mt-4 text-base font-bold text-foreground">{v.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
