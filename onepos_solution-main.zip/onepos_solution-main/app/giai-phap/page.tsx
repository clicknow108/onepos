import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { Solutions, Industries, ScaleSolutions } from '@/content/solutions';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Giải pháp — OnePOS',
  description: 'Giải pháp OnePOS theo nhu cầu, ngành và quy mô doanh nghiệp: Telesales, Chăm sóc khách hàng, Call Center, Contact Center, AI và nhiều hơn nữa.',
  alternates: { canonical: '/giai-phap' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/giai-phap`,
    title: 'Giải pháp — OnePOS',
    description: 'Giải pháp OnePOS theo nhu cầu, ngành và quy mô doanh nghiệp.',
  },
};

export default function SolutionsPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <SectionHeading
            eyebrow="Giải pháp"
            title="Giải pháp cho mọi nhu cầu và ngành"
            description="OnePOS cung cấp giải pháp tùy chỉnh theo nhu cầu, ngành nghề và quy mô doanh nghiệp."
          />
        </div>
      </section>

      {/* By need */}
      <section className="section-pad">
        <div className="container-page">
          <h2 className="text-2xl font-bold tracking-tight">Theo nhu cầu</h2>
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Solutions.map((s) => (
              <Link key={s.slug} href={`/giai-phap/${s.slug}`} className="group rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <h3 className="text-lg font-bold text-foreground">{s.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.tagline}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                  Xem giải pháp <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* By industry */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <h2 className="text-2xl font-bold tracking-tight">Theo ngành</h2>
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Industries.map((s) => (
              <Link key={s.slug} href={`/giai-phap/${s.slug}`} className="group rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <h3 className="text-lg font-bold text-foreground">{s.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.tagline}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                  Xem giải pháp <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* By scale */}
      <section className="section-pad">
        <div className="container-page">
          <h2 className="text-2xl font-bold tracking-tight">Theo quy mô</h2>
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
            {ScaleSolutions.map((s) => (
              <Link key={s.slug} href={`/giai-phap/${s.slug}`} className="group rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <h3 className="text-lg font-bold text-foreground">{s.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.tagline}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                  Xem giải pháp <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
