import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowRight, CheckCircle2, ChevronRight, AlertCircle, Lightbulb, Workflow } from 'lucide-react';
import { AllSolutions, getSolution } from '@/content/solutions';
import { Products, getProduct } from '@/content/products';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export async function generateStaticParams() {
  return AllSolutions.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const solution = getSolution(params.slug);
  if (!solution) return {};
  return {
    title: `Giải pháp ${solution.name} — ${solution.tagline}`,
    description: solution.description,
    alternates: { canonical: `/giai-phap/${solution.slug}` },
    openGraph: {
      type: 'website',
      locale: 'vi_VN',
      url: `${SiteConfig.url}/giai-phap/${solution.slug}`,
      title: `Giải pháp ${solution.name} — ${solution.tagline}`,
      description: solution.description,
    },
  };
}

export default function SolutionPage({ params }: { params: { slug: string } }) {
  const solution = getSolution(params.slug);
  if (!solution) notFound();

  const solutionProducts = solution.products
    .map((slug) => getProduct(slug))
    .filter(Boolean);

  return (
    <>
      {/* Breadcrumb */}
      <div className="border-b border-border bg-secondary/30">
        <div className="container-page py-3">
          <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Link href="/" className="hover:text-foreground">Trang chủ</Link>
            <ChevronRight className="h-3 w-3" />
            <Link href="/giai-phap" className="hover:text-foreground">Giải pháp</Link>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground">{solution.name}</span>
          </nav>
        </div>
      </div>

      {/* Hero */}
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-sky-50/50 to-background" />
          <div className="absolute -top-20 left-0 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        </div>
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
              {solution.type === 'industry' ? 'Giải pháp theo ngành' : solution.type === 'scale' ? 'Giải pháp theo quy mô' : 'Giải pháp theo nhu cầu'}
            </span>
            <h1 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl lg:leading-[1.1]">
              Giải pháp {solution.name}
            </h1>
            <p className="mt-4 text-lg text-muted-foreground leading-relaxed">{solution.tagline}</p>
            <p className="mt-4 text-base text-foreground/80 leading-relaxed">{solution.description}</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row justify-center">
              <Link href="/dung-thu" className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:scale-105">
                Dùng thử miễn phí <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/lien-he" className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-all hover:bg-secondary">
                Đăng ký tư vấn
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Pain Points */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">Thách thức doanh nghiệp gặp phải</h2>
            <div className="mt-10 space-y-3">
              {solution.painPoints.map((point, i) => (
                <div key={i} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
                  <AlertCircle className="h-5 w-5 shrink-0 text-amber-500" />
                  <p className="text-sm text-foreground/80">{point}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solutions */}
      <section className="section-pad">
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Giải pháp OnePOS</h2>
            <p className="mt-4 text-base text-muted-foreground">Cách OnePOS giải quyết các thách thức trên.</p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2">
            {solution.solutions.map((s, i) => (
              <div key={i} className="flex gap-4 rounded-2xl border border-border bg-card p-6">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-accent/10">
                  <Lightbulb className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-foreground">{s.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{s.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Workflow */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Quy trình hoạt động</h2>
            <p className="mt-4 text-base text-muted-foreground">Các bước triển khai giải pháp.</p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-5">
            {solution.workflow.map((step, i) => (
              <div key={i} className="relative">
                <div className="rounded-2xl border border-border bg-card p-5">
                  <div className="flex items-center gap-2">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    <Workflow className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <h3 className="mt-3 text-sm font-bold text-foreground">{step.step}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products used */}
      {solutionProducts.length > 0 && (
        <section className="section-pad">
          <div className="container-page">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Sản phẩm sử dụng</h2>
              <p className="mt-4 text-base text-muted-foreground">Các sản phẩm OnePOS trong giải pháp này.</p>
            </div>
            <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {solutionProducts.map((p) => p && (
                <Link key={p.slug} href={`/san-pham/${p.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-all hover:shadow-xl hover:border-primary/20">
                  <h3 className="text-base font-bold text-foreground">{p.name}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.tagline}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                    Khám phá <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Features */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Tính năng nổi bật</h2>
          </div>
          <div className="mt-12 flex flex-wrap justify-center gap-3">
            {solution.features.map((f) => (
              <div key={f} className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="section-pad">
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Trường hợp sử dụng</h2>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-3">
            {solution.useCases.map((uc, i) => (
              <div key={i} className="rounded-2xl border border-border bg-card p-6">
                <h3 className="text-base font-bold text-foreground">{uc.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{uc.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
