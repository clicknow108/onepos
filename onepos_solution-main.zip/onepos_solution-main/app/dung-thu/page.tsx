import type { Metadata } from 'next';
import { CheckCircle2 } from 'lucide-react';
import { ContactForm } from '@/components/forms/contact-form';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Dùng thử miễn phí — OnePOS',
  description: 'Đăng ký dùng thử miễn phí OnePOS — trải nghiệm Tổng đài Cloud, Call Center, CRM, Omnichannel và AI trên một nền tảng.',
  alternates: { canonical: '/dung-thu' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/dung-thu`,
    title: 'Dùng thử miễn phí — OnePOS',
    description: 'Đăng ký dùng thử miễn phí OnePOS — trải nghiệm Tổng đài Cloud, Call Center, CRM, Omnichannel và AI.',
  },
};

const benefits = [
  'Trải nghiệm đầy đủ tính năng OnePOS',
  'Không cần đầu tư phần cứng',
  'Triển khai nhanh, bắt đầu ngay',
  'Hỗ trợ từ đội ngũ OnePOS',
  'Không cam kết dài hạn',
  'Mở rộng linh hoạt khi cần',
];

export default function TrialPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
                Dùng thử miễn phí
              </span>
              <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl lg:leading-[1.1]">
                Trải nghiệm OnePOS miễn phí
              </h1>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">
                Đăng ký dùng thử để khám phá toàn bộ tính năng OnePOS — Tổng đài Cloud, Call Center, CRM, Omnichannel và AI trên một nền tảng.
              </p>
              <ul className="mt-6 space-y-3">
                {benefits.map((b) => (
                  <li key={b} className="flex items-center gap-3 text-sm text-foreground/80">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
                    {b}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 shadow-xl">
              <h2 className="text-xl font-bold text-foreground">Đăng ký dùng thử</h2>
              <p className="mt-2 text-sm text-muted-foreground">Điền thông tin để nhận tài khoản dùng thử.</p>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
