import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Chính sách cookie',
  description: 'Chính sách cookie OnePOS.',
  alternates: { canonical: '/chinh-sach-cookie' },
};

export default function CookiePage() {
  return (
    <section className="py-12 lg:py-20">
      <div className="container-page">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Chính sách cookie</h1>
          <p className="mt-4 text-sm text-muted-foreground">Cập nhật: {new Date().toLocaleDateString('vi-VN')}</p>
          <div className="mt-8 space-y-6 text-sm text-foreground/80 leading-relaxed">
            <p>OnePOS sử dụng cookie để cải thiện trải nghiệm người dùng và phân tích lưu lượng truy cập.</p>
            <h2 className="text-xl font-bold text-foreground">1. Cookie là gì?</h2>
            <p>Cookie là tệp văn bản nhỏ được lưu trữ trên trình duyệt khi bạn truy cập website.</p>
            <h2 className="text-xl font-bold text-foreground">2. Cách OnePOS sử dụng cookie</h2>
            <p>OnePOS sử dụng cookie để ghi nhớ tùy chọn, phân tích cách sử dụng và cải thiện website.</p>
            <h2 className="text-xl font-bold text-foreground">3. Quản lý cookie</h2>
            <p>Bạn có thể quản lý hoặc xóa cookie trong cài đặt trình duyệt. Vô hiệu hóa cookie có thể ảnh hưởng trải nghiệm website.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
