import type { Metadata } from 'next';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { ContactForm } from '@/components/forms/contact-form';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Liên hệ — OnePOS',
  description: 'Liên hệ OnePOS để được tư vấn về Tổng đài Cloud, Call Center, CRM, Omnichannel và AI cho doanh nghiệp.',
  alternates: { canonical: '/lien-he' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/lien-he`,
    title: 'Liên hệ — OnePOS',
    description: 'Liên hệ OnePOS để được tư vấn về Tổng đài Cloud, Call Center, CRM, Omnichannel và AI.',
  },
};

const contactInfo = [
  { icon: Phone, label: 'Hotline', value: SiteConfig.contact.hotline },
  { icon: Mail, label: 'Email', value: SiteConfig.contact.email },
  { icon: MapPin, label: 'Địa chỉ', value: SiteConfig.contact.address },
  { icon: Clock, label: 'Giờ hỗ trợ', value: SiteConfig.contact.supportHours },
];

export default function ContactPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
              Liên hệ
            </span>
            <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
              Đăng ký tư vấn
            </h1>
            <p className="mt-4 text-base text-muted-foreground leading-relaxed">
              Để lại thông tin, đội ngũ OnePOS sẽ liên hệ tư vấn giải pháp phù hợp cho doanh nghiệp của bạn.
            </p>
          </div>
        </div>
      </section>

      <section className="pb-16 lg:pb-24">
        <div className="container-page">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            {/* Form */}
            <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 shadow-sm">
              <h2 className="text-xl font-bold text-foreground">Thông tin liên hệ</h2>
              <p className="mt-2 text-sm text-muted-foreground">Vui lòng điền đầy đủ thông tin để chúng tôi tư vấn chính xác.</p>
              <ContactForm />
            </div>

            {/* Contact info */}
            <div className="space-y-4">
              {contactInfo.map((info) => (
                <div key={info.label} className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                    <info.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{info.label}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{info.value}</p>
                  </div>
                </div>
              ))}
              <div className="rounded-2xl border border-border bg-navy-950 p-6 text-white">
                <h3 className="text-lg font-bold">Hỗ trợ nhanh</h3>
                <p className="mt-2 text-sm text-navy-200">
                  Đội ngũ OnePOS sẵn sàng hỗ trợ bạn trong giờ làm việc. Nếu cần hỗ trợ khẩn cấp, vui lòng gọi hotline.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
