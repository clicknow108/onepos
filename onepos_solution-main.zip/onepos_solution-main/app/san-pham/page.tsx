import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { Products } from '@/content/products';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Sản phẩm — Hệ sinh thái OnePOS',
  description: 'Khám phá toàn bộ hệ sinh thái OnePOS: Tổng đài Cloud, Call Center, Contact Center, Omnichannel, CRM, Telesales, Auto Call, AI và Viễn thông.',
  alternates: { canonical: '/san-pham' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/san-pham`,
    title: 'Sản phẩm — Hệ sinh thái OnePOS',
    description: 'Khám phá toàn bộ hệ sinh thái OnePOS: Tổng đài Cloud, Call Center, Contact Center, Omnichannel, CRM, Telesales, Auto Call, AI và Viễn thông.',
  },
};

const categories = ['Tổng đài & Call Center', 'Omnichannel', 'CRM & Sales', 'AI', 'Viễn thông'];

export default function ProductsPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <SectionHeading
            eyebrow="Hệ sinh thái"
            title="Tất cả sản phẩm OnePOS"
            description="OnePOS cung cấp đầy đủ công cụ từ tổng đài, call center, CRM, telesales đến AI — trên một nền tảng duy nhất."
          />
        </div>
      </section>

      {categories.map((cat) => {
        const products = Products.filter((p) => p.category === cat);
        if (products.length === 0) return null;
        return (
          <section key={cat} className="section-pad">
            <div className="container-page">
              <h2 className="text-2xl font-bold tracking-tight">{cat}</h2>
              <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {products.map((p) => (
                  <Link key={p.slug} href={`/san-pham/${p.slug}`} className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20 hover:-translate-y-1">
                    <h3 className="text-lg font-bold text-foreground">{p.name}</h3>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{p.tagline}</p>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {p.features.slice(0, 5).map((f) => (
                        <span key={f.label} className="rounded-md bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">{f.label}</span>
                      ))}
                    </div>
                    <span className="mt-auto pt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                      Khám phá <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        );
      })}

      <CTASection />
    </>
  );
}
