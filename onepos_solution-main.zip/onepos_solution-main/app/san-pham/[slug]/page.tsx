import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowRight, CheckCircle2, ChevronRight } from 'lucide-react';
import { Products, getProduct } from '@/content/products';
import { DashboardMockup } from '@/components/dashboard';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export async function generateStaticParams() {
  return Products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = getProduct(params.slug);
  if (!product) return {};
  return {
    title: `${product.name} — ${product.tagline}`,
    description: product.description,
    alternates: { canonical: `/san-pham/${product.slug}` },
    openGraph: {
      type: 'website',
      locale: 'vi_VN',
      url: `${SiteConfig.url}/san-pham/${product.slug}`,
      title: `${product.name} — ${product.tagline}`,
      description: product.description,
    },
  };
}

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProduct(params.slug);
  if (!product) notFound();

  const relatedProducts = Products.filter(
    (p) => p.slug !== product.slug && p.category === product.category
  ).slice(0, 3);

  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: product.faqs.map((f) => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: { '@type': 'Answer', text: f.answer },
    })),
  };

  const productJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: product.name,
    description: product.description,
    applicationCategory: 'BusinessApplication',
    operatingSystem: 'Web',
    offers: { '@type': 'Offer', price: '0', priceCurrency: 'VND' },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }} />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-secondary/30">
        <div className="container-page py-3">
          <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Link href="/" className="hover:text-foreground">Trang chủ</Link>
            <ChevronRight className="h-3 w-3" />
            <Link href="/san-pham" className="hover:text-foreground">Sản phẩm</Link>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground">{product.name}</span>
          </nav>
        </div>
      </div>

      {/* Hero */}
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-sky-50/50 to-background" />
          <div className="absolute -top-20 right-0 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        </div>
        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
                {product.category}
              </span>
              <h1 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl lg:leading-[1.1]">
                {product.name}
              </h1>
              <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                {product.tagline}
              </p>
              <p className="mt-4 text-base text-foreground/80 leading-relaxed">
                {product.description}
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href="/dung-thu" className="group inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:shadow-xl hover:scale-105">
                  Dùng thử miễn phí <ArrowRight className="h-4 w-4" />
                </Link>
                <Link href="/lien-he" className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-all hover:bg-secondary">
                  Đăng ký tư vấn
                </Link>
              </div>
            </div>
            <div className="relative">
              <DashboardMockup type={product.dashboardType} />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Tính năng</h2>
            <p className="mt-4 text-base text-muted-foreground">
              Đầy đủ tính năng {product.name.toLowerCase()} cho doanh nghiệp.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {product.features.map((f) => (
              <div key={f.label} className="rounded-2xl border border-border bg-card p-5 transition-all hover:shadow-lg hover:border-primary/20">
                <div className="flex items-start gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-foreground">{f.label}</h3>
                    {f.description && <p className="mt-1 text-xs text-muted-foreground">{f.description}</p>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-pad">
        <div className="container-page">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Lợi ích</h2>
            <p className="mt-4 text-base text-muted-foreground">
              {product.name} mang lại giá trị gì cho doanh nghiệp của bạn.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2">
            {product.benefits.map((b, i) => (
              <div key={i} className="flex gap-4 rounded-2xl border border-border bg-card p-6">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-accent/10 text-lg font-bold text-primary">
                  {String(i + 1).padStart(2, '0')}
                </div>
                <div>
                  <h3 className="text-base font-bold text-foreground">{b.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{b.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">Câu hỏi thường gặp</h2>
            <div className="mt-10 space-y-3">
              {product.faqs.map((faq) => (
                <details key={faq.question} className="group rounded-xl border border-border bg-card p-5">
                  <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-foreground list-none">
                    {faq.question}
                    <span className="ml-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-transform group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Related products */}
      {relatedProducts.length > 0 && (
        <section className="section-pad">
          <div className="container-page">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Sản phẩm liên quan</h2>
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
              {relatedProducts.map((p) => (
                <Link key={p.slug} href={`/san-pham/${p.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-all hover:shadow-xl hover:border-primary/20">
                  <h3 className="text-base font-bold text-foreground">{p.name}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.tagline}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                    Khám phá <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <CTASection />
    </>
  );
}
