import type { Metadata } from 'next';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Case Study — OnePOS',
  description: 'Case Study OnePOS — câu chuyện doanh nghiệp sử dụng OnePOS để tối ưu chăm sóc khách hàng, tăng hiệu suất Sales và tự động hóa giao tiếp.',
  alternates: { canonical: '/case-study' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/case-study`,
    title: 'Case Study — OnePOS',
    description: 'Case Study OnePOS — câu chuyện doanh nghiệp sử dụng OnePOS.',
  },
};

export default function CaseStudyPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <SectionHeading
            eyebrow="Case Study"
            title="Case Study đang cập nhật"
            description="Chúng tôi đang thu thập các câu chuyện thành công từ khách hàng OnePOS. Vui lòng quay lại sau."
          />
        </div>
      </section>

      <section className="section-pad">
        <div className="container-page">
          <div className="mx-auto max-w-2xl rounded-2xl border border-dashed border-border bg-secondary/30 p-12 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
              <svg viewBox="0 0 24 24" className="h-8 w-8 text-primary" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <path d="M14 2v6h6" />
                <path d="M16 13H8" />
                <path d="M16 17H8" />
                <path d="M10 9H8" />
              </svg>
            </div>
            <h3 className="mt-6 text-xl font-bold text-foreground">Case Study đang cập nhật</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Chúng tôi đang thu thập các câu chuyện thành công từ khách hàng OnePOS. Nếu bạn muốn chia sẻ trải nghiệm, vui lòng liên hệ với chúng tôi.
            </p>
          </div>
        </div>
      </section>

      <CTASection
        title="Bạn muốn chia sẻ câu chuyện của mình?"
        description="Nếu bạn là khách hàng OnePOS và muốn chia sẻ trải nghiệm, hãy liên hệ với chúng tôi."
        primaryLabel="Liên hệ"
        primaryHref="/lien-he"
      />
    </>
  );
}
