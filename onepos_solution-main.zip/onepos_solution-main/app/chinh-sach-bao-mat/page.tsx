import type { Metadata } from 'next';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Chính sách bảo mật',
  description: 'Chính sách bảo mật OnePOS — cách chúng tôi bảo vệ dữ liệu khách hàng.',
  alternates: { canonical: '/chinh-sach-bao-mat' },
};

export default function PrivacyPage() {
  return (
    <section className="py-12 lg:py-20">
      <div className="container-page">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Chính sách bảo mật</h1>
          <p className="mt-4 text-sm text-muted-foreground">Cập nhật: {new Date().toLocaleDateString('vi-VN')}</p>
          <div className="mt-8 space-y-6 text-sm text-foreground/80 leading-relaxed">
            <p>OnePOS cam kết bảo vệ dữ liệu cá nhân và dữ liệu doanh nghiệp của khách hàng. Chính sách bảo mật mô tả cách chúng tôi thu thập, sử dụng và bảo vệ thông tin.</p>
            <h2 className="text-xl font-bold text-foreground">1. Thu thập thông tin</h2>
            <p>OnePOS thu thập thông tin khách hàng cung cấp khi đăng ký sử dụng dịch vụ, bao gồm: họ tên, tên công ty, số điện thoại, email và thông tin liên hệ.</p>
            <h2 className="text-xl font-bold text-foreground">2. Sử dụng thông tin</h2>
            <p>Thông tin được sử dụng để cung cấp dịch vụ, hỗ trợ khách hàng, cải thiện sản phẩm và gửi thông tin liên quan đến dịch vụ.</p>
            <h2 className="text-xl font-bold text-foreground">3. Bảo mật dữ liệu</h2>
            <p>OnePOS áp dụng các biện pháp bảo mật kỹ thuật và tổ chức để bảo vệ dữ liệu khách hàng khỏi truy cập trái phép.</p>
            <h2 className="text-xl font-bold text-foreground">4. Chia sẻ thông tin</h2>
            <p>OnePOS không bán hoặc cho thuê thông tin khách hàng cho bên thứ ba. Thông tin chỉ được chia sẻ khi có yêu cầu pháp lý hoặc với đối tác cung cấp dịch vụ có thỏa thuận bảo mật.</p>
            <h2 className="text-xl font-bold text-foreground">5. Quyền của khách hàng</h2>
            <p>Khách hàng có quyền xem, chỉnh sửa hoặc xóa thông tin cá nhân. Vui lòng liên hệ {SiteConfig.contact.email} để thực hiện quyền.</p>
            <h2 className="text-xl font-bold text-foreground">6. Liên hệ</h2>
            <p>Nếu bạn có câu hỏi về chính sách bảo mật, vui lòng liên hệ: {SiteConfig.contact.email} hoặc hotline {SiteConfig.contact.hotline}.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
