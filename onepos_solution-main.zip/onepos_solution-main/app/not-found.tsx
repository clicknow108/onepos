import Link from 'next/link';
import { Home, ArrowRight } from 'lucide-react';

export default function NotFound() {
  return (
    <section className="flex min-h-[60vh] items-center justify-center py-20">
      <div className="container-page text-center">
        <p className="text-6xl font-bold text-primary sm:text-8xl">404</p>
        <h1 className="mt-4 text-2xl font-bold text-foreground sm:text-3xl">Không tìm thấy trang</h1>
        <p className="mt-2 text-sm text-muted-foreground">Trang bạn tìm kiếm không tồn tại hoặc đã được chuyển.</p>
        <Link href="/" className="group mt-8 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:shadow-lg hover:gap-3">
          <Home className="h-4 w-4" /> Về trang chủ <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </section>
  );
}
