import type { Metadata } from 'next';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Điều khoản sử dụng',
  description: 'Điều khoản sử dụng dịch vụ OnePOS.',
  alternates: { canonical: '/dieu-khoan-su-dung' },
};

export default function TermsPage() {
  return (
    <section className="py-12 lg:py-20">
      <div className="container-page">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Điều khoản sử dụng</h1>
          <p className="mt-4 text-sm text-muted-foreground">Cập nhật: {new Date().toLocaleDateString('vi-VN')}</p>
          <div className="mt-8 space-y-6 text-sm text-foreground/80 leading-relaxed">
            <p>Bằng việc sử dụng dịch vụ OnePOS, bạn đồng ý với các điều khoản sau. Vui lòng đọc kỹ trước khi sử dụng.</p>
            <h2 className="text-xl font-bold text-foreground">1. Dịch vụ</h2>
            <p>OnePOS cung cấp nền tảng tổng đài Cloud, Call Center, CRM, Omnichannel và AI cho doanh nghiệp. Chi tiết dịch vụ theo gói đăng ký.</p>
            <h2 className="text-xl font-bold text-foreground">2. Trách nhiệm khách hàng</h2>
            <p>Khách hàng chịu trách nhiệm về tính chính xác của thông tin cung cấp và cách sử dụng dịch vụ tuân thủ pháp luật Việt Nam.</p>
            <h2 className="text-xl font-bold text-foreground">3. Thanh toán</h2>
            <p>Khách hàng thanh toán phí dịch vụ theo gói đã chọn. Chi tiết giá vui lòng liên hệ tư vấn.</p>
            <h2 className="text-xl font-bold text-foreground">4. Chấm dứt dịch vụ</h2>
            <p>Khách hàng có thể chấm dứt dịch vụ bất cứ lúc nào. OnePOS có quyền tạm ngừng hoặc chấm dứt dịch vụ nếu khách hàng vi phạm điều khoản.</p>
            <h2 className="text-xl font-bold text-foreground">5. Liên hệ</h2>
            <p>Nếu bạn có câu hỏi về điều khoản sử dụng, vui lòng liên hệ: {SiteConfig.contact.email}.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
