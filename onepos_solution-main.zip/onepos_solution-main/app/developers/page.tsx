import type { Metadata } from 'next';
import Link from 'next/link';
import { Code2, Webhook, Smartphone, Globe, ArrowRight, Terminal, Zap } from 'lucide-react';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Developer — API, SDK & Webhook OnePOS',
  description: 'Tài liệu API, Web SDK, Mobile SDK và Webhook OnePOS — tích hợp OnePOS với hệ thống doanh nghiệp.',
  alternates: { canonical: '/developers' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/developers`,
    title: 'Developer — API, SDK & Webhook OnePOS',
    description: 'Tài liệu API, Web SDK, Mobile SDK và Webhook OnePOS.',
  },
};

const features = [
  { icon: Code2, title: 'REST API', desc: 'API RESTful đầy đủ cho mọi thao tác — gọi, CRM, chat, báo cáo.' },
  { icon: Globe, title: 'Web SDK', desc: 'JavaScript SDK cho web — click-to-call, WebRTC, chat widget.' },
  { icon: Smartphone, title: 'Mobile SDK', desc: 'SDK cho iOS và Android — Softphone, push notification.' },
  { icon: Webhook, title: 'Webhook', desc: 'Nhận sự kiện realtime — cuộc gọi, tin nhắn, trạng thái.' },
];

const codeExample = `// Khởi tạo OnePOS SDK
import OnePOS from '@onepos/sdk';

const client = new OnePOS({
  apiKey: 'your-api-key',
});

// Gọi điện từ CRM
const call = await client.calls.create({
  from: 'extension-101',
  to: '0901234567',
});

// Lấy lịch sử cuộc gọi
const calls = await client.calls.list({
  from: '2026-01-01',
  to: '2026-01-31',
});

// Webhook: nhận sự kiện cuộc gọi
app.post('/webhook/call', (req, res) => {
  const { event, data } = req.body;
  if (event === 'call.answered') {
    console.log('Cuộc gọi được trả lời:', data);
  }
  res.json({ ok: true });
});`;

export default function DeveloperPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-navy-950 to-navy-900" />
        <div className="absolute inset-0 grid-pattern opacity-5" />
        <div className="absolute -top-20 right-0 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <div className="container-page relative">
          <div className="mx-auto max-w-3xl text-center text-white">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-sky-400">
              <Terminal className="h-3.5 w-3.5" /> Developer
            </span>
            <h1 className="mt-5 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl lg:leading-[1.1]">
              Tích hợp OnePOS với hệ thống của bạn
            </h1>
            <p className="mt-4 text-base text-navy-200 leading-relaxed">
              API, SDK và Webhook đầy đủ — kết nối OnePOS với CRM, ERP, website, e-commerce và bất kỳ hệ thống nào.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row justify-center">
              <Link href="/lien-he" className="inline-flex items-center justify-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-navy-950 transition-all hover:shadow-xl hover:scale-105">
                Liên hệ tư vấn <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/dung-thu" className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/10">
                Dùng thử miễn phí
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section-pad">
        <div className="container-page">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <div key={f.title} className="rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <f.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-foreground">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Code example */}
      <section className="section-pad bg-navy-950">
        <div className="container-page">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <span className="inline-block rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-sky-400">
                Code Example
              </span>
              <h2 className="mt-4 text-3xl font-bold text-white">Bắt đầu nhanh với OnePOS SDK</h2>
              <p className="mt-4 text-base text-navy-200 leading-relaxed">
                SDK OnePOS dễ tích hợp, tài liệu đầy đủ. Bắt đầu với vài dòng code.
              </p>
              <div className="mt-6 space-y-3">
                {[
                  { icon: Zap, text: 'Khởi tạo SDK trong vài phút' },
                  { icon: Zap, text: 'Click-to-Call chỉ với 1 dòng' },
                  { icon: Zap, text: 'Webhook realtime cho mọi sự kiện' },
                  { icon: Zap, text: 'Hỗ trợ REST API và GraphQL' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-sm text-navy-200">
                    <item.icon className="h-4 w-4 text-sky-400" />
                    {item.text}
                  </div>
                ))}
              </div>
            </div>
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-navy-950">
              <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
                <span className="h-3 w-3 rounded-full bg-red-500" />
                <span className="h-3 w-3 rounded-full bg-amber-500" />
                <span className="h-3 w-3 rounded-full bg-green-500" />
                <span className="ml-2 text-xs text-navy-400">example.ts</span>
              </div>
              <pre className="overflow-x-auto p-4 text-xs text-navy-100 leading-relaxed">
                <code>{codeExample}</code>
              </pre>
            </div>
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
