import type { Metadata } from 'next';
import Link from 'next/link';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Bảng giá — OnePOS',
  description: 'Bảng giá OnePOS cho Tổng đài Cloud, Call Center, CRM, Omnichannel, AI và Auto Call. Liên hệ tư vấn để nhận báo giá chi tiết.',
  alternates: { canonical: '/bang-gia' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/bang-gia`,
    title: 'Bảng giá — OnePOS',
    description: 'Bảng giá OnePOS cho Tổng đài Cloud, Call Center, CRM, Omnichannel, AI và Auto Call.',
  },
};

const pricingGroups = [
  {
    name: 'Tổng đài Cloud',
    plans: [
      { name: 'Starter', price: 'Liên hệ tư vấn', features: ['10 máy lẻ', 'IVR cơ bản', 'Call Recording', 'Call Forwarding', 'Mobile App'], popular: false },
      { name: 'Pro', price: 'Liên hệ tư vấn', features: ['30 máy lẻ', 'IVR nâng cao', 'Queue', 'Ring Group', 'Monitoring', 'Voicemail'], popular: true },
      { name: 'Enterprise', price: 'Liên hệ tư vấn', features: ['Không giới hạn máy lẻ', 'Tất cả tính năng Pro', 'SIP Trunk', 'Voice Brandname', 'API', 'Hỗ trợ 24/7'], popular: false },
    ],
  },
  {
    name: 'Call Center',
    plans: [
      { name: 'Starter', price: 'Liên hệ tư vấn', features: ['10 agent', 'Inbound/Outbound', 'Queue', 'Call Recording', 'Báo cáo cơ bản'], popular: false },
      { name: 'Pro', price: 'Liên hệ tư vấn', features: ['30 agent', 'Supervisor', 'Monitor/Whisper', 'Wallboard', 'KPI Dashboard'], popular: true },
      { name: 'Enterprise', price: 'Liên hệ tư vấn', features: ['Không giới hạn agent', 'Tất cả tính năng Pro', 'Barge', 'QA', 'API', 'SSO'], popular: false },
    ],
  },
  {
    name: 'CRM',
    plans: [
      { name: 'Starter', price: 'Liên hệ tư vấn', features: ['1,000 khách hàng', 'Lead Management', 'Pipeline', 'Activity', 'Click-to-Call'], popular: false },
      { name: 'Pro', price: 'Liên hệ tư vấn', features: ['10,000 khách hàng', 'Customer 360', 'Deal', 'Tự động hóa', 'Báo cáo nâng cao'], popular: true },
      { name: 'Enterprise', price: 'Liên hệ tư vấn', features: ['Không giới hạn', 'Tất cả tính năng Pro', 'API', 'Tích hợp ERP', 'SSO'], popular: false },
    ],
  },
  {
    name: 'Omnichannel',
    plans: [
      { name: 'Starter', price: 'Liên hệ tư vấn', features: ['2 kênh', 'Unified Inbox', 'Phân công cơ bản', 'Lịch sử chat'], popular: false },
      { name: 'Pro', price: 'Liên hệ tư vấn', features: ['5 kênh', 'Phân công tự động', 'Customer 360', 'Báo cáo đa kênh'], popular: true },
      { name: 'Enterprise', price: 'Liên hệ tư vấn', features: ['Tất cả kênh', 'Tất cả tính năng Pro', 'API', 'Webhook', 'SSO'], popular: false },
    ],
  },
  {
    name: 'AI',
    plans: [
      { name: 'Starter', price: 'Liên hệ tư vấn', features: ['AI Chatbot', '1 kênh', 'Knowledge Base', 'Human Handoff'], popular: false },
      { name: 'Pro', price: 'Liên hệ tư vấn', features: ['AI Voice Agent', 'AI Chatbot', 'Đa kênh', 'Intent Detection'], popular: true },
      { name: 'Enterprise', price: 'Liên hệ tư vấn', features: ['Tất cả tính năng Pro', 'AI Call Analytics', 'Call Scoring', 'API'], popular: false },
    ],
  },
  {
    name: 'Auto Call',
    plans: [
      { name: 'Starter', price: 'Liên hệ tư vấn', features: ['1 chiến dịch', 'Quay số tự động', 'Ghi âm', 'Báo cáo cơ bản'], popular: false },
      { name: 'Pro', price: 'Liên hệ tư vấn', features: ['5 chiến dịch', 'Lên lịch', 'Retry', 'AI Handoff'], popular: true },
      { name: 'Enterprise', price: 'Liên hệ tư vấn', features: ['Không giới hạn', 'Tất cả tính năng Pro', 'DNC List', 'API', 'Hỗ trợ 24/7'], popular: false },
    ],
  },
];

export default function PricingPage() {
  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <SectionHeading
            eyebrow="Bảng giá"
            title="Bảng giá OnePOS"
            description="Chọn gói phù hợp với doanh nghiệp của bạn. Liên hệ tư vấn để nhận báo giá chi tiết theo nhu cầu."
          />
        </div>
      </section>

      {pricingGroups.map((group) => (
        <section key={group.name} className="section-pad">
          <div className="container-page">
            <h2 className="text-2xl font-bold tracking-tight">{group.name}</h2>
            <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-3">
              {group.plans.map((plan) => (
                <div
                  key={plan.name}
                  className={`relative rounded-2xl border bg-card p-6 transition-all hover:shadow-xl ${
                    plan.popular ? 'border-primary shadow-lg' : 'border-border'
                  }`}
                >
                  {plan.popular && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                      Phổ biến nhất
                    </span>
                  )}
                  <h3 className="text-lg font-bold text-foreground">{plan.name}</h3>
                  <p className="mt-3 text-2xl font-bold text-foreground">{plan.price}</p>
                  <p className="text-xs text-muted-foreground">/tháng</p>
                  <ul className="mt-6 space-y-2.5">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-foreground/80">
                        <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/lien-he"
                    className={`mt-6 flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${
                      plan.popular
                        ? 'bg-primary text-primary-foreground hover:shadow-lg'
                        : 'border border-border text-foreground hover:bg-secondary'
                    }`}
                  >
                    Liên hệ tư vấn <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      ))}

      <CTASection
        title="Không chắc gói nào phù hợp?"
        description="Liên hệ với đội ngũ OnePOS để được tư vấn gói dịch vụ phù hợp nhất với nhu cầu và quy mô doanh nghiệp của bạn."
        primaryLabel="Đăng ký tư vấn"
        primaryHref="/lien-he"
        secondaryLabel="Dùng thử miễn phí"
        secondaryHref="/dung-thu"
      />
    </>
  );
}
