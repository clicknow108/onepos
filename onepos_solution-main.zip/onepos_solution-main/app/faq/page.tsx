import type { Metadata } from 'next';
import { FAQCategories, GlobalFAQ } from '@/content/faq';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'FAQ — Câu hỏi thường gặp',
  description: 'Câu hỏi thường gặp về OnePOS — Tổng đài Cloud, Call Center, CRM, Omnichannel, AI và tích hợp.',
  alternates: { canonical: '/faq' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/faq`,
    title: 'FAQ — Câu hỏi thường gặp',
    description: 'Câu hỏi thường gặp về OnePOS — Tổng đài Cloud, Call Center, CRM, Omnichannel, AI.',
  },
};

export default function FAQPage() {
  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: GlobalFAQ.map((f) => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: { '@type': 'Answer', text: f.answer },
    })),
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }} />

      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <SectionHeading
            eyebrow="FAQ"
            title="Câu hỏi thường gặp"
            description="Những câu hỏi doanh nghiệp thường hỏi về OnePOS."
          />
        </div>
      </section>

      <section className="pb-16 lg:pb-24">
        <div className="container-page">
          <div className="mx-auto max-w-3xl space-y-10">
            {FAQCategories.map((cat) => (
              <div key={cat.category}>
                <h2 className="text-xl font-bold text-foreground">{cat.category}</h2>
                <div className="mt-4 space-y-3">
                  {cat.items.map((faq) => (
                    <details key={faq.question} className="group rounded-xl border border-border bg-card p-5">
                      <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-foreground list-none">
                        {faq.question}
                        <span className="ml-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-transform group-open:rotate-45">+</span>
                      </summary>
                      <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                    </details>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
