import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight, CheckCircle2, Cloud, Zap, MessageSquare, Brain, Code2, Maximize2, Phone, PhoneCall, Bot, AudioLines, Users, Headphones, MessagesSquare, Network, Send, MessageSquareText, Workflow, Sparkles, Layers, Rocket, TrendingUp } from 'lucide-react';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { HeroDashboard } from '@/components/sections/hero-dashboard';
import { Products } from '@/content/products';
import { GlobalFAQ } from '@/content/faq';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: SiteConfig.title,
  description: SiteConfig.description,
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: SiteConfig.url,
    siteName: SiteConfig.name,
    title: SiteConfig.title,
    description: SiteConfig.description,
  },
};

const productIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Cloud, Headphones, MessageSquare, MessagesSquare, Users, PhoneCall, PhoneOutgoing: Phone, Bot, MessageCircleBot: MessageSquare, AudioLines, Network, MessageSquareText, Send,
};

const valueProps = [
  { icon: Cloud, label: 'Cloud', desc: 'Không cần hạ tầng' },
  { icon: Zap, label: 'Realtime', desc: 'Giám sát tức thì' },
  { icon: MessageSquare, label: 'Omnichannel', desc: 'Hợp nhất đa kênh' },
  { icon: Brain, label: 'AI Ready', desc: 'Sẵn sàng AI' },
  { icon: Code2, label: 'API First', desc: 'Dễ tích hợp' },
  { icon: Maximize2, label: 'Scalable', desc: 'Mở rộng linh hoạt' },
];

const journeySteps = [
  {
    num: '01',
    title: 'Thu hút',
    desc: 'Tiếp cận khách hàng qua nhiều kênh',
    items: ['Hotline', 'Website', 'Facebook', 'Zalo', 'TikTok', 'Marketing'],
    icon: Phone,
  },
  {
    num: '02',
    title: 'Tương tác',
    desc: 'Giao tiếp với khách hàng qua gọi và chat',
    items: ['Call Center', 'Chat', 'Live Chat', 'AI Chatbot'],
    icon: MessageSquare,
  },
  {
    num: '03',
    title: 'Chuyển đổi',
    desc: 'Quản lý và chốt cơ hội bán hàng',
    items: ['CRM', 'Lead', 'Telesales', 'Auto Call', 'Sales Pipeline'],
    icon: TrendingUp,
  },
  {
    num: '04',
    title: 'Chăm sóc',
    desc: 'Hỗ trợ và giữ chân khách hàng',
    items: ['Ticket', 'Workflow', 'AI', 'Customer 360', 'Analytics'],
    icon: CheckCircle2,
  },
];

const whyOnePOS = [
  { icon: Layers, title: 'Một nền tảng', desc: 'Call + CRM + Chat + AI trên cùng một hệ thống.' },
  { icon: Cloud, title: 'Cloud', desc: 'Không cần đầu tư phần cứng phức tạp.' },
  { icon: Rocket, title: 'Dễ triển khai', desc: 'Bắt đầu nhanh, không cần lắp đặt.' },
  { icon: Code2, title: 'API First', desc: 'Dễ tích hợp với hệ thống hiện có.' },
  { icon: Brain, title: 'AI Ready', desc: 'Sẵn sàng tích hợp AI mọi lúc.' },
  { icon: Maximize2, title: 'Có thể mở rộng', desc: 'Từ SME đến Enterprise.' },
];

const integrations = ['CRM', 'ERP', 'Website', 'E-commerce', 'POS', 'API', 'Webhook', 'Google', 'Microsoft', 'Zalo', 'Facebook'];

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden pt-12 pb-16 sm:pt-16 lg:pt-24 lg:pb-24">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-sky-50/50 via-background to-background" />
          <div className="absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-primary/5 blur-3xl" />
          <div className="absolute top-20 right-0 h-72 w-72 rounded-full bg-accent/5 blur-3xl" />
        </div>

        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2 lg:gap-8">
            <div className="text-center lg:text-left">
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-semibold text-primary">
                <Sparkles className="h-3.5 w-3.5" />
                Nền tảng kết nối khách hàng cho doanh nghiệp
              </span>
              <h1 className="mt-5 text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl lg:leading-[1.05]">
                Một nền tảng.
                <br />
                <span className="text-gradient">Kết nối mọi khách hàng.</span>
              </h1>
              <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg leading-relaxed lg:mx-0">
                OnePOS hợp nhất Tổng đài, Call Center, CRM, Omnichannel và AI trên một nền tảng duy nhất — giúp doanh nghiệp bán hàng tốt hơn, chăm sóc khách hàng nhanh hơn và vận hành hiệu quả hơn.
              </p>
              <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
                <Link href="/dung-thu" className="group inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:shadow-xl hover:shadow-primary/30 hover:scale-105 sm:w-auto">
                  Dùng thử miễn phí
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
                <Link href="/lien-he" className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-all hover:bg-secondary sm:w-auto">
                  Đăng ký tư vấn
                </Link>
              </div>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-muted-foreground lg:justify-start">
                <span className="flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-green-500" /> Không cần phần cứng</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-green-500" /> Triển khai nhanh</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-green-500" /> Mở rộng linh hoạt</span>
              </div>
            </div>

            <div className="relative mx-auto w-full max-w-lg lg:max-w-none">
              <HeroDashboard />
            </div>
          </div>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section className="border-y border-border bg-secondary/30 py-12">
        <div className="container-page">
          <p className="text-center text-sm font-medium text-muted-foreground">
            Được xây dựng cho doanh nghiệp Việt Nam
          </p>
          <div className="mt-8 grid grid-cols-2 items-center gap-x-8 gap-y-6 sm:grid-cols-3 lg:grid-cols-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center justify-center rounded-lg border border-dashed border-border bg-background/50 px-4 py-3 text-sm font-semibold text-muted-foreground/60">
                Customer Logo {String(i + 1).padStart(2, '0')}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* VALUE PROPS */}
      <section className="section-pad">
        <div className="container-page">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {valueProps.map((v) => (
              <div key={v.label} className="rounded-2xl border border-border bg-card p-5 text-center transition-all hover:shadow-lg hover:border-primary/20">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <v.icon className="h-6 w-6 text-primary" />
                </div>
                <p className="mt-3 text-sm font-bold text-foreground">{v.label}</p>
                <p className="mt-1 text-xs text-muted-foreground">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ONE PLATFORM JOURNEY */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <SectionHeading
            eyebrow="Một nền tảng"
            title="Một nền tảng. Toàn bộ hành trình khách hàng."
            description="Từ cuộc gọi đầu tiên đến chăm sóc sau bán, OnePOS giúp doanh nghiệp quản lý toàn bộ hành trình khách hàng trên một hệ thống duy nhất."
          />
          <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
            {journeySteps.map((step, i) => (
              <div key={step.num} className="group relative">
                {i < journeySteps.length - 1 && (
                  <div className="absolute right-0 top-8 hidden h-px w-full translate-x-full bg-gradient-to-r from-primary/40 to-transparent lg:block" />
                )}
                <div className="relative rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                  <div className="flex items-center justify-between">
                    <span className="text-3xl font-bold text-primary/20">{step.num}</span>
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                      <step.icon className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                  <h3 className="mt-4 text-lg font-bold text-foreground">{step.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{step.desc}</p>
                  <ul className="mt-4 space-y-1.5">
                    {step.items.map((item) => (
                      <li key={item} className="flex items-center gap-2 text-xs text-foreground/70">
                        <span className="h-1 w-1 rounded-full bg-primary" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCT ECOSYSTEM */}
      <section className="section-pad">
        <div className="container-page">
          <SectionHeading
            eyebrow="Hệ sinh thái"
            title="Tất cả công cụ Sales & CSKH trong một hệ sinh thái"
            description="OnePOS cung cấp đầy đủ công cụ từ tổng đài, call center, CRM, telesales đến AI — trên một nền tảng duy nhất."
          />
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Products.slice(0, 10).map((p) => {
              const Icon = productIcons[p.icon] || Cloud;
              return (
                <Link
                  key={p.slug}
                  href={`/san-pham/${p.slug}`}
                  className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20 hover:-translate-y-1"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                      <Icon className="h-5 w-5 text-primary group-hover:text-primary-foreground transition-colors" />
                    </div>
                    <h3 className="text-lg font-bold text-foreground">{p.shortName || p.name}</h3>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{p.tagline}</p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {p.features.slice(0, 4).map((f) => (
                      <span key={f.label} className="rounded-md bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
                        {f.label}
                      </span>
                    ))}
                    {p.features.length > 4 && (
                      <span className="rounded-md bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
                        +{p.features.length - 4}
                      </span>
                    )}
                  </div>
                  <div className="mt-auto pt-4">
                    <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                      Khám phá <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* CLOUD PBX SECTION */}
      <section className="section-pad bg-navy-950 text-white relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-5" />
        <div className="absolute -right-20 top-0 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <div className="container-page relative">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="inline-block rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-sky-400">
                Cloud PBX
              </span>
              <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
                Tổng đài Cloud — làm việc ở bất kỳ đâu
              </h2>
              <p className="mt-4 text-base text-navy-200 leading-relaxed">
                Triển khai tổng đài doanh nghiệp trên Cloud, không cần đầu tư phần cứng. Agent làm việc trên trình duyệt, mobile hoặc IP Phone — ở văn phòng hay tại nhà.
              </p>
              <div className="mt-6 grid grid-cols-2 gap-3">
                {['IVR', 'Ring Group', 'Queue', 'Call Recording', 'Call Forwarding', 'Extension', 'Voicemail', 'Call Parking', 'Monitoring'].map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-navy-200">
                    <CheckCircle2 className="h-4 w-4 text-sky-400 shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/san-pham/tong-dai-cloud" className="group mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-navy-950 transition-all hover:shadow-xl hover:gap-3">
                Xem giải pháp Tổng đài Cloud
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="relative">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-xl">
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Cuộc gọi hoạt động', value: '12', color: 'text-green-400' },
                    { label: 'Máy lẻ online', value: '24/30', color: 'text-sky-400' },
                    { label: 'Hàng đợi', value: '3', color: 'text-amber-400' },
                    { label: 'Voicemail', value: '5', color: 'text-purple-400' },
                  ].map((s) => (
                    <div key={s.label} className="rounded-xl border border-white/10 bg-white/5 p-3">
                      <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                      <p className="text-xs text-navy-300">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 rounded-xl border border-white/10 bg-white/5 p-3">
                  <p className="mb-2 text-xs font-semibold text-white">Lưu lượng cuộc gọi 24h</p>
                  <div className="flex h-20 items-end gap-1">
                    {[40, 55, 68, 72, 85, 92, 78, 65, 58, 70, 82, 88].map((v, i) => (
                      <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-sky-500/40 to-sky-400" style={{ height: `${v}%` }} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CALL CENTER SECTION */}
      <section className="section-pad">
        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div className="order-2 lg:order-1">
              <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground">Call Center Wallboard</h3>
                  <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">SLA 96%</span>
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {[
                    { label: 'Agent online', value: '18/20', color: 'text-green-500' },
                    { label: 'Cuộc gọi chờ', value: '4', color: 'text-amber-500' },
                    { label: 'Tỷ lệ trả lời', value: '96%', color: 'text-sky-500' },
                    { label: 'Bỏ cuộc gọi', value: '2', color: 'text-red-500' },
                  ].map((s) => (
                    <div key={s.label} className="rounded-xl border border-border bg-secondary/30 p-3">
                      <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 space-y-1.5">
                  {[
                    { name: 'Agent 01', status: 'Đang gọi', time: '3:24', color: 'bg-green-500' },
                    { name: 'Agent 02', status: 'Sẵn sàng', time: '—', color: 'bg-sky-500' },
                    { name: 'Agent 03', status: 'Đang gọi', time: '1:52', color: 'bg-green-500' },
                    { name: 'Agent 04', status: 'Nghỉ', time: '—', color: 'bg-amber-500' },
                  ].map((a) => (
                    <div key={a.name} className="flex items-center gap-3 rounded-lg border border-border bg-secondary/20 px-3 py-2">
                      <span className={`h-2 w-2 rounded-full ${a.color}`} />
                      <span className="flex-1 text-xs font-medium text-foreground">{a.name}</span>
                      <span className="text-xs text-muted-foreground">{a.status}</span>
                      <span className="text-xs text-foreground">{a.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
                Call Center
              </span>
              <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
                Biến đội ngũ Sales & CSKH thành một Call Center chuyên nghiệp
              </h2>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">
                Quản lý agent, hàng đợi, giám sát và báo cáo — đầy đủ tính năng Call Center chuyên nghiệp trên Cloud.
              </p>
              <div className="mt-6 grid grid-cols-2 gap-3">
                {['Inbound / Outbound', 'Queue', 'Agent', 'Supervisor', 'Call Monitoring', 'Whisper', 'Barge', 'Recording', 'Reporting', 'QA'].map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-foreground/80">
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/san-pham/call-center" className="group mt-8 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:shadow-lg hover:gap-3">
                Khám phá Call Center <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* OMNICHANNEL SECTION */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
                Omnichannel
              </span>
              <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
                Mọi cuộc trò chuyện. Một nơi duy nhất.
              </h2>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">
                Hợp nhất Facebook, Zalo, Website, WhatsApp và Email vào một inbox duy nhất — agent không cần chuyển qua lại giữa nhiều phần mềm.
              </p>
              <div className="mt-6 space-y-3">
                {[
                  { channel: 'Facebook Messenger', icon: MessageSquare },
                  { channel: 'Zalo', icon: MessageSquare },
                  { channel: 'Live Chat', icon: MessageSquare },
                  { channel: 'Email', icon: MessageSquare },
                  { channel: 'WhatsApp', icon: MessageSquare },
                ].map((c) => (
                  <div key={c.channel} className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-2.5">
                    <c.icon className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium text-foreground">{c.channel}</span>
                  </div>
                ))}
              </div>
              <Link href="/san-pham/omnichannel" className="group mt-8 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:shadow-lg hover:gap-3">
                Khám phá Omnichannel <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-foreground">Unified Inbox</h3>
                <span className="rounded-full bg-accent/10 px-2.5 py-1 text-xs font-medium text-accent">28 tin chờ</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { name: 'Facebook', count: 12, color: 'text-blue-600', bg: 'bg-blue-50' },
                  { name: 'Zalo', count: 8, color: 'text-sky-600', bg: 'bg-sky-50' },
                  { name: 'Live Chat', count: 5, color: 'text-green-600', bg: 'bg-green-50' },
                  { name: 'Email', count: 3, color: 'text-amber-600', bg: 'bg-amber-50' },
                ].map((c) => (
                  <div key={c.name} className="rounded-lg border border-border bg-secondary/30 p-2.5 text-center">
                    <p className={`text-base font-bold ${c.color}`}>{c.count}</p>
                    <p className="text-[10px] text-muted-foreground">{c.name}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 space-y-1.5">
                {[
                  { name: 'Nguyễn Văn A', msg: 'Cho tôi hỏi giá gói Call Center', time: '2 phút', unread: true },
                  { name: 'Trần Thị B', msg: 'Cảm ơn bạn đã tư vấn', time: '15 phút', unread: true },
                  { name: 'Le Văn C', msg: 'Tôi cần hỗ trợ kỹ thuật', time: '1 giờ', unread: false },
                ].map((c, i) => (
                  <div key={i} className={`flex items-center gap-2 rounded-lg border px-3 py-2 ${c.unread ? 'border-primary/30 bg-primary/5' : 'border-border bg-secondary/20'}`}>
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-xs font-semibold text-foreground">{c.name[0]}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{c.msg}</p>
                    </div>
                    {c.unread && <span className="h-1.5 w-1.5 rounded-full bg-primary" />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CRM SECTION */}
      <section className="section-pad">
        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div className="order-2 lg:order-1">
              <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground">CRM — Customer 360</h3>
                  <span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">Tổng quan</span>
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {[
                    { label: 'Khách hàng', value: '1,284', color: 'text-sky-500' },
                    { label: 'Lead mới', value: '86', color: 'text-amber-500' },
                    { label: 'Deal mở', value: '32', color: 'text-green-500' },
                    { label: 'Tỷ lệ chốt', value: '24%', color: 'text-purple-500' },
                  ].map((s) => (
                    <div key={s.label} className="rounded-xl border border-border bg-secondary/30 p-3">
                      <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 rounded-xl border border-border bg-secondary/30 p-3">
                  <p className="mb-2 text-xs font-semibold text-foreground">Sales Pipeline</p>
                  <div className="space-y-1.5">
                    {[
                      { stage: 'Tiếp xúc', count: 120, color: 'bg-sky-400' },
                      { stage: 'Tư vấn', count: 64, color: 'bg-sky-500' },
                      { stage: 'Báo giá', count: 32, color: 'bg-primary' },
                      { stage: 'Chốt', count: 12, color: 'bg-green-500' },
                    ].map((p) => (
                      <div key={p.stage} className="flex items-center gap-2">
                        <span className="w-16 text-xs text-muted-foreground">{p.stage}</span>
                        <div className="flex-1 h-5 rounded bg-secondary overflow-hidden">
                          <div className={`h-full ${p.color} rounded flex items-center px-1.5`} style={{ width: `${(p.count / 120) * 100}%` }}>
                            <span className="text-[10px] font-medium text-white">{p.count}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
                CRM
              </span>
              <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
                Customer 360° — hiểu khách hàng trước khi gọi
              </h2>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">
                Không còn dữ liệu khách hàng nằm rải rác ở nhiều phần mềm. OnePOS CRM lưu trữ toàn bộ thông tin, lịch sử tương tác và giao dịch trên một hệ thống.
              </p>
              <div className="mt-6 grid grid-cols-2 gap-3">
                {['Customer profile', 'Calls', 'Messages', 'Deals', 'Tickets', 'Notes', 'Activities', 'Timeline'].map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-foreground/80">
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/san-pham/crm" className="group mt-8 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:shadow-lg hover:gap-3">
                Khám phá CRM <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* TELESALES SECTION */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
                Telesales
              </span>
              <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
                Bàn làm việc dành riêng cho Telesales
              </h2>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">
                Agent không cần chuyển qua nhiều phần mềm để gọi và quản lý khách hàng. Telesales Workspace tích hợp danh sách lead, click-to-call, kịch bản, ghi chú và KPI trên một màn hình.
              </p>
              <div className="mt-6 grid grid-cols-2 gap-3">
                {['Lead list', 'Click-to-Call', 'Call Script', 'Call History', 'Notes', 'Tasks', 'Pipeline', 'KPI'].map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-foreground/80">
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/san-pham/telesales" className="group mt-8 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:shadow-lg hover:gap-3">
                Khám phá Telesales <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-foreground">Telesales Workspace</h3>
                <span className="flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-600">
                  <PhoneCall className="h-3 w-3" /> Đang gọi
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  { label: 'Đã gọi', value: '42' },
                  { label: 'Liên lạc', value: '28' },
                  { label: 'Chốt', value: '7' },
                  { label: 'Thời gian TB', value: '4:12' },
                ].map((k) => (
                  <div key={k.label} className="rounded-xl border border-border bg-secondary/30 p-3">
                    <p className="text-lg font-bold text-foreground">{k.value}</p>
                    <p className="text-xs text-muted-foreground">{k.label}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 space-y-1.5">
                {[
                  { name: 'Nguyễn Văn A', phone: '0901 234 567', status: 'calling' },
                  { name: 'Trần Thị B', phone: '0902 345 678', status: 'pending' },
                  { name: 'Le Văn C', phone: '0903 456 789', status: 'called' },
                ].map((l, i) => (
                  <div key={i} className="flex items-center gap-3 rounded-lg border border-border bg-secondary/20 px-3 py-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground">{l.name}</p>
                      <p className="text-[10px] text-muted-foreground">{l.phone}</p>
                    </div>
                    {l.status === 'calling' && <span className="rounded-md bg-green-500 px-2 py-0.5 text-[10px] font-medium text-white">Đang gọi</span>}
                    {l.status === 'pending' && <span className="rounded-md bg-primary px-2 py-0.5 text-[10px] font-medium text-primary-foreground">Gọi</span>}
                    {l.status === 'called' && <span className="text-[10px] text-green-600">Đã gọi</span>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI SECTION */}
      <section className="section-pad">
        <div className="container-page">
          <SectionHeading
            eyebrow="AI"
            title="AI giúp doanh nghiệp tự động hóa giao tiếp với khách hàng"
            description="AI Voice Agent, AI Chatbot và AI Call Analytics — giúp doanh nghiệp phục vụ khách hàng 24/7 và nâng cao chất lượng phục vụ."
          />
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Bot, title: 'AI Voice Agent', desc: 'AI nghe và nói chuyện với khách hàng bằng giọng nói tự nhiên.' },
              { icon: MessageSquare, title: 'AI Chatbot', desc: 'AI trả lời khách hàng 24/7 trên website, Zalo và Facebook.' },
              { icon: AudioLines, title: 'AI Call Summary', desc: 'Tự động tóm tắt nội dung cuộc gọi sau khi kết thúc.' },
              { icon: CheckCircle2, title: 'AI Call Scoring', desc: 'Đánh giá chất lượng cuộc gọi dựa trên tiêu chí tùy chỉnh.' },
            ].map((card) => (
              <div key={card.title} className="group rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-accent/10">
                  <card.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-foreground">{card.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AUTO CALL SECTION */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <SectionHeading
            eyebrow="Auto Call"
            title="Tự động hóa chiến dịch gọi ra"
            description="Auto Call tự động quay số theo danh sách khách hàng, chuyển cho AI hoặc agent khi khách bắt máy, ghi âm và báo cáo toàn bộ chiến dịch."
          />
          <div className="mt-12 flex flex-wrap items-center justify-center gap-2">
            {['Danh sách khách hàng', 'Campaign', 'Call Queue', 'Auto Dial', 'AI / Agent', 'Recording', 'Report'].map((step, i, arr) => (
              <div key={step} className="flex items-center gap-2">
                <div className="rounded-xl border border-border bg-card px-4 py-3 text-sm font-semibold text-foreground shadow-sm">
                  {step}
                </div>
                {i < arr.length - 1 && <ArrowRight className="h-4 w-4 text-primary" />}
              </div>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/san-pham/auto-call" className="group inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:shadow-lg hover:gap-3">
              Khám phá Auto Call <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* TELECOM SERVICES */}
      <section className="section-pad">
        <div className="container-page">
          <SectionHeading
            eyebrow="Viễn thông"
            title="Hạ tầng liên lạc doanh nghiệp"
            description="Đầu số tổng đài, SIP Trunk, Voice Brandname, SMS Brandname và Zalo ZNS — đầy đủ hạ tầng viễn thông cho doanh nghiệp."
          />
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Phone, title: 'Đầu số tổng đài', items: ['1900', '1800', 'Fixed Number', 'Mobile SIP'] },
              { icon: Network, title: 'SIP Trunk', desc: 'Kết nối hệ thống tổng đài với nhà cung cấp viễn thông.' },
              { icon: PhoneCall, title: 'Voice Brandname', desc: 'Hiển thị thương hiệu khi doanh nghiệp gọi ra nếu dịch vụ được hỗ trợ.' },
              { icon: MessageSquareText, title: 'SMS Brandname', desc: 'Gửi SMS thương hiệu đến khách hàng.' },
              { icon: Send, title: 'Zalo ZNS', desc: 'Gửi thông báo và chăm sóc khách hàng qua Zalo theo chính sách của nền tảng.' },
            ].map((card) => (
              <div key={card.title} className="rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10">
                  <card.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-foreground">{card.title}</h3>
                {card.desc && <p className="mt-2 text-sm text-muted-foreground">{card.desc}</p>}
                {card.items && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {card.items.map((item) => (
                      <span key={item} className="rounded-md bg-secondary px-2 py-1 text-xs font-medium text-muted-foreground">{item}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INTEGRATION */}
      <section className="section-pad bg-navy-950 text-white relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-5" />
        <div className="container-page relative">
          <SectionHeading
            eyebrow="Tích hợp"
            title={<span className="text-white">Kết nối OnePOS với hệ thống bạn đang sử dụng</span>}
            description="OnePOS cung cấp API, SDK và Webhook để tích hợp với CRM, ERP, website, e-commerce và nhiều hệ thống khác."
            className="[&_p]:text-navy-300 [&_span]:bg-white/10 [&_span]:text-sky-400"
          />
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            {integrations.map((item) => (
              <div key={item} className="rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-semibold text-white backdrop-blur-sm transition-colors hover:bg-white/10">
                {item}
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link href="/developers" className="group inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-navy-950 transition-all hover:shadow-xl hover:gap-3">
              Xem tài liệu API <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* WHY ONEPOS */}
      <section className="section-pad">
        <div className="container-page">
          <SectionHeading
            eyebrow="Tại sao chọn OnePOS"
            title="Tại sao doanh nghiệp chọn OnePOS?"
            description="OnePOS không chỉ là phần mềm tổng đài — đây là nền tảng kết nối và tự động hóa giao tiếp khách hàng cho doanh nghiệp."
          />
          <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {whyOnePOS.map((item) => (
              <div key={item.title} className="rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-xl hover:border-primary/20">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-accent/10">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-foreground">{item.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-page">
          <SectionHeading
            eyebrow="FAQ"
            title="Câu hỏi thường gặp"
            description="Những câu hỏi doanh nghiệp thường hỏi về OnePOS."
          />
          <div className="mx-auto mt-10 max-w-3xl space-y-3">
            {GlobalFAQ.slice(0, 8).map((faq) => (
              <details key={faq.question} className="group rounded-xl border border-border bg-card p-5">
                <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-foreground list-none">
                  {faq.question}
                  <span className="ml-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-transform group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
              </details>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/faq" className="text-sm font-semibold text-primary hover:underline">
              Xem tất cả câu hỏi →
            </Link>
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
