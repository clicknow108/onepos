import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight, Clock } from 'lucide-react';
import { BlogPosts, BlogCategories } from '@/content/blog';
import { SectionHeading } from '@/components/shared/section-heading';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export const metadata: Metadata = {
  title: 'Blog — Kiến thức Tổng đài, Call Center, CRM & AI',
  description: 'Blog OnePOS chia sẻ kiến thức về tổng đài Cloud, Call Center, Contact Center, CRM, Telesales, Omnichannel, AI và công nghệ cho doanh nghiệp Việt Nam.',
  alternates: { canonical: '/blog' },
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: `${SiteConfig.url}/blog`,
    title: 'Blog — Kiến thức Tổng đài, Call Center, CRM & AI',
    description: 'Blog OnePOS chia sẻ kiến thức về tổng đài Cloud, Call Center, CRM, Telesales, Omnichannel, AI.',
  },
};

export default function BlogPage() {
  const [featured, ...rest] = BlogPosts;

  return (
    <>
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-sky-50/50 to-background" />
        <div className="container-page">
          <SectionHeading
            eyebrow="Blog"
            title="Kiến thức Tổng đài, Call Center, CRM & AI"
            description="Chia sẻ kiến thức và hướng dẫn về công nghệ chăm sóc khách hàng cho doanh nghiệp Việt Nam."
          />

          {/* Categories */}
          <div className="mt-8 flex flex-wrap justify-center gap-2">
            {BlogCategories.map((cat) => (
              <span key={cat} className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground">
                {cat}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Featured post */}
      <section className="pb-8">
        <div className="container-page">
          <Link href={`/blog/${featured.slug}`} className="group block overflow-hidden rounded-2xl border border-border bg-card transition-all hover:shadow-xl">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="relative aspect-video overflow-hidden bg-gradient-to-br from-primary/10 to-accent/10 lg:aspect-auto">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="dot-pattern h-full w-full opacity-30" />
                </div>
                <div className="absolute bottom-4 left-4 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Nổi bật
                </div>
              </div>
              <div className="p-8">
                <span className="text-xs font-semibold text-primary">{featured.category}</span>
                <h2 className="mt-3 text-2xl font-bold text-foreground group-hover:text-primary transition-colors">{featured.title}</h2>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{featured.excerpt}</p>
                <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                  <span>{new Date(featured.date).toLocaleDateString('vi-VN')}</span>
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {featured.readingTime}</span>
                </div>
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* All posts */}
      <section className="section-pad">
        <div className="container-page">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {rest.map((post) => (
              <Link key={post.slug} href={`/blog/${post.slug}`} className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:shadow-xl hover:border-primary/20">
                <div className="relative aspect-video overflow-hidden bg-gradient-to-br from-primary/10 to-accent/10">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="dot-pattern h-full w-full opacity-30" />
                  </div>
                  <span className="absolute top-3 left-3 rounded-full bg-background/80 px-2.5 py-1 text-xs font-medium text-foreground backdrop-blur-sm">
                    {post.category}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="text-base font-bold text-foreground group-hover:text-primary transition-colors">{post.title}</h3>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground leading-relaxed">{post.excerpt}</p>
                  <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground">
                    <span>{new Date(post.date).toLocaleDateString('vi-VN')}</span>
                    <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {post.readingTime}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
