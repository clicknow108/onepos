import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Clock, ChevronRight, ArrowRight } from 'lucide-react';
import { BlogPosts, getPost } from '@/content/blog';
import { CTASection } from '@/components/shared/cta-section';
import { SiteConfig } from '@/content/site-config';

export async function generateStaticParams() {
  return BlogPosts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = getPost(params.slug);
  if (!post) return {};
  return {
    title: post.seoTitle,
    description: post.metaDescription,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      type: 'article',
      locale: 'vi_VN',
      url: `${SiteConfig.url}/blog/${post.slug}`,
      title: post.seoTitle,
      description: post.metaDescription,
      publishedTime: post.date,
    },
  };
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = getPost(params.slug);
  if (!post) notFound();

  const related = BlogPosts.filter((p) => p.slug !== post.slug && p.category === post.category).slice(0, 3);

  const articleJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    description: post.metaDescription,
    datePublished: post.date,
    author: { '@type': 'Organization', name: 'OnePOS' },
    publisher: { '@type': 'Organization', name: 'OnePOS' },
  };

  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: post.faqs.map((f) => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: { '@type': 'Answer', text: f.answer },
    })),
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleJsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }} />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-secondary/30">
        <div className="container-page py-3">
          <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Link href="/" className="hover:text-foreground">Trang chủ</Link>
            <ChevronRight className="h-3 w-3" />
            <Link href="/blog" className="hover:text-foreground">Blog</Link>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground line-clamp-1">{post.title}</span>
          </nav>
        </div>
      </div>

      {/* Article header */}
      <section className="py-12 lg:py-16">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <span className="text-xs font-semibold text-primary">{post.category}</span>
            <h1 className="mt-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:leading-[1.15]">
              {post.title}
            </h1>
            <p className="mt-4 text-base text-muted-foreground leading-relaxed">{post.excerpt}</p>
            <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
              <span>{new Date(post.date).toLocaleDateString('vi-VN')}</span>
              <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {post.readingTime}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Article content */}
      <section className="pb-16">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <div className="prose prose-sm sm:prose-base max-w-none">
              {post.content.split('\n').map((line, i) => {
                if (line.startsWith('## ')) {
                  return <h2 key={i} className="mt-8 text-2xl font-bold text-foreground">{line.replace('## ', '')}</h2>;
                }
                if (line.startsWith('### ')) {
                  return <h3 key={i} className="mt-6 text-xl font-bold text-foreground">{line.replace('### ', '')}</h3>;
                }
                if (line.startsWith('| ')) {
                  return null;
                }
                if (line.startsWith('- ')) {
                  return <li key={i} className="ml-4 text-foreground/80">{line.replace('- ', '')}</li>;
                }
                if (line.startsWith('1. ') || line.match(/^\d+\. /)) {
                  return <p key={i} className="mt-2 text-foreground/80">{line}</p>;
                }
                if (line.trim() === '') {
                  return <div key={i} className="h-4" />;
                }
                return <p key={i} className="mt-3 text-foreground/80 leading-relaxed">{line}</p>;
              })}
            </div>

            {/* FAQ */}
            <div className="mt-12 rounded-2xl border border-border bg-secondary/30 p-6">
              <h2 className="text-xl font-bold text-foreground">Câu hỏi thường gặp</h2>
              <div className="mt-4 space-y-3">
                {post.faqs.map((faq) => (
                  <details key={faq.question} className="group rounded-xl border border-border bg-card p-4">
                    <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-foreground list-none">
                      {faq.question}
                      <span className="ml-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-transform group-open:rotate-45">+</span>
                    </summary>
                    <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="section-pad bg-gradient-to-b from-secondary/30 to-background">
          <div className="container-page">
            <h2 className="text-2xl font-bold tracking-tight">Bài viết liên quan</h2>
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
              {related.map((p) => (
                <Link key={p.slug} href={`/blog/${p.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-all hover:shadow-xl hover:border-primary/20">
                  <span className="text-xs font-semibold text-primary">{p.category}</span>
                  <h3 className="mt-2 text-base font-bold text-foreground group-hover:text-primary transition-colors">{p.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.excerpt}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                    Đọc tiếp <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <CTASection />
    </>
  );
}
