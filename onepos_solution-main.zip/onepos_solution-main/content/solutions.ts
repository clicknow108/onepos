export type SolutionDetail = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  type: 'need' | 'industry' | 'scale';
  painPoints: string[];
  solutions: { title: string; description: string }[];
  products: string[];
  workflow: { step: string; description: string }[];
  features: string[];
  useCases: { title: string; description: string }[];
};

export const Solutions: SolutionDetail[] = [
  {
    slug: 'telesales',
    name: 'Telesales',
    tagline: 'Tăng hiệu suất đội ngũ telesales với không gian làm việc chuyên biệt',
    description:
      'Giải pháp telesales OnePOS giúp đội ngũ gọi điện bán hàng làm việc hiệu quả hơn — gọi nhanh hơn, quản lý khách hàng tốt hơn và đo lường KPI chính xác.',
    type: 'need',
    painPoints: [
      'Agent phải bấm số thủ công, tốn thời gian và dễ sai',
      'Dữ liệu khách hàng nằm rải rác ở nhiều nơi',
      'Không theo dõi được KPI agent realtime',
      'Kịch bản gọi không đồng nhất giữa các agent',
      'Khó đo lường tỷ lệ chuyển đổi theo chiến dịch',
    ],
    solutions: [
      { title: 'Click-to-Call', description: 'Agent gọi điện chỉ với một click, không cần bấm số thủ công.' },
      { title: 'Telesales Workspace', description: 'Danh sách lead, kịch bản, ghi chú, nhiệm vụ trên một màn hình.' },
      { title: 'Auto Call', description: 'Tự động quay số theo danh sách, agent chỉ xử lý khi khách bắt máy.' },
      { title: 'KPI Dashboard', description: 'Số cuộc gọi, thời gian gọi, tỷ lệ chốt — realtime.' },
    ],
    products: ['telesales', 'crm', 'auto-call', 'tong-dai-cloud'],
    workflow: [
      { step: 'Nhập danh sách lead', description: 'Tải lên danh sách khách hàng cần gọi' },
      { step: 'Phân công', description: 'Phân lead cho từng agent hoặc chiến dịch' },
      { step: 'Gọi tự động', description: 'Agent click-to-call hoặc Auto Call quay số' },
      { step: 'Ghi chú & phân loại', description: 'Ghi kết quả, phân loại khách hàng' },
      { step: 'Báo cáo KPI', description: 'Đo lường hiệu suất theo agent và chiến dịch' },
    ],
    features: ['Click-to-Call', 'Call Script', 'Lead Management', 'Auto Call', 'KPI Dashboard', 'Call Recording', 'Campaign', 'Pipeline'],
    useCases: [
      { title: 'Bán bảo hiểm', description: 'Đội ngũ telesales gọi khách hàng giới thiệu sản phẩm bảo hiểm.' },
      { title: 'Bán B2B', description: 'Sales gọi doanh nghiệp giới thiệu giải pháp SaaS.' },
      { title: 'Khảo sát thị trường', description: 'Gọi khách hàng thu thập phản hồi sản phẩm.' },
    ],
  },
  {
    slug: 'cham-soc-khach-hang',
    name: 'Chăm sóc khách hàng',
    tagline: 'Phục vụ khách hàng trên mọi kênh, 24/7',
    description:
      'Giải pháp chăm sóc khách hàng OnePOS giúp doanh nghiệp tiếp nhận và xử lý yêu cầu khách hàng trên mọi kênh — thoại, chat, Zalo, Facebook, email — trên một hệ thống duy nhất.',
    type: 'need',
    painPoints: [
      'Khách hàng liên lạc qua nhiều kênh, khó quản lý',
      'Agent không có context lịch sử khách hàng',
      'Tỷ lệ bỏ cuộc gọi chờ cao',
      'Không đo lường được chất lượng phục vụ',
      'Khó mở rộng đội ngũ CSKH',
    ],
    solutions: [
      { title: 'Omnichannel Inbox', description: 'Mọi kênh chat và gọi trên một inbox duy nhất.' },
      { title: 'Customer 360', description: 'Lịch sử tương tác đầy đủ trước khi trả lời.' },
      { title: 'Ticket System', description: 'Quản lý yêu cầu hỗ trợ có deadline và người phụ trách.' },
      { title: 'AI Chatbot', description: 'AI trả lời câu hỏi phổ biến 24/7.' },
    ],
    products: ['contact-center', 'omnichannel', 'crm', 'ai-chatbot'],
    workflow: [
      { step: 'Tiếp nhận', description: 'Khách liên lạc qua gọi, chat, Zalo, Facebook' },
      { step: 'Phân công', description: 'Tự động phân cho agent phù hợp' },
      { step: 'Xử lý', description: 'Agent xem lịch sử, trả lời hoặc tạo ticket' },
      { step: 'Theo dõi', description: 'Ticket có deadline, trạng thái rõ ràng' },
      { step: 'Đánh giá', description: 'Đo lường CSAT và chất lượng phục vụ' },
    ],
    features: ['Omnichannel', 'Ticket', 'Customer 360', 'AI Chatbot', 'Call Recording', 'QA', 'SLA', 'CSAT'],
    useCases: [
      { title: 'Hotline hỗ trợ', description: 'Khách gọi đến hỏi về sản phẩm, đổi trả, bảo hành.' },
      { title: 'Chat hỗ trợ', description: 'Khách nhắn tin trên website, Zalo, Facebook.' },
      { title: 'Email CSKH', description: 'Xử lý email yêu cầu hỗ trợ có quy trình rõ ràng.' },
    ],
  },
  {
    slug: 'call-center',
    name: 'Call Center',
    tagline: 'Biến đội ngũ của bạn thành Call Center chuyên nghiệp',
    description:
      'Giải pháp Call Center OnePOS cung cấp đầy đủ tính năng quản lý agent, hàng đợi, giám sát và báo cáo — triển khai nhanh trên Cloud, không cần đầu tư hạ tầng.',
    type: 'need',
    painPoints: [
      'Không giám sát được agent realtime',
      'Tỷ lệ bỏ cuộc gọi chờ cao',
      'Không đo lường được SLA',
      'Khó đào tạo và đánh giá agent',
      'Báo cáo thủ công, tốn thời gian',
    ],
    solutions: [
      { title: 'Queue Management', description: 'Hàng đợi thông minh, giảm thời gian chờ.' },
      { title: 'Supervisor Tools', description: 'Nghe, thì thầm, can thiệp cuộc gọi realtime.' },
      { title: 'Wallboard', description: 'Bảng điều khiển realtime với đầy đủ chỉ số.' },
      { title: 'AI Call Analytics', description: 'Tự động đánh giá chất lượng cuộc gọi.' },
    ],
    products: ['call-center', 'tong-dai-cloud', 'ai-call-analytics', 'crm'],
    workflow: [
      { step: 'Khách gọi đến', description: 'Cuộc gọi vào hàng đợi IVR' },
      { step: 'Phân loại', description: 'IVR điều hướng theo nhu cầu' },
      { step: 'Phân agent', description: 'Hàng đợi phân cho agent rảnh' },
      { step: 'Giám sát', description: 'Supervisor nghe, thì thầm, can thiệp' },
      { step: 'Báo cáo', description: 'SLA, tỷ lệ trả lời, thời gian đàm thoại' },
    ],
    features: ['IVR', 'Queue', 'Agent', 'Supervisor', 'Wallboard', 'Monitor', 'Whisper', 'SLA', 'Call Recording', 'KPI'],
    useCases: [
      { title: 'Call Center Inbound', description: 'Tiếp nhận cuộc gọi khách hàng, tối ưu thời gian chờ.' },
      { title: 'Call Center Outbound', description: 'Đội ngũ gọi ra bán hàng, khảo sát, nhắc nợ.' },
      { title: 'Call Center Hybrid', description: 'Kết hợp inbound và outbound trong cùng đội ngũ.' },
    ],
  },
  {
    slug: 'contact-center',
    name: 'Contact Center',
    tagline: 'Chăm sóc khách hàng đa kênh trên một nền tảng',
    description:
      'Giải pháp Contact Center OnePOS hợp nhất kênh thoại và kỹ thuật số, giúp doanh nghiệp chăm sóc khách hàng xuyên suốt trên mọi điểm chạm.',
    type: 'need',
    painPoints: [
      'Khách liên lạc qua nhiều kênh, dữ liệu phân tán',
      'Agent phải dùng nhiều phần mềm cùng lúc',
      'Không có context xuyên suốt giữa các kênh',
      'Khó đo lường hiệu quả từng kênh',
    ],
    solutions: [
      { title: 'Unified Inbox', description: 'Mọi kênh trên một inbox duy nhất.' },
      { title: 'Customer 360', description: 'Tầm nhìn toàn cảnh khách hàng trên mọi kênh.' },
      { title: 'Ticket', description: 'Quản lý yêu cầu hỗ trợ có quy trình.' },
      { title: 'Báo cáo đa kênh', description: 'Đo lường hiệu quả từng kênh và tổng thể.' },
    ],
    products: ['contact-center', 'omnichannel', 'crm', 'ai-chatbot', 'ai-call-analytics'],
    workflow: [
      { step: 'Tiếp nhận đa kênh', description: 'Gọi, chat, Zalo, Facebook, email' },
      { step: 'Hợp nhất', description: 'Tất cả về một inbox chung' },
      { step: 'Phân công', description: 'Tự động phân theo kỹ năng agent' },
      { step: 'Xử lý', description: 'Agent xem Customer 360 và xử lý' },
      { step: 'Báo cáo', description: 'Đo lường hiệu quả từng kênh' },
    ],
    features: ['Voice', 'Chat', 'Zalo', 'Facebook', 'Email', 'Ticket', 'Customer 360', 'SLA', 'QA'],
    useCases: [
      { title: 'Trung tâm CSKH đa kênh', description: 'Phục vụ khách hàng qua gọi và chat cùng lúc.' },
      { title: 'Hỗ trợ E-commerce', description: 'Xử lý đơn hàng, đổi trả qua gọi và chat.' },
      { title: 'Hỗ trợ dịch vụ', description: 'Tiếp nhận yêu cầu hỗ trợ qua nhiều kênh.' },
    ],
  },
  {
    slug: 'marketing',
    name: 'Marketing',
    tagline: 'Thu lead và chăm sóc khách hàng qua nhiều kênh',
    description:
      'Giải pháp marketing OnePOS giúp đội ngũ marketing thu lead, chăm sóc và giữ chân khách hàng qua gọi, SMS, Zalo và chat — đo lường hiệu quả từng chiến dịch.',
    type: 'need',
    painPoints: [
      'Lead từ nhiều nguồn khó quản lý',
      'Không theo dõi được hiệu quả chiến dịch',
      'Khó nurture lead qua nhiều kênh',
      'Không đo lường được ROI marketing',
    ],
    solutions: [
      { title: 'Lead Capture', description: 'Thu lead từ website, Facebook, Zalo.' },
      { title: 'Auto Call', description: 'Tự động gọi lead theo chiến dịch.' },
      { title: 'SMS & ZNS', description: 'Gửi SMS Brandname và Zalo ZNS.' },
      { title: 'CRM Pipeline', description: 'Theo dõi lead qua phễu bán hàng.' },
    ],
    products: ['crm', 'auto-call', 'sms-brandname', 'zalo-zns', 'ai-chatbot'],
    workflow: [
      { step: 'Thu lead', description: 'Từ website, Facebook, Zalo, sự kiện' },
      { step: 'Phân loại', description: 'AI chấm điểm và phân loại lead' },
      { step: 'Nurture', description: 'Gọi, SMS, ZNS theo kịch bản' },
      { step: 'Chuyển Sales', description: 'Lead đủ điều kiện chuyển cho Sales' },
      { step: 'Đo lường', description: 'ROI theo từng chiến dịch' },
    ],
    features: ['Lead Management', 'Auto Call', 'SMS Brandname', 'Zalo ZNS', 'Pipeline', 'Campaign', 'AI Chatbot', 'Analytics'],
    useCases: [
      { title: 'Chiến dịch Lead Gen', description: 'Thu lead từ quảng cáo và nurture qua gọi, SMS.' },
      { title: 'Chăm sóc khách hàng', description: 'Gửi thông báo và ưu đãi qua ZNS, SMS.' },
      { title: 'Event Marketing', description: 'Mời khách tham dự sự kiện qua Auto Call.' },
    ],
  },
  {
    slug: 'tu-dong-hoa',
    name: 'Tự động hóa',
    tagline: 'Tự động hóa quy trình giao tiếp với khách hàng',
    description:
      'Giải pháp tự động hóa OnePOS giúp doanh nghiệp tự động gọi, nhắn tin, phân công và xử lý yêu cầu khách hàng — giảm thao tác thủ công, tăng hiệu quả.',
    type: 'need',
    painPoints: [
      'Nhiều thao tác lặp lại thủ công',
      'Agent tốn thời gian cho việc không cần thiết',
      'Khó đảm bảo tính nhất quán',
      'Không thể phục vụ ngoài giờ làm việc',
    ],
    solutions: [
      { title: 'Auto Call', description: 'Tự động gọi theo danh sách và lịch.' },
      { title: 'AI Voice Agent', description: 'AI nghe và nói với khách hàng 24/7.' },
      { title: 'Workflow', description: 'Tự động phân công và xử lý theo quy tắc.' },
      { title: 'SMS & ZNS', description: 'Gửi thông báo tự động theo sự kiện.' },
    ],
    products: ['auto-call', 'ai-voice-agent', 'ai-chatbot', 'sms-brandname', 'zalo-zns'],
    workflow: [
      { step: 'Thiết lập quy tắc', description: 'Định nghĩa khi nào tự động' },
      { step: 'Kích hoạt', description: 'Sự kiện hoặc lịch trình kích hoạt' },
      { step: 'Thực thi', description: 'AI, Auto Call, SMS, ZNS tự động' },
      { step: 'Chuyển agent', description: 'Khi cần, chuyển cho người xử lý' },
      { step: 'Báo cáo', description: 'Đo lường hiệu quả tự động hóa' },
    ],
    features: ['Auto Call', 'AI Voice Agent', 'AI Chatbot', 'Workflow', 'SMS', 'ZNS', 'Webhook', 'API'],
    useCases: [
      { title: 'Nhắc lịch hẹn', description: 'Tự động gọi hoặc SMS nhắc khách đến hẹn.' },
      { title: 'Xác nhận đơn hàng', description: 'AI gọi xác nhận đơn hàng tự động.' },
      { title: 'Thu hồi nợ', description: 'Auto Call nhắc khách thanh toán.' },
    ],
  },
  {
    slug: 'ai-customer-service',
    name: 'AI Customer Service',
    tagline: 'AI phục vụ khách hàng 24/7 trên mọi kênh',
    description:
      'Giải pháp AI Customer Service OnePOS kết hợp AI Voice Agent, AI Chatbot và AI Call Analytics — giúp doanh nghiệp tự động hóa phục vụ khách hàng mà vẫn đảm bảo chất lượng.',
    type: 'need',
    painPoints: [
      'Khách hàng phải chờ ngoài giờ làm việc',
      'Agent quá tải vào giờ cao điểm',
      'Câu hỏi lặp lại tốn thời gian agent',
      'Khó đánh giá chất lượng phục vụ',
    ],
    solutions: [
      { title: 'AI Voice Agent', description: 'AI nghe và nói với khách hàng 24/7.' },
      { title: 'AI Chatbot', description: 'AI trả lời chat trên mọi kênh.' },
      { title: 'AI Call Analytics', description: 'Tự động đánh giá chất lượng cuộc gọi.' },
      { title: 'Human Handoff', description: 'Chuyển agent mượt mà khi cần.' },
    ],
    products: ['ai-voice-agent', 'ai-chatbot', 'ai-call-analytics', 'contact-center'],
    workflow: [
      { step: 'Khách liên lạc', description: 'Gọi hoặc chat bất cứ lúc nào' },
      { step: 'AI tiếp nhận', description: 'AI Voice Agent hoặc Chatbot xử lý' },
      { step: 'Phân tích', description: 'AI nhận diện ý định và cảm xúc' },
      { step: 'Tự xử lý hoặc chuyển', description: 'AI trả lời hoặc chuyển agent' },
      { step: 'Đánh giá', description: 'AI Call Analytics chấm chất lượng' },
    ],
    features: ['AI Voice Agent', 'AI Chatbot', 'Intent Detection', 'Sentiment', 'Human Handoff', 'Call Scoring', '24/7', 'Multi-language'],
    useCases: [
      { title: 'Tự động trả lời', description: 'AI trả lời câu hỏi phổ biến về sản phẩm, giá, giờ làm việc.' },
      { title: 'Tiếp nhận ngoài giờ', description: 'AI phục vụ khách hàng khi agent không trực.' },
      { title: 'Đánh giá chất lượng', description: 'AI chấm điểm mọi cuộc gọi, phát hiện vấn đề.' },
    ],
  },
];

export const Industries: SolutionDetail[] = [
  {
    slug: 'ban-le',
    name: 'Bán lẻ',
    tagline: 'Kết nối chuỗi cửa hàng với khách hàng trên mọi kênh',
    description:
      'Giải pháp bán lẻ OnePOS giúp chuỗi cửa hàng quản lý cuộc gọi, chat và chăm sóc khách hàng tập trung — từ hotline cửa hàng đến chăm sóc khách hàng thân thiết.',
    type: 'industry',
    painPoints: [
      'Mỗi cửa hàng có hotline riêng, khó quản lý tập trung',
      'Khách nhắn tin trên nhiều kênh, không ai trả lời kịp',
      'Không lưu được lịch sử khách hàng mua',
      'Khó đo lường hiệu quả CSKH theo cửa hàng',
    ],
    solutions: [
      { title: 'Tổng đài Cloud', description: 'Một tổng đài cho toàn bộ chuỗi, định tuyến theo cửa hàng.' },
      { title: 'Omnichannel', description: 'Chat Facebook, Zalo, website trên một inbox.' },
      { title: 'CRM', description: 'Lưu lịch sử mua hàng và chăm sóc khách hàng.' },
      { title: 'SMS & ZNS', description: 'Gửi ưu đãi và thông báo khuyến mãi.' },
    ],
    products: ['tong-dai-cloud', 'omnichannel', 'crm', 'sms-brandname', 'zalo-zns'],
    workflow: [
      { step: 'Khách liên lạc', description: 'Gọi hotline hoặc nhắn tin kênh online' },
      { step: 'Định tuyến cửa hàng', description: 'Tổng đài chuyển về cửa hàng gần nhất' },
      { step: 'Tra cứu CRM', description: 'Agent xem lịch sử mua hàng' },
      { step: 'Xử lý', description: 'Tư vấn, đặt hàng, đổi trả' },
      { step: 'Chăm sóc', description: 'SMS/ZNS gửi ưu đãi, sinh nhật' },
    ],
    features: ['IVR đa cửa hàng', 'Omnichannel', 'Customer 360', 'SMS Brandname', 'Zalo ZNS', 'Call Recording'],
    useCases: [
      { title: 'Hotline chuỗi', description: 'Một số tổng đài cho toàn bộ chuỗi, định tuyến theo khu vực.' },
      { title: 'Chat bán hàng', description: 'Nhân viên trả lời chat Facebook, Zalo, website.' },
      { title: 'Chăm sóc KH', description: 'Gửi ưu đãi sinh nhật, khuyến mãi qua SMS và ZNS.' },
    ],
  },
  {
    slug: 'ecommerce',
    name: 'E-commerce',
    tagline: 'Xử lý đơn hàng và chăm sóc khách hàng E-commerce',
    description:
      'Giải pháp E-commerce OnePOS giúp doanh nghiệp bán hàng online xử lý cuộc gọi, chat, xác nhận đơn và chăm sóc khách hàng hiệu quả.',
    type: 'industry',
    painPoints: [
      'Khách gọi hỏi đơn hàng, đổi trả — tốn nhiều thời gian',
      'Tin nhắn Facebook, Zalo, website tràn ngập',
      'Xác nhận đơn thủ công chậm',
      'Khó đo lường CSAT',
    ],
    solutions: [
      { title: 'Omnichannel', description: 'Mọi tin nhắn trên một inbox.' },
      { title: 'Auto Call', description: 'Tự động gọi xác nhận đơn hàng.' },
      { title: 'AI Chatbot', description: 'AI trả lời câu hỏi về đơn hàng, vận chuyển.' },
      { title: 'CRM', description: 'Lưu lịch sử mua và hoàn trả.' },
    ],
    products: ['omnichannel', 'auto-call', 'ai-chatbot', 'crm', 'sms-brandname'],
    workflow: [
      { step: 'Đơn hàng', description: 'Khách đặt hàng trên website/sàn' },
      { step: 'Xác nhận', description: 'Auto Call hoặc AI gọi xác nhận' },
      { step: 'Hỗ trợ', description: 'Khách chat/gọi hỏi về đơn' },
      { step: 'Đổi trả', description: 'Tạo ticket xử lý đổi trả' },
      { step: 'Đánh giá', description: 'Gửi SMS/ZNS xin đánh giá' },
    ],
    features: ['Omnichannel', 'Auto Call', 'AI Chatbot', 'Ticket', 'SMS Brandname', 'Zalo ZNS', 'CRM'],
    useCases: [
      { title: 'Xác nhận đơn', description: 'Auto Call tự động gọi xác nhận đơn hàng COD.' },
      { title: 'Hỗ trợ đổi trả', description: 'Tiếp nhận yêu cầu đổi trả qua chat và gọi.' },
      { title: 'Khảo sát hài lòng', description: 'Gửi SMS/ZNS xin đánh giá sau khi nhận hàng.' },
    ],
  },
  {
    slug: 'bat-dong-san',
    name: 'Bất động sản',
    tagline: 'Quản lý lead và telesales dự án bất động sản',
    description:
      'Giải pháp bất động sản OnePOS giúp đội ngũ sales BĐS quản lý lead, gọi telesales và chăm sóc khách hàng mua dự án hiệu quả.',
    type: 'industry',
    painPoints: [
      'Lead từ nhiều nguồn khó quản lý',
      'Telesales gọi không có kịch bản',
      'Không theo dõi được khách đã xem dự án',
      'Khó đo lường tỷ lệ chuyển đổi',
    ],
    solutions: [
      { title: 'CRM', description: 'Quản lý lead và khách hàng dự án.' },
      { title: 'Telesales', description: 'Workspace gọi có kịch bản theo dự án.' },
      { title: 'Auto Call', description: 'Tự động gọi mời xem dự án.' },
      { title: 'SMS & ZNS', description: 'Gửi thông tin dự án và sự kiện.' },
    ],
    products: ['crm', 'telesales', 'auto-call', 'sms-brandname', 'zalo-zns'],
    workflow: [
      { step: 'Thu lead', description: 'Từ sự kiện, website, Facebook' },
      { step: 'Phân loại', description: 'Phân lead theo dự án và ngân sách' },
      { step: 'Telesales', description: 'Agent gọi mời xem dự án' },
      { step: 'Theo dõi', description: 'Pipeline theo dõi khách qua từng giai đoạn' },
      { step: 'Chốt', description: 'Gọi/SMS xác nhận đặt cọc' },
    ],
    features: ['Lead Management', 'Telesales Workspace', 'Auto Call', 'Pipeline', 'SMS Brandname', 'Zalo ZNS', 'Call Recording'],
    useCases: [
      { title: 'Mở bán dự án', description: 'Telesales gọi hàng loạt khách mời tham dự sự kiện mở bán.' },
      { title: 'Chăm sóc khách', description: 'Gửi thông tin dự án và tiến độ qua SMS/ZNS.' },
      { title: 'Telesales dự án', description: 'Workspace gọi có kịch bản theo từng dự án BĐS.' },
    ],
  },
  {
    slug: 'giao-duc',
    name: 'Giáo dục',
    tagline: 'Tư vấn tuyển sinh và chăm sóc học viên',
    description:
      'Giải pháp giáo dục OnePOS giúp trung tâm, trường học tư vấn tuyển sinh qua telesales và chăm sóc học viên đa kênh.',
    type: 'industry',
    painPoints: [
      'Tư vấn tuyển sinh tốn nhiều nhân lực',
      'Phụ huynh liên lạc qua nhiều kênh',
      'Không theo dõi được học viên',
      'Nhắc học phí thủ công',
    ],
    solutions: [
      { title: 'Telesales', description: 'Gọi tư vấn tuyển sinh có kịch bản.' },
      { title: 'Omnichannel', description: 'Chat phụ huynh trên mọi kênh.' },
      { title: 'CRM', description: 'Quản lý hồ sơ học viên.' },
      { title: 'Auto Call & SMS', description: 'Nhắc học phí, lịch học tự động.' },
    ],
    products: ['telesales', 'omnichannel', 'crm', 'auto-call', 'sms-brandname'],
    workflow: [
      { step: 'Thu lead', description: 'Phụ huynh/học sinh đăng ký' },
      { step: 'Tư vấn', description: 'Telesales gọi tư vấn khóa học' },
      { step: 'Theo dõi', description: 'CRM theo dõi hồ sơ học viên' },
      { step: 'Nhắc nhở', description: 'Auto Call/SMS nhắc lịch học' },
      { step: 'Chăm sóc', description: 'Chat hỗ trợ phụ huynh đa kênh' },
    ],
    features: ['Telesales', 'Omnichannel', 'CRM', 'Auto Call', 'SMS Brandname', 'Call Recording'],
    useCases: [
      { title: 'Tư vấn tuyển sinh', description: 'Telesales gọi tư vấn khóa học cho phụ huynh.' },
      { title: 'Chăm sóc học viên', description: 'Chat hỗ trợ học viên qua Zalo, Facebook.' },
      { title: 'Nhắc học phí', description: 'Auto Call/SMS nhắc đóng học phí đúng hạn.' },
    ],
  },
  {
    slug: 'y-te',
    name: 'Y tế',
    tagline: 'Đặt lịch hẹn và chăm sóc bệnh nhân',
    description:
      'Giải pháp y tế OnePOS giúp phòng khám, bệnh viện quản lý cuộc gọi đặt lịch, nhắc lịch hẹn và chăm sóc bệnh nhân đa kênh.',
    type: 'industry',
    painPoints: [
      'Đặt lịch hẹn thủ công, dễ nhầm',
      'Bệnh nhân không nhớ lịch hẹn',
      'Gọi nhắc lịch tốn thời gian nhân viên',
      'Khó quản lý hồ sơ bệnh nhân',
    ],
    solutions: [
      { title: 'Tổng đài Cloud', description: 'Tổng đài đặt lịch hẹn chuyên nghiệp.' },
      { title: 'Auto Call', description: 'Tự động gọi nhắc lịch hẹn.' },
      { title: 'CRM', description: 'Quản lý hồ sơ bệnh nhân.' },
      { title: 'SMS & ZNS', description: 'Gửi nhắc lịch và kết quả xét nghiệm.' },
    ],
    products: ['tong-dai-cloud', 'auto-call', 'crm', 'sms-brandname', 'zalo-zns'],
    workflow: [
      { step: 'Đặt lịch', description: 'Bệnh nhân gọi đặt lịch hẹn' },
      { step: 'Nhắc lịch', description: 'Auto Call/SMS nhắc trước ngày hẹn' },
      { step: 'Khám', description: 'Bệnh nhân đến khám' },
      { step: 'Kết quả', description: 'SMS/ZNS gửi kết quả xét nghiệm' },
      { step: 'Tái khám', description: 'Nhắc lịch tái khám tự động' },
    ],
    features: ['IVR', 'Auto Call', 'CRM', 'SMS Brandname', 'Zalo ZNS', 'Call Recording'],
    useCases: [
      { title: 'Đặt lịch hẹn', description: 'Bệnh nhân gọi tổng đài đặt lịch khám.' },
      { title: 'Nhắc lịch hẹn', description: 'Auto Call tự động gọi nhắc trước ngày hẹn.' },
      { title: 'Gửi kết quả', description: 'SMS/ZNS gửi kết quả xét nghiệm và nhắc tái khám.' },
    ],
  },
  {
    slug: 'tai-chinh',
    name: 'Tài chính',
    tagline: 'Telesales và thu hồi nợ cho tài chính, ngân hàng',
    description:
      'Giải pháp tài chính OnePOS giúp tổ chức tài chính telesales vay vốn, thu hồi nợ và chăm sóc khách hàng với quy trình tuân thủ nghiêm ngặt.',
    type: 'industry',
    painPoints: [
      'Telesales vay vốn cần kịch bản tuân thủ',
      'Thu hồi nợ tốn nhiều nhân lực',
      'Cần ghi âm và kiểm tra tuân thủ',
      'Bảo mật dữ liệu khách hàng cao',
    ],
    solutions: [
      { title: 'Telesales', description: 'Gọi có kịch bản tuân thủ quy định.' },
      { title: 'Auto Call', description: 'Tự động gọi nhắc thanh toán.' },
      { title: 'AI Call Analytics', description: 'Kiểm tra tuân thủ kịch bản.' },
      { title: 'CRM', description: 'Quản lý hồ sơ vay an toàn.' },
    ],
    products: ['telesales', 'auto-call', 'ai-call-analytics', 'crm', 'sms-brandname'],
    workflow: [
      { step: 'Tiếp nhận', description: 'Khách đăng ký vay vốn' },
      { step: 'Telesales', description: 'Agent gọi tư vấn có kịch bản' },
      { step: 'Kiểm tra', description: 'AI kiểm tra tuân thủ kịch bản' },
      { step: 'Nhắc nợ', description: 'Auto Call/SMS nhắc thanh toán' },
      { step: 'Thu hồi', description: 'Agent gọi thu hồi nợ' },
    ],
    features: ['Telesales', 'Auto Call', 'AI Call Analytics', 'Call Recording', 'CRM', 'SMS Brandname', 'Compliance'],
    useCases: [
      { title: 'Telesales vay vốn', description: 'Gọi tư vấn sản phẩm vay có kịch bản tuân thủ.' },
      { title: 'Nhắc thanh toán', description: 'Auto Call/SMS nhắc khách trả nợ đúng hạn.' },
      { title: 'Kiểm tra tuân thủ', description: 'AI phân tích cuộc gọi đảm bảo tuân thủ quy định.' },
    ],
  },
  {
    slug: 'logistics',
    name: 'Logistics',
    tagline: 'Giao nhận và hỗ trợ khách hàng vận chuyển',
    description:
      'Giải pháp logistics OnePOS giúp doanh nghiệp vận chuyển quản lý cuộc gọi giao nhận, hỗ trợ khách hàng tra cứu và khiếu nại đa kênh.',
    type: 'industry',
    painPoints: [
      'Khách gọi hỏi trạng thái đơn hàng liên tục',
      'Khiếu nại qua nhiều kênh khó quản lý',
      'Tài xế cần liên lạc điều phối',
      'Khó đo lường chất lượng phục vụ',
    ],
    solutions: [
      { title: 'IVR Tra cứu', description: 'IVR tự động tra cứu trạng thái đơn.' },
      { title: 'Omnichannel', description: 'Khiếu nại qua gọi, chat, email.' },
      { title: 'Auto Call', description: 'Tự động gọi thông báo giao hàng.' },
      { title: 'SMS & ZNS', description: 'Gửi mã vận đơn và thông báo.' },
    ],
    products: ['tong-dai-cloud', 'omnichannel', 'auto-call', 'sms-brandname', 'zalo-zns'],
    workflow: [
      { step: 'Tra cứu', description: 'Khách gọi IVR tra cứu đơn' },
      { step: 'Giao hàng', description: 'Auto Call/SMS thông báo giao' },
      { step: 'Khiếu nại', description: 'Tiếp nhận khiếu nại đa kênh' },
      { step: 'Xử lý', description: 'Ticket xử lý khiếu nại' },
      { step: 'Đánh giá', description: 'SMS/ZNS xin đánh giá dịch vụ' },
    ],
    features: ['IVR', 'Omnichannel', 'Auto Call', 'Ticket', 'SMS Brandname', 'Zalo ZNS'],
    useCases: [
      { title: 'Tra cứu đơn', description: 'IVR tự động trả lời trạng thái vận đơn.' },
      { title: 'Thông báo giao', description: 'Auto Call/SMS thông báo tài xế đang giao.' },
      { title: 'Khiếu nại', description: 'Tiếp nhận khiếu nại qua gọi và chat.' },
    ],
  },
  {
    slug: 'fnb',
    name: 'F&B',
    tagline: 'Đặt bàn và chăm sóc khách hàng nhà hàng, chuỗi F&B',
    description:
      'Giải pháp F&B OnePOS giúp nhà hàng, chuỗi F&B quản lý cuộc gọi đặt bàn, giao hàng và chăm sóc khách hàng thân thiết.',
    type: 'industry',
    painPoints: [
      'Khách gọi đặt bàn trong giờ cao điểm khó tiếp',
      'Đặt bàn qua nhiều kênh dễ nhầm',
      'Không quản lý được khách quen',
      'Khó gửi ưu đãi cho khách',
    ],
    solutions: [
      { title: 'Tổng đài Cloud', description: 'Tổng đài đặt bàn cho chuỗi nhà hàng.' },
      { title: 'Omnichannel', description: 'Chat đặt bàn qua Zalo, Facebook.' },
      { title: 'CRM', description: 'Quản lý khách quen và sở thích.' },
      { title: 'SMS & ZNS', description: 'Gửi ưu đãi và khuyến mãi.' },
    ],
    products: ['tong-dai-cloud', 'omnichannel', 'crm', 'sms-brandname', 'zalo-zns'],
    workflow: [
      { step: 'Đặt bàn', description: 'Khách gọi hoặc chat đặt bàn' },
      { step: 'Xác nhận', description: 'Agent xác nhận và ghi CRM' },
      { step: 'Phục vụ', description: 'Nhà hàng phục vụ khách' },
      { step: 'Chăm sóc', description: 'SMS/ZNS gửi ưu đãi' },
      { step: 'Đánh giá', description: 'Xin đánh giá trải nghiệm' },
    ],
    features: ['IVR', 'Omnichannel', 'CRM', 'SMS Brandname', 'Zalo ZNS', 'Call Recording'],
    useCases: [
      { title: 'Đặt bàn', description: 'Khách gọi tổng đài đặt bàn cho chuỗi nhà hàng.' },
      { title: 'Giao hàng', description: 'Chat đặt món giao tận nơi qua Zalo, Facebook.' },
      { title: 'Khách quen', description: 'CRM lưu sở thích, gửi ưu đãi sinh nhật.' },
    ],
  },
  {
    slug: 'dich-vu',
    name: 'Dịch vụ',
    tagline: 'Hỗ trợ khách hàng cho doanh nghiệp dịch vụ',
    description:
      'Giải pháp dịch vụ OnePOS giúp doanh nghiệp dịch vụ tiếp nhận yêu cầu, đặt lịch và chăm sóc khách hàng đa kênh.',
    type: 'industry',
    painPoints: [
      'Khách liên lạc qua nhiều kênh, dễ bỏ lỡ',
      'Đặt lịch hẹn thủ công',
      'Không theo dõi được chất lượng dịch vụ',
      'Khó đo lường CSAT',
    ],
    solutions: [
      { title: 'Omnichannel', description: 'Mọi kênh trên một inbox.' },
      { title: 'CRM', description: 'Quản lý khách hàng và lịch sử.' },
      { title: 'Auto Call', description: 'Nhắc lịch hẹn tự động.' },
      { title: 'AI Chatbot', description: 'AI trả lời câu hỏi phổ biến.' },
    ],
    products: ['omnichannel', 'crm', 'auto-call', 'ai-chatbot', 'sms-brandname'],
    workflow: [
      { step: 'Tiếp nhận', description: 'Khách gọi hoặc chat đặt dịch vụ' },
      { step: 'Đặt lịch', description: 'Agent đặt lịch trong CRM' },
      { step: 'Nhắc lịch', description: 'Auto Call/SMS nhắc trước lịch hẹn' },
      { step: 'Phục vụ', description: 'Cung cấp dịch vụ' },
      { step: 'Đánh giá', description: 'Xin đánh giá và CSAT' },
    ],
    features: ['Omnichannel', 'CRM', 'Auto Call', 'AI Chatbot', 'SMS Brandname', 'Ticket'],
    useCases: [
      { title: 'Đặt dịch vụ', description: 'Khách đặt lịch dịch vụ qua gọi và chat.' },
      { title: 'Hỗ trợ', description: 'AI Chatbot trả lời câu hỏi dịch vụ 24/7.' },
      { title: 'Chăm sóc', description: 'SMS/ZNS gửi ưu đãi và nhắc lịch.' },
    ],
  },
];

export const ScaleSolutions: SolutionDetail[] = [
  {
    slug: 'startup',
    name: 'Startup',
    tagline: 'Bắt đầu nhanh với chi phí tối thiểu',
    description:
      'OnePOS giúp startup triển khai tổng đài và CRM nhanh chóng, không cần đầu tư hạ tầng — mở rộng khi doanh nghiệp phát triển.',
    type: 'scale',
    painPoints: [
      'Không có ngân sách cho hạ tầng tổng đài',
      'Cần triển khai nhanh, không chờ đợi',
      'Đội ngũ nhỏ, cần công cụ đa năng',
      'Muốn mở rộng khi tăng trưởng',
    ],
    solutions: [
      { title: 'Cloud PBX', description: 'Tổng đài Cloud, bắt đầu ngay, không cần phần cứng.' },
      { title: 'CRM', description: 'Quản lý khách hàng từ ngày đầu.' },
      { title: 'Omnichannel', description: 'Chat đa kênh, không bỏ lỡ khách.' },
      { title: 'Mở rộng linh hoạt', description: 'Thêm agent khi tăng trưởng.' },
    ],
    products: ['tong-dai-cloud', 'crm', 'omnichannel'],
    workflow: [
      { step: 'Đăng ký', description: 'Bắt đầu dùng thử miễn phí' },
      { step: 'Thiết lập', description: 'Cấu hình tổng đài và CRM' },
      { step: 'Bán hàng', description: 'Gọi và chat với khách' },
      { step: 'Mở rộng', description: 'Thêm agent và tính năng' },
    ],
    features: ['Cloud PBX', 'CRM', 'Omnichannel', 'Click-to-Call', 'Mobile App'],
    useCases: [
      { title: 'Tổng đài startup', description: 'Tổng đài Cloud cho 2-10 người.' },
      { title: 'CRM ban đầu', description: 'Quản lý khách hàng từ ngày đầu.' },
      { title: 'Chat đa kênh', description: 'Trả lời khách trên mọi kênh.' },
    ],
  },
  {
    slug: 'sme',
    name: 'SME',
    tagline: 'Quản lý khách hàng chuyên nghiệp cho doanh nghiệp vừa',
    description:
      'OnePOS giúp doanh nghiệp vừa xây dựng Call Center, CRM và Omnichannel chuyên nghiệp — tối ưu hiệu suất Sales và CSKH.',
    type: 'scale',
    painPoints: [
      'Cần Call Center chuyên nghiệp nhưng ngân sách hạn chế',
      'Dữ liệu khách hàng phân tán',
      'Đo lường KPI Sales khó',
      'Muốn tự động hóa nhưng chưa biết bắt đầu',
    ],
    solutions: [
      { title: 'Call Center', description: 'Call Center Cloud cho 10-50 agent.' },
      { title: 'CRM', description: 'CRM quản lý toàn bộ khách hàng.' },
      { title: 'Omnichannel', description: 'Hợp nhất chat đa kênh.' },
      { title: 'Auto Call', description: 'Tự động hóa telesales.' },
    ],
    products: ['call-center', 'crm', 'omnichannel', 'auto-call', 'telesales'],
    workflow: [
      { step: 'Triển khai', description: 'Call Center + CRM + Omnichannel' },
      { step: 'Đào tạo', description: 'Agent sử dụng workspace' },
      { step: 'Vận hành', description: 'Giám sát và đo lường KPI' },
      { step: 'Tối ưu', description: 'AI và tự động hóa' },
    ],
    features: ['Call Center', 'CRM', 'Omnichannel', 'Auto Call', 'Telesales', 'KPI', 'Wallboard'],
    useCases: [
      { title: 'Call Center SME', description: 'Call Center 10-50 agent trên Cloud.' },
      { title: 'Telesales SME', description: 'Workspace telesales có KPI.' },
      { title: 'CSKH đa kênh', description: 'Chăm sóc khách hàng qua gọi và chat.' },
    ],
  },
  {
    slug: 'enterprise',
    name: 'Enterprise',
    tagline: 'Nền tảng Contact Center cho doanh nghiệp lớn',
    description:
      'OnePOS cung cấp nền tảng Contact Center, CRM và AI cho doanh nghiệp lớn — mở rộng không giới hạn, tích hợp sâu và bảo mật cao.',
    type: 'scale',
    painPoints: [
      'Hệ thống cũ khó mở rộng',
      'Cần tích hợp nhiều hệ thống',
      'Bảo mật và tuân thủ cao',
      'Cần AI và tự động hóa quy mô lớn',
    ],
    solutions: [
      { title: 'Contact Center', description: 'Contact Center đa kênh quy mô lớn.' },
      { title: 'API & SDK', description: 'Tích hợp sâu với hệ thống doanh nghiệp.' },
      { title: 'AI', description: 'AI Voice Agent và Call Analytics quy mô lớn.' },
      { title: 'Bảo mật', description: 'Phân quyền chi tiết, audit log, bảo mật dữ liệu.' },
    ],
    products: ['contact-center', 'crm', 'ai-voice-agent', 'ai-call-analytics', 'auto-call'],
    workflow: [
      { step: 'Tư vấn', description: 'Phân tích nhu cầu doanh nghiệp' },
      { step: 'Thiết kế', description: 'Kiến trúc giải pháp tùy chỉnh' },
      { step: 'Tích hợp', description: 'Kết nối hệ thống qua API' },
      { step: 'Triển khai', description: 'Rollout theo giai đoạn' },
      { step: 'Vận hành', description: 'Hỗ trợ và tối ưu liên tục' },
    ],
    features: ['Contact Center', 'CRM', 'AI', 'API', 'SDK', 'SSO', 'Audit Log', 'SLA Enterprise'],
    useCases: [
      { title: 'Contact Center lớn', description: 'Contact Center hàng trăm agent đa kênh.' },
      { title: 'AI quy mô lớn', description: 'AI Voice Agent xử lý hàng nghìn cuộc gọi/ngày.' },
      { title: 'Tích hợp hệ thống', description: 'Kết nối CRM, ERP, hệ thống nội bộ.' },
    ],
  },
];

export function getSolution(slug: string): SolutionDetail | undefined {
  return [...Solutions, ...Industries, ...ScaleSolutions].find((s) => s.slug === slug);
}

export const AllSolutions = [...Solutions, ...Industries, ...ScaleSolutions];
