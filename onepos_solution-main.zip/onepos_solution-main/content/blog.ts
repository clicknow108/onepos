export type BlogPost = {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  readingTime: string;
  seoTitle: string;
  metaDescription: string;
  faqs: { question: string; answer: string }[];
};

export const BlogCategories = [
  'Tổng đài',
  'Call Center',
  'CRM',
  'Telesales',
  'Omnichannel',
  'AI',
  'VoIP',
  'Marketing',
  'Chăm sóc khách hàng',
  'Công nghệ',
];

export const BlogPosts: BlogPost[] = [
  {
    slug: 'tong-dai-cloud-la-gi',
    title: 'Tổng đài Cloud là gì? Hướng dẫn cho doanh nghiệp',
    excerpt: 'Tổng đài Cloud (Cloud PBX) là hệ thống tổng đài ảo chạy trên nền tảng Cloud, giúp doanh nghiệp gọi điện và nhận cuộc gọi mà không cần đầu tư phần cứng.',
    content: `## Tổng đài Cloud là gì?

Tổng đài Cloud (Cloud PBX) là hệ thống tổng đài điện thoại ảo hoạt động trên nền tảng Cloud. Thay vì lắp đặt thiết bị phần cứng tại văn phòng, doanh nghiệp sử dụng dịch vụ tổng đài qua Internet.

## Tổng đài Cloud hoạt động như thế nào?

Tổng đài Cloud sử dụng công nghệ VoIP (Voice over Internet Protocol) để truyền cuộc gọi qua Internet. Khi có cuộc gọi đến, hệ thống Cloud PBX điều hướng cuộc gọi đến máy lẻ (extension) phù hợp dựa trên quy tắc IVR.

### Các thành phần chính

- **IVR (Interactive Voice Response):** Điều hướng cuộc gọi theo phím bấm
- **Extension (Máy lẻ):** Mỗi nhân viên có một số máy lẻ riêng
- **Ring Group:** Nhóm máy lẻ đổ chuông cùng lúc
- **Queue:** Hàng đợi cuộc gọi khi tất cả agent bận
- **Call Recording:** Tự động ghi âm mọi cuộc gọi

## Lợi ích của tổng đài Cloud

### Không cần đầu tư phần cứng

Với tổng đài truyền thống, doanh nghiệp phải mua thiết bị tổng đài (PBX) vật lý, chi phí từ hàng chục đến hàng trăm triệu đồng. Tổng đài Cloud loại bỏ hoàn toàn khoản chi phí này.

### Làm việc từ xa

Agent có thể làm việc từ văn phòng, ở nhà hoặc bất kỳ đâu — chỉ cần kết nối Internet. Điều này đặc biệt phù hợp với mô hình làm việc hybrid và đội ngũ phân tán.

### Mở rộng linh hoạt

Thêm máy lẻ và agent theo nhu cầu, không cần nâng cấp phần cứng. Phù hợp cho doanh nghiệp đang tăng trưởng nhanh.

### Tiết kiệm chi phí

Trả phí theo sử dụng, không cần bảo trì phần cứng, không cần nhân sự IT chuyên trách.

## Tổng đài Cloud phù hợp cho ai?

- Doanh nghiệp nhỏ và startup cần tổng đài nhanh
- SME muốn xây dựng Call Center mà không đầu tư hạ tầng
- Doanh nghiệp có đội ngũ làm việc từ xa
- Chuỗi cửa hàng cần tổng đài tập trung

## OnePOS Cloud PBX

OnePOS cung cấp tổng đài Cloud PBX với đầy đủ tính năng: IVR, Queue, Ring Group, Call Recording, Call Forwarding, Voicemail, Monitoring. Agent làm việc trên trình duyệt, mobile hoặc IP Phone.`,
    category: 'Tổng đài',
    date: '2026-08-15',
    readingTime: '6 phút',
    seoTitle: 'Tổng đài Cloud là gì? Hướng dẫn toàn tập cho doanh nghiệp',
    metaDescription: 'Tổng đài Cloud (Cloud PBX) là hệ thống tổng đài ảo trên Cloud, không cần phần cứng. Tìm hiểu lợi ích, cách hoạt động và ứng dụng cho doanh nghiệp.',
    faqs: [
      { question: 'Tổng đài Cloud có cần lắp đặt phần cứng không?', answer: 'Không. Tổng đài Cloud hoạt động hoàn toàn trên Internet, bạn chỉ cần trình duyệt hoặc ứng dụng.' },
      { question: 'Tổng đài Cloud có ghi âm cuộc gọi không?', answer: 'Có. Mọi cuộc gọi đều được tự động ghi âm và lưu trữ.' },
      { question: 'Tổng đài Cloud có đắt không?', answer: 'Tổng đài Cloud thường rẻ hơn tổng đài truyền thống vì không cần đầu tư phần cứng, trả phí theo sử dụng.' },
    ],
  },
  {
    slug: 'call-center-la-gi',
    title: 'Call Center là gì? Phân biệt Call Center và Contact Center',
    excerpt: 'Call Center là trung tâm xử lý cuộc gọi khách hàng. Bài viết giải thích Call Center là gì, các thành phần chính và khác biệt với Contact Center.',
    content: `## Call Center là gì?

Call Center là trung tâm chuyên xử lý cuộc gọi điện thoại — cả inbound (tiếp nhận) và outbound (gọi ra). Call Center giúp doanh nghiệp quản lý đội ngũ agent, hàng đợi cuộc gọi và đo lường hiệu suất.

## Các thành phần chính của Call Center

### Agent

Agent là nhân viên trực tiếp nhận hoặc gọi cuộc gọi. Mỗi agent có trạng thái: sẵn sàng, bận, nghỉ, sau cuộc gọi.

### Queue (Hàng đợi)

Khi tất cả agent bận, cuộc gọi vào hàng đợi. Hệ thống phát nhạc chờ và thông báo vị trí chờ.

### Supervisor

Supervisor giám sát agent realtime: nghe lén (Listen), thì thầm (Whisper), can thiệp (Barge).

### Wallboard

Bảng điều khiển hiển thị realtime: agent online, cuộc gọi chờ, SLA, tỷ lệ trả lời.

### KPI

Các chỉ số đo lường: số cuộc gọi, thời gian đàm thoại, tỷ lệ trả lời, tỷ lệ bỏ cuộc gọi.

## Inbound vs Outbound

### Inbound Call Center

Tiếp nhận cuộc gọi từ khách hàng — hỗ trợ, tư vấn, khiếu nại.

### Outbound Call Center

Gọi ra khách hàng — telesales, khảo sát, thu hồi nợ.

### Hybrid Call Center

Kết hợp cả inbound và outbound trong cùng đội ngũ.

## Call Center vs Contact Center

Call Center tập trung vào **kênh thoại**. Contact Center mở rộng sang **nhiều kênh** — chat, Zalo, Facebook, email, mạng xã hội.

Nếu doanh nghiệp chỉ cần xử lý cuộc gọi, Call Center là đủ. Nếu cần chăm sóc khách hàng đa kênh, Contact Center phù hợp hơn.

## Call Center Cloud

Call Center Cloud hoạt động trên nền tảng Cloud, không cần phần cứng. Agent làm việc trên trình duyệt, mở rộng linh hoạt. OnePOS cung cấp giải pháp Call Center Cloud đầy đủ tính năng.`,
    category: 'Call Center',
    date: '2026-08-16',
    readingTime: '7 phút',
    seoTitle: 'Call Center là gì? Phân biệt Call Center và Contact Center',
    metaDescription: 'Call Center là trung tâm xử lý cuộc gọi khách hàng. Tìm hiểu Call Center là gì, các thành phần, KPI và khác biệt với Contact Center.',
    faqs: [
      { question: 'Call Center khác gì Contact Center?', answer: 'Call Center tập trung vào kênh thoại, Contact Center mở rộng sang nhiều kênh (chat, Zalo, Facebook, email).' },
      { question: 'Call Center Cloud có cần phần cứng không?', answer: 'Không. Call Center Cloud hoạt động trên Internet, agent chỉ cần trình duyệt.' },
      { question: 'Call Center phù hợp cho doanh nghiệp nào?', answer: 'Mọi doanh nghiệp có đội ngũ Sales hoặc CSKH, từ vài agent đến hàng trăm agent.' },
    ],
  },
  {
    slug: 'contact-center-la-gi',
    title: 'Contact Center là gì? Chăm sóc khách hàng đa kênh',
    excerpt: 'Contact Center là trung tâm chăm sóc khách hàng đa kênh — hợp nhất thoại, chat, Zalo, Facebook và email trên một nền tảng.',
    content: `## Contact Center là gì?

Contact Center là trung tâm chăm sóc khách hàng **đa kênh** — hợp nhất kênh thoại và các kênh kỹ thuật số (chat, Zalo, Facebook, email) vào một hệ thống duy nhất.

## Khác biệt với Call Center

| Tiêu chí | Call Center | Contact Center |
|----------|------------|---------------|
| Kênh | Thoại | Thoại + Chat + Email + MXH |
| Phạm vi | Cuộc gọi | Toàn bộ tương tác |
| Dữ liệu | Cuộc gọi | Đa kênh |

## Lợi ích của Contact Center

### Một hệ thống duy nhất

Agent không cần chuyển qua lại giữa nhiều phần mềm. Mọi cuộc gọi và tin nhắn hiển thị trên một inbox chung.

### Hành trình khách hàng xuyên suốt

Lịch sử tương tác trên mọi kênh được lưu trữ. Agent biết khách đã gọi, chat hay email trước đó.

### Tối ưu agent

Agent xử lý cuộc gọi và chat cùng lúc, tăng hiệu suất.

### Báo cáo đa kênh

Đo lường hiệu quả từng kênh và tổng thể toàn bộ Contact Center.

## Contact Center OnePOS

OnePOS cung cấp giải pháp Contact Center đầy đủ:
- Voice (gọi và nhận)
- Chat (Facebook, Zalo, Website, WhatsApp)
- Email
- Ticket (quản lý yêu cầu)
- Customer 360 (tầm nhìn toàn cảnh)
- AI Chatbot (trả lời tự động)

Triển khai nhanh trên Cloud, mở rộng linh hoạt.`,
    category: 'Call Center',
    date: '2026-08-17',
    readingTime: '5 phút',
    seoTitle: 'Contact Center là gì? Chăm sóc khách hàng đa kênh',
    metaDescription: 'Contact Center là trung tâm chăm sóc khách hàng đa kênh, hợp nhất thoại, chat, Zalo, Facebook và email. Tìm hiểu lợi ích và ứng dụng.',
    faqs: [
      { question: 'Contact Center có cần nhiều phần mềm không?', answer: 'Không. Contact Center hợp nhất mọi kênh trên một nền tảng duy nhất.' },
      { question: 'Contact Center phù hợp cho doanh nghiệp nào?', answer: 'Doanh nghiệp cần chăm sóc khách hàng trên nhiều kênh, không chỉ gọi điện.' },
    ],
  },
  {
    slug: 'omnichannel-la-gi',
    title: 'Omnichannel là gì? Chăm sóc khách hàng đa kênh',
    excerpt: 'Omnichannel là chiến lược hợp nhất mọi kênh giao tiếp với khách hàng — Facebook, Zalo, website, email — trên một nền tảng duy nhất.',
    content: `## Omnichannel là gì?

Omnichannel là chiến lược hợp nhất mọi kênh giao tiếp với khách hàng vào một hệ thống duy nhất. Khách hàng có thể liên lạc qua Facebook, Zalo, website, email — và doanh nghiệp quản lý tất cả trên một inbox chung.

## Omnichannel vs Multichannel

**Multichannel:** Nhiều kênh riêng biệt, dữ liệu phân tán.
**Omnichannel:** Nhiều kênh hợp nhất, dữ liệu xuyên suốt.

## Lợi ích của Omnichannel

### Không bỏ lỡ tin nhắn

Mọi tin nhắn từ mọi kênh đều hiển thị trên một inbox. Agent không cần kiểm tra từng kênh riêng.

### Context xuyên suốt

Lịch sử trò chuyện trên mọi kênh được lưu trữ cho mỗi khách hàng. Agent biết khách đã hỏi gì trước đó.

### Agent hiệu quả hơn

Agent trả lời tin nhắn từ nhiều kênh trên cùng một màn hình, không cần chuyển tab.

### Phân công tự động

Tự động phân cuộc hội thoại cho agent phù hợp dựa trên quy tắc và kỹ năng.

## Các kênh OnePOS hỗ trợ

- Facebook Messenger
- Zalo Official Account
- Website Live Chat
- WhatsApp Business
- Email
- TikTok

## Omnichannel OnePOS

OnePOS Omnichannel gom tất cả cuộc trò chuyện vào một inbox thống nhất, tích hợp CRM để hiển thị thông tin khách hàng và lịch sử tương tác.`,
    category: 'Omnichannel',
    date: '2026-08-18',
    readingTime: '5 phút',
    seoTitle: 'Omnichannel là gì? Chăm sóc khách hàng đa kênh',
    metaDescription: 'Omnichannel là chiến lược hợp nhất mọi kênh giao tiếp với khách hàng. Tìm hiểu lợi ích, các kênh và ứng dụng cho doanh nghiệp.',
    faqs: [
      { question: 'Omnichannel khác gì multichannel?', answer: 'Multichannel có nhiều kênh riêng biệt, Omnichannel hợp nhất mọi kênh trên một nền tảng với dữ liệu xuyên suốt.' },
      { question: 'Omnichannel hỗ trợ những kênh nào?', answer: 'Facebook, Zalo, Website, WhatsApp, Email, TikTok — tùy theo gói dịch vụ.' },
    ],
  },
  {
    slug: 'crm-la-gi',
    title: 'CRM là gì? Phần mềm quản lý khách hàng cho doanh nghiệp',
    excerpt: 'CRM (Customer Relationship Management) là phần mềm quản lý quan hệ khách hàng — lưu trữ, theo dõi và phân tích dữ liệu khách hàng.',
    content: `## CRM là gì?

CRM (Customer Relationship Management) là phần mềm quản lý quan hệ khách hàng. CRM giúp doanh nghiệp lưu trữ, theo dõi và phân tích toàn bộ dữ liệu khách hàng — từ thông tin liên hệ đến lịch sử tương tác và giao dịch.

## CRM có những tính năng gì?

### Customer 360

Tầm nhìn 360° khách hàng: thông tin liên hệ, lịch sử gọi, tin nhắn, giao dịch, ghi chú, hoạt động.

### Lead Management

Quản lý khách hàng tiềm năng (lead) từ khi tiếp nhận đến khi chuyển đổi.

### Pipeline

Quản lý phễu bán hàng — theo dõi cơ hội ở từng giai đoạn.

### Deal

Theo dõi từng cơ hội kinh doanh — giá trị, giai đoạn, dự kiến chốt.

### Activity

Lịch sử hoạt động — gọi, email, chat, họp, nhiệm vụ.

## Lợi ích của CRM

### Dữ liệu tập trung

Mọi thông tin khách hàng ở một nơi, không còn dữ liệu nằm rải rác ở nhiều nơi.

### Tăng tỷ lệ chốt

Pipeline giúp Sales theo dõi cơ hội và không bỏ lỡ giao dịch.

### Hiểu khách hàng

Xem lịch sử tương tác trước khi gọi — hiểu nhu cầu và sở thích khách hàng.

### Tự động hóa

Tự động phân công lead, nhắc việc, gửi email/SMS theo sự kiện.

## CRM OnePOS

CRM OnePOS tích hợp sẵn với tổng đài — gọi trực tiếp từ CRM, xem lịch sử cuộc gọi, ghi âm. Dữ liệu xuyên suốt từ cuộc gọi đầu tiên đến chăm sóc sau bán.`,
    category: 'CRM',
    date: '2026-08-19',
    readingTime: '6 phút',
    seoTitle: 'CRM là gì? Phần mềm quản lý khách hàng cho doanh nghiệp',
    metaDescription: 'CRM là phần mềm quản lý quan hệ khách hàng. Tìm hiểu CRM là gì, các tính năng, lợi ích và cách chọn CRM cho doanh nghiệp.',
    faqs: [
      { question: 'CRM có cần tổng đài không?', answer: 'Không bắt buộc, nhưng CRM tích hợp tổng đài giúp gọi trực tiếp và xem lịch sử cuộc gọi.' },
      { question: 'CRM OnePOS có tích hợp tổng đài không?', answer: 'Có. CRM OnePOS tích hợp sẵn với tổng đài Cloud, gọi trực tiếp từ CRM.' },
    ],
  },
  {
    slug: 'tong-dai-ao-hoat-dong-nhu-the-nao',
    title: 'Tổng đài ảo hoạt động như thế nào?',
    excerpt: 'Tổng đài ảo (Virtual PBX) hoạt động trên Cloud, sử dụng VoIP để truyền cuộc gọi qua Internet. Bài viết giải thích chi tiết cách hoạt động.',
    content: `## Tổng đài ảo hoạt động như thế nào?

Tổng đài ảo (Virtual PBX) là hệ thống tổng đài chạy trên nền tảng Cloud. Thay vì phần cứng tại văn phòng, hệ thống được vận hành trong trung tâm dữ liệu và truy cập qua Internet.

## Cơ chế hoạt động

### 1. Cuộc gọi đến

Khi khách gọi đến số tổng đài, cuộc gọi đi qua nhà mạng → SIP Trunk → Cloud PBX.

### 2. IVR điều hướng

Cloud PBX phát lời chào IVR, khách bấm phím chọn dịch vụ. Hệ thống điều hướng cuộc gọi theo quy tắc.

### 3. Phân agent

Cuộc gọi vào hàng đợi (Queue), hệ thống phân cho agent rảnh theo chiến lược (ring all, round robin, longest idle).

### 4. Agent trả lời

Agent nhận cuộc gọi trên trình duyệt (WebRTC), Softphone hoặc IP Phone. Cuộc gọi được ghi âm tự động.

### 5. Kết thúc và báo cáo

Sau cuộc gọi, dữ liệu được ghi vào CRM và báo cáo. Supervisor xem realtime.

## Công nghệ sử dụng

- **VoIP (Voice over IP):** Truyền cuộc gọi qua Internet
- **SIP (Session Initiation Protocol):** Giao thức thiết lập cuộc gọi
- **WebRTC:** Gọi trực tiếp trên trình duyệt
- **SIP Trunk:** Kết nối Cloud PBX với nhà mạng

## Ưu điểm của tổng đài ảo

- Không cần phần cứng
- Triển khai nhanh
- Mở rộng linh hoạt
- Làm việc từ xa
- Tiết kiệm chi phí

## Tổng đài ảo OnePOS

OnePOS cung cấp tổng đài ảo Cloud PBX với đầy đủ tính năng, agent làm việc trên trình duyệt, mobile hoặc IP Phone.`,
    category: 'Tổng đài',
    date: '2026-08-20',
    readingTime: '6 phút',
    seoTitle: 'Tổng đài ảo hoạt động như thế nào? Hướng dẫn chi tiết',
    metaDescription: 'Tổng đài ảo (Virtual PBX) hoạt động trên Cloud sử dụng VoIP. Tìm hiểu cơ chế, công nghệ và ưu điểm của tổng đài ảo.',
    faqs: [
      { question: 'Tổng đài ảo có cần Internet không?', answer: 'Có. Tổng đài ảo hoạt động qua Internet, cần kết nối ổn định.' },
      { question: 'Tổng đài ảo có chất lượng tốt không?', answer: 'Với kết nối Internet ổn định, chất lượng cuộc gọi ngang ngang tổng đài truyền thống.' },
    ],
  },
  {
    slug: 'call-center-vs-contact-center',
    title: 'Call Center và Contact Center khác nhau thế nào?',
    excerpt: 'Call Center tập trung vào kênh thoại, Contact Center mở rộng sang nhiều kênh. Bài viết so sánh chi tiết hai giải pháp.',
    content: `## Call Center vs Contact Center

Nhiều doanh nghiệp nhầm lẫn Call Center và Contact Center. Bài viết so sánh chi tiết để bạn chọn giải pháp phù hợp.

## Bảng so sánh

| Tiêu chí | Call Center | Contact Center |
|----------|------------|---------------|
| Kênh | Thoại | Thoại + Chat + Email + MXH |
| Phạm vi | Cuộc gọi | Toàn bộ tương tác |
| Agent | Xử lý cuộc gọi | Xử lý đa kênh |
| Dữ liệu | Cuộc gọi | Đa kênh |
| Phù hợp | Telesales, CSKH qua gọi | CSKH đa kênh |

## Khi nào chọn Call Center?

- Doanh nghiệp chỉ cần xử lý cuộc gọi
- Đội ngũ telesales gọi ra
- Khách hàng chủ yếu liên lạc qua điện thoại
- Ngân sách hạn chế

## Khi nào chọn Contact Center?

- Khách liên lạc qua nhiều kênh
- Cần chăm sóc đa kênh
- Có team chat, email, mạng xã hội
- Muốn hợp nhất dữ liệu khách hàng

## OnePOS hỗ trợ cả hai

OnePOS cung cấp cả Call Center và Contact Center. Bạn có thể bắt đầu với Call Center và nâng cấp lên Contact Center khi cần.`,
    category: 'Call Center',
    date: '2026-08-21',
    readingTime: '5 phút',
    seoTitle: 'Call Center và Contact Center khác nhau thế nào?',
    metaDescription: 'So sánh Call Center và Contact Center — khác biệt về kênh, phạm vi, agent và khi nào chọn giải pháp nào.',
    faqs: [
      { question: 'Nên chọn Call Center hay Contact Center?', answer: 'Nếu chỉ cần xử lý cuộc gọi, chọn Call Center. Nếu cần chăm sóc đa kênh, chọn Contact Center.' },
      { question: 'Có thể nâng cấp từ Call Center lên Contact Center không?', answer: 'Có. OnePOS cho phép bắt đầu với Call Center và thêm kênh chat, email khi cần.' },
    ],
  },
  {
    slug: 'telesales-su-dung-crm-nhu-the-nao',
    title: 'Telesales nên sử dụng CRM như thế nào?',
    excerpt: 'CRM giúp đội telesales quản lý lead, gọi có kịch bản, ghi chú và đo lường KPI. Hướng dẫn cách telesales dùng CRM hiệu quả.',
    content: `## Telesales nên sử dụng CRM như thế nào?

CRM là công cụ không thể thiếu cho đội telesales. Bài viết hướng dẫn cách telesales sử dụng CRM để tăng hiệu suất.

## 1. Quản lý danh sách lead

Tải danh sách khách hàng cần gọi vào CRM. Mỗi lead có trạng thái: mới, đang gọi, đã liên lạc, không liên lạc, chốt, từ chối.

## 2. Click-to-Call

Thay vì bấm số thủ công, agent click vào số điện thoại trong CRM để gọi. Tiết kiệm thời gian, tránh sai số.

## 3. Kịch bản gọi

Mỗi chiến dịch có kịch bản riêng. Khi agent gọi, kịch bản hiển thị trực tiếp — agent biết phải nói gì.

## 4. Ghi chú sau cuộc gọi

Sau mỗi cuộc gọi, agent ghi kết quả vào CRM. Ghi chú giúp lần gọi sau hiệu quả hơn.

## 5. Phân loại lead

Phân loại lead theo mức quan tâm: nóng, ấm, lạnh. Ưu tiên gọi lại lead nóng.

## 6. Theo dõi Pipeline

Lead chuyển qua các giai đoạn phễu: tiếp xúc → tư vấn → báo giá → chốt. Pipeline giúp không bỏ lỡ cơ hội.

## 7. Đo lường KPI

CRM theo dõi KPI: số cuộc gọi, thời gian gọi, tỷ lệ liên lạc, tỷ lệ chốt. Supervisor xem realtime.

## 8. Lên lịch gọi lại

CRM nhắc agent gọi lại khi khách bận hoặc hẹn giờ. Không bỏ lỡ cơ hội.

## CRM OnePOS cho Telesales

OnePOS Telesales Workspace tích hợp CRM, click-to-call, kịch bản, ghi chú, pipeline và KPI trên một màn hình duy nhất.`,
    category: 'Telesales',
    date: '2026-08-22',
    readingTime: '6 phút',
    seoTitle: 'Telesales nên sử dụng CRM như thế nào? Hướng dẫn 8 bước',
    metaDescription: 'CRM giúp telesales quản lý lead, gọi có kịch bản, ghi chú và đo lường KPI. Hướng dẫn cách telesales dùng CRM hiệu quả.',
    faqs: [
      { question: 'Telesales có cần CRM không?', answer: 'Có. CRM giúp telesales quản lý lead, gọi hiệu quả và đo lường KPI.' },
      { question: 'CRM nào tốt cho telesales?', answer: 'CRM tích hợp click-to-call, kịch bản gọi và KPI như OnePOS Telesales Workspace.' },
    ],
  },
  {
    slug: 'ai-voicebot-la-gi',
    title: 'AI Voicebot là gì? Trợ lý giọng nói AI cho doanh nghiệp',
    excerpt: 'AI Voicebot (AI Voice Agent) là trợ lý AI có thể nghe, hiểu và phản hồi khách hàng bằng giọng nói. Tìm hiểu cách hoạt động và ứng dụng.',
    content: `## AI Voicebot là gì?

AI Voicebot (AI Voice Agent) là trợ lý ảo sử dụng trí tuệ nhân tạo để **nghe, hiểu và phản hồi** khách hàng bằng giọng nói tự nhiên.

## AI Voicebot hoạt động như thế nào?

### 1. Nghe (Speech-to-Text)

AI chuyển giọng nói của khách hàng thành văn bản.

### 2. Hiểu (NLU)

AI phân tích văn bản, nhận diện ý định (intent) và thực thể (entity).

### 3. Xử lý

AI tra cứu cơ sở kiến thức hoặc thực hiện hành động theo kịch bản.

### 4. Nói (Text-to-Speech)

AI chuyển câu trả lời thành giọng nói tự nhiên.

### 5. Chuyển agent

Khi AI không xử lý được, cuộc gọi chuyển cho agent người thật.

## Ứng dụng AI Voicebot

### Tiếp nhận cuộc gọi 24/7

AI Voicebot tiếp nhận cuộc gọi ngoài giờ làm việc, trả lời câu hỏi phổ biến.

### Xác nhận đơn hàng

AI gọi xác nhận đơn hàng, lịch hẹn tự động.

### Telesales tự động

AI gọi ra khách hàng theo chiến dịch, giới thiệu sản phẩm.

### Chăm sóc khách hàng

AI trả lời câu hỏi về sản phẩm, giá, giờ làm việc.

## AI Voicebot OnePOS

OnePOS AI Voice Agent hỗ trợ tiếng Việt, nhận diện ý định, chuyển agent mượt mà. Tích hợp Auto Call và CRM.`,
    category: 'AI',
    date: '2026-08-23',
    readingTime: '6 phút',
    seoTitle: 'AI Voicebot là gì? Trợ lý giọng nói AI cho doanh nghiệp',
    metaDescription: 'AI Voicebot là trợ lý AI nghe và nói với khách hàng bằng giọng nói. Tìm hiểu cách hoạt động, ứng dụng và lợi ích.',
    faqs: [
      { question: 'AI Voicebot có hiểu tiếng Việt không?', answer: 'Có. AI Voicebot OnePOS được tối ưu cho tiếng Việt.' },
      { question: 'AI Voicebot có thay thế agent không?', answer: 'AI xử lý câu hỏi phổ biến, agent xử lý trường hợp phức tạp. AI bổ trợ, không thay thế hoàn toàn.' },
    ],
  },
  {
    slug: 'auto-call-la-gi',
    title: 'Auto Call là gì? Tự động hóa chiến dịch gọi ra',
    excerpt: 'Auto Call là tính năng tự động quay số theo danh sách khách hàng. Tìm hiểu Auto Call là gì và ứng dụng cho telesales.',
    content: `## Auto Call là gì?

Auto Call là tính năng tự động thực hiện cuộc gọi ra theo danh sách khách hàng. Hệ thống tự quay số, khi khách bắt máy, chuyển cuộc gọi cho agent hoặc AI.

## Auto Call hoạt động như thế nào?

1. **Tạo chiến dịch:** Tải danh sách khách hàng, thiết lập kịch bản
2. **Quay số tự động:** Hệ thống gọi lần lượt từng số
3. **Phát hiện máy nghe:** AI phát hiện khi khách bắt máy
4. **Chuyển agent/AI:** Cuộc gọi chuyển cho agent hoặc AI xử lý
5. **Ghi âm & báo cáo:** Mọi cuộc gọi được ghi âm, báo cáo tự động

## Ứng dụng Auto Call

### Telesales

Gọi hàng loạt khách hàng giới thiệu sản phẩm, không cần agent bấm số.

### Nhắc lịch hẹn

Tự động gọi nhắc khách đến hẹn, giảm no-show.

### Xác nhận đơn hàng

Gọi xác nhận đơn hàng COD tự động.

### Thu hồi nợ

Gọi nhắc khách thanh toán đúng hạn.

## Lợi ích Auto Call

- **Tiết kiệm thời gian:** Agent không bấm số thủ công
- **Tỷ lệ liên lạc cao:** Tự động gọi lại khi không liên lạc
- **Lên lịch linh hoạt:** Gọi theo khung giờ quy định
- **Báo cáo tức thì:** Số cuộc gọi, tỷ lệ bắt máy realtime

## Auto Call OnePOS

OnePOS Auto Call tích hợp AI Voice Agent, CRM và Call Recording — tự động hóa toàn bộ chiến dịch gọi ra.`,
    category: 'Telesales',
    date: '2026-08-24',
    readingTime: '5 phút',
    seoTitle: 'Auto Call là gì? Tự động hóa chiến dịch gọi ra',
    metaDescription: 'Auto Call là tính năng tự động quay số theo danh sách khách hàng. Tìm hiểu cách hoạt động, ứng dụng và lợi ích.',
    faqs: [
      { question: 'Auto Call có kết hợp AI không?', answer: 'Có. Khi khách bắt máy, cuộc gọi có thể chuyển cho AI Voice Agent hoặc agent người.' },
      { question: 'Auto Call có bị coi là spam không?', answer: 'Nếu tuân thủ danh sách DNC và khung giờ, Auto Call không bị coi là spam.' },
    ],
  },
  {
    slug: 'sip-trunk-la-gi',
    title: 'SIP Trunk là gì? Kết nối tổng đài với nhà mạng',
    excerpt: 'SIP Trunk là dịch vụ kết nối hệ thống tổng đài với nhà cung cấp viễn thông qua Internet. Tìm hiểu SIP Trunk là gì.',
    content: `## SIP Trunk là gì?

SIP Trunk là dịch vụ kết nối hệ thống tổng đài (PBX) với nhà cung cấp viễn thông qua giao thức SIP (Session Initiation Protocol) trên Internet.

## SIP Trunk hoạt động như thế nào?

Thay vì đường dây điện thoại truyền thống, SIP Trunk sử dụng kết nối Internet để truyền cuộc gọi. Điều này giúp:

- Không cần dây điện thoại riêng
- Nhiều cuộc gọi đồng thời trên một kết nối
- Mở rộng số lượng kênh linh hoạt

## Lợi ích SIP Trunk

### Chi phí thấp

SIP Trunk rẻ hơn đường dây truyền thống, đặc biệt khi gọi quốc tế.

### Mở rộng linh hoạt

Thêm kênh cuộc gọi (concurrent calls) theo nhu cầu, không cần lắp đặt thêm dây.

### Kết nối Cloud PBX

SIP Trunk kết nối Cloud PBX với nhà mạng, cho phép gọi ra và nhận cuộc gọi từ số cố định, di động.

### Số đầu số linh hoạt

Gán đầu số 1900, 1800, số cố định hoặc số di động qua SIP Trunk.

## SIP Trunk OnePOS

OnePOS cung cấp SIP Trunk kết nối hệ thống tổng đài với nhà mạng Việt Nam. Bạn có thể giữ số cũ (port number) hoặc đăng ký số mới.`,
    category: 'VoIP',
    date: '2026-08-25',
    readingTime: '5 phút',
    seoTitle: 'SIP Trunk là gì? Kết nối tổng đài với nhà mạng',
    metaDescription: 'SIP Trunk là dịch vụ kết nối tổng đài với nhà mạng qua Internet. Tìm hiểu SIP Trunk là gì, lợi ích và ứng dụng.',
    faqs: [
      { question: 'SIP Trunk có cần Internet nhanh không?', answer: 'Cần kết nối ổn định. Tốc độ tối thiểu tùy số cuộc gọi đồng thời.' },
      { question: 'SIP Trunk khác gì đường dây truyền thống?', answer: 'SIP Trunk dùng Internet, đường dây truyền thống dùng dây đồng. SIP Trunk rẻ và linh hoạt hơn.' },
    ],
  },
  {
    slug: 'xay-dung-he-thong-cham-soc-khach-hang-da-kenh',
    title: 'Cách xây dựng hệ thống chăm sóc khách hàng đa kênh',
    excerpt: 'Hướng dẫn xây dựng hệ thống chăm sóc khách hàng đa kênh (Omnichannel) cho doanh nghiệp — từ chiến lược đến công cụ.',
    content: `## Cách xây dựng hệ thống chăm sóc khách hàng đa kênh

Chăm sóc khách hàng đa kênh (Omnichannel) là xu hướng tất yếu. Bài viết hướng dẫn xây dựng hệ thống Omnichannel cho doanh nghiệp.

## Bước 1: Xác định kênh khách hàng sử dụng

Phân tích khách hàng liên lạc qua kênh nào: gọi, Facebook, Zalo, website, email. Tập trung vào kênh phổ biến nhất trước.

## Bước 2: Hợp nhất kênh

Sử dụng nền tảng Omnichannel hợp nhất mọi kênh vào một inbox. Agent không cần chuyển qua lại nhiều phần mềm.

## Bước 3: Tích hợp CRM

Mỗi khách hàng có hồ sơ trong CRM. Lịch sử tương tác trên mọi kênh được lưu trữ. Agent xem context trước khi trả lời.

## Bước 4: Thiết lập quy trình phân công

Tự động phân cuộc hội thoại cho agent phù hợp dựa trên kỹ năng, tải, ngôn ngữ.

## Bước 5: Đo lường và tối ưu

Theo dõi SLA, CSAT, thời gian phản hồi trên từng kênh. Tối ưu quy trình dựa trên dữ liệu.

## Bước 6: Tự động hóa

Sử dụng AI Chatbot trả lời câu hỏi phổ biến, Auto Call nhắc lịch, SMS/ZNS gửi thông báo.

## Công cụ OnePOS

OnePOS cung cấp đầy đủ công cụ:
- Omnichannel (hợp nhất kênh)
- CRM (quản lý khách hàng)
- AI Chatbot (tự động trả lời)
- Auto Call (tự động gọi)
- SMS & ZNS (thông báo)

Triển khai nhanh trên Cloud, mở rộng linh hoạt.`,
    category: 'Chăm sóc khách hàng',
    date: '2026-08-26',
    readingTime: '7 phút',
    seoTitle: 'Cách xây dựng hệ thống chăm sóc khách hàng đa kênh',
    metaDescription: 'Hướng dẫn xây dựng hệ thống chăm sóc khách hàng đa kênh (Omnichannel) — từ chiến lược đến công cụ cho doanh nghiệp.',
    faqs: [
      { question: 'Chi phí xây dựng hệ thống đa kênh đắt không?', answer: 'Với Cloud, chi phí thấp hơn nhiều so với tự xây dựng. OnePOS trả phí theo sử dụng.' },
      { question: 'Mất bao lâu để triển khai?', answer: 'Với OnePOS, bạn có thể bắt đầu trong vài ngày, không cần triển khai phần cứng.' },
    ],
  },
];

export function getPost(slug: string): BlogPost | undefined {
  return BlogPosts.find((p) => p.slug === slug);
}
