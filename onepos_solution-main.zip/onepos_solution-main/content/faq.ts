export type FAQItem = { question: string; answer: string };
export type FAQCategory = { category: string; items: FAQItem[] };

export const GlobalFAQ: FAQItem[] = [
  {
    question: 'Tổng đài Cloud là gì?',
    answer: 'Tổng đài Cloud (Cloud PBX) là hệ thống tổng đài ảo chạy trên nền tảng Cloud, giúp doanh nghiệp gọi và nhận cuộc gọi qua Internet mà không cần đầu tư phần cứng. Agent làm việc trên trình duyệt, điện thoại di động hoặc IP Phone.',
  },
  {
    question: 'OnePOS có cần lắp tổng đài vật lý không?',
    answer: 'Không. OnePOS hoạt động hoàn toàn trên nền tảng Cloud. Bạn chỉ cần trình duyệt hoặc ứng dụng Softphone để sử dụng, không cần mua hay lắp đặt thiết bị tổng đài vật lý.',
  },
  {
    question: 'Có thể sử dụng trên điện thoại không?',
    answer: 'Có. OnePOS hỗ trợ ứng dụng Softphone trên điện thoại di động (iOS và Android), giúp agent gọi và nhận cuộc gọi mọi lúc mọi nơi.',
  },
  {
    question: 'OnePOS có CRM không?',
    answer: 'Có. OnePOS tích hợp sẵn CRM với Customer 360, Lead Management, Pipeline, Deal và Activity. CRM kết nối trực tiếp với tổng đài — gọi từ CRM và xem lịch sử cuộc gọi.',
  },
  {
    question: 'Có thể tích hợp Zalo không?',
    answer: 'Có. OnePOS Omnichannel kết nối Zalo Official Account, giúp bạn nhận và trả lời tin nhắn Zalo trên cùng inbox chung với các kênh khác.',
  },
  {
    question: 'Có thể tích hợp Facebook không?',
    answer: 'Có. OnePOS kết nối Facebook Messenger, cho phép quản lý tin nhắn từ nhiều Fanpage trên một inbox duy nhất.',
  },
  {
    question: 'Có thể gọi trực tiếp từ CRM không?',
    answer: 'Có. CRM OnePOS tích hợp Click-to-Call — bạn click vào số điện thoại trong CRM để gọi, không cần bấm số thủ công. Lịch sử cuộc gọi tự động lưu vào hồ sơ khách hàng.',
  },
  {
    question: 'Có hỗ trợ Call Center không?',
    answer: 'Có. OnePOS cung cấp giải pháp Call Center đầy đủ tính năng: Agent, Queue, Supervisor, Monitor, Whisper, Wallboard, Call Recording và KPI.',
  },
  {
    question: 'Có hỗ trợ AI Voice Agent không?',
    answer: 'Có. OnePOS AI Voice Agent có thể nghe, hiểu và phản hồi khách hàng bằng giọng nói tự nhiên, hỗ trợ tiếng Việt và chuyển cho agent khi cần.',
  },
  {
    question: 'Có API không?',
    answer: 'Có. OnePOS cung cấp API, Web SDK, Mobile SDK và Webhook để tích hợp với hệ thống doanh nghiệp. Xem tài liệu tại trang Developer.',
  },
  {
    question: 'Có hỗ trợ doanh nghiệp SME không?',
    answer: 'Có. OnePOS phù hợp cho mọi quy mô — từ cá nhân, startup, SME đến Enterprise. Bạn bắt đầu với gói nhỏ và mở rộng khi doanh nghiệp phát triển.',
  },
  {
    question: 'Có thể mở rộng số lượng Agent không?',
    answer: 'Có. OnePOS mở rộng linh hoạt — thêm agent và máy lẻ theo nhu cầu, không cần nâng cấp hạ tầng. Phù hợp cho doanh nghiệp đang tăng trưởng.',
  },
];

export const FAQCategories: FAQCategory[] = [
  {
    category: 'Tổng đài & Call Center',
    items: [
      { question: 'Tổng đài Cloud là gì?', answer: 'Tổng đài Cloud (Cloud PBX) là hệ thống tổng đài ảo chạy trên Cloud, không cần phần cứng. Agent làm việc trên trình duyệt, mobile hoặc IP Phone.' },
      { question: 'OnePOS có cần lắp tổng đài vật lý không?', answer: 'Không. OnePOS hoạt động hoàn toàn trên Cloud, không cần phần cứng.' },
      { question: 'Có thể sử dụng trên điện thoại không?', answer: 'Có. OnePOS hỗ trợ Softphone trên iOS và Android.' },
      { question: 'Có hỗ trợ Call Center không?', answer: 'Có. OnePOS có đầy đủ tính năng Call Center: Agent, Queue, Supervisor, Monitor, Wallboard, KPI.' },
    ],
  },
  {
    category: 'CRM & Telesales',
    items: [
      { question: 'OnePOS có CRM không?', answer: 'Có. CRM OnePOS có Customer 360, Lead, Pipeline, Deal, Activity, tích hợp tổng đài.' },
      { question: 'Có thể gọi trực tiếp từ CRM không?', answer: 'Có. Click-to-Call cho phép gọi từ CRM, lịch sử tự động lưu.' },
    ],
  },
  {
    category: 'Omnichannel',
    items: [
      { question: 'Có thể tích hợp Zalo không?', answer: 'Có. OnePOS kết nối Zalo Official Account.' },
      { question: 'Có thể tích hợp Facebook không?', answer: 'Có. OnePOS kết nối Facebook Messenger, quản lý nhiều Fanpage.' },
    ],
  },
  {
    category: 'AI',
    items: [
      { question: 'Có hỗ trợ AI Voice Agent không?', answer: 'Có. AI Voice Agent OnePOS nghe, hiểu và phản hồi bằng giọng nói, hỗ trợ tiếng Việt.' },
      { question: 'AI Chatbot có cần lập trình không?', answer: 'Không. Bạn cấu hình kịch bản và cơ sở kiến thức qua giao diện trực quan.' },
    ],
  },
  {
    category: 'Developer & Tích hợp',
    items: [
      { question: 'Có API không?', answer: 'Có. OnePOS cung cấp API, Web SDK, Mobile SDK và Webhook.' },
      { question: 'Có thể mở rộng số lượng Agent không?', answer: 'Có. Thêm agent linh hoạt, không cần nâng cấp hạ tầng.' },
    ],
  },
];
