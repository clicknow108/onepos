export const SiteConfig = {
  name: 'OnePOS',
  tagline: 'Nền tảng kết nối khách hàng cho doanh nghiệp',
  title: 'OnePOS - Tổng Đài Cloud, Call Center, CRM & AI cho Doanh Nghiệp',
  description:
    'OnePOS cung cấp nền tảng tổng đài Cloud, Call Center, Contact Center, CRM, Omnichannel và AI giúp doanh nghiệp quản lý khách hàng, tăng hiệu suất Sales và tự động hóa chăm sóc khách hàng.',
  url: 'https://onepos.vn',
  keywords: [
    'tổng đài ảo',
    'tổng đài cloud',
    'tổng đài doanh nghiệp',
    'tổng đài IP',
    'tổng đài VoIP',
    'call center',
    'contact center',
    'cloud call center',
    'CRM',
    'phần mềm CRM',
    'omnichannel',
    'chăm sóc khách hàng đa kênh',
    'AI Voicebot',
    'AI chatbot',
    'phần mềm telesales',
    'auto call',
    'SIP trunk',
    'SMS brandname',
    'Zalo ZNS',
  ],
  contact: {
    hotline: '1900 xxxx',
    email: 'contact@onepos.vn',
    address: 'TP. Hồ Chí Minh, Việt Nam',
    supportHours: '8:00 - 18:00 (Thứ 2 - Thứ 7)',
  },
  social: {
    facebook: '#',
    linkedin: '#',
    youtube: '#',
    zalo: '#',
  },
};

export type NavChildItem = {
  label: string;
  href: string;
  description?: string;
};

export type NavGroup = {
  label: string;
  items: NavChildItem[];
};

export type NavColumn = {
  title: string;
  items: NavChildItem[];
};

export type MegaMenuItem = {
  label: string;
  href: string;
  columns: NavColumn[];
};

export type SimpleNavItem = {
  label: string;
  href: string;
  children?: NavChildItem[];
};

export const Navigation: {
  products: MegaMenuItem;
  solutions: SimpleNavItem;
  pricing: SimpleNavItem;
  resources: SimpleNavItem;
  about: SimpleNavItem;
} = {
  products: {
    label: 'Sản phẩm',
    href: '/san-pham',
    columns: [
      {
        title: 'Tổng đài & Call Center',
        items: [
          { label: 'Tổng đài ảo Cloud PBX', href: '/san-pham/tong-dai-cloud', description: 'Tổng đài doanh nghiệp trên Cloud' },
          { label: 'Call Center', href: '/san-pham/call-center', description: 'Quản lý đội ngũ Sales & CSKH' },
          { label: 'Contact Center', href: '/san-pham/contact-center', description: 'Kết nối đa kênh trên một nền tảng' },
          { label: 'Auto Call', href: '/san-pham/auto-call', description: 'Tự động hóa chiến dịch gọi ra' },
          { label: 'Telesales', href: '/san-pham/telesales', description: 'Không gian làm việc cho telesales' },
        ],
      },
      {
        title: 'Omnichannel',
        items: [
          { label: 'Chat đa kênh', href: '/san-pham/omnichannel', description: 'Hợp nhất mọi cuộc hội thoại' },
          { label: 'Facebook Messenger', href: '/san-pham/omnichannel', description: 'Kết nối Fanpage' },
          { label: 'Zalo', href: '/san-pham/omnichannel', description: 'Chat Zalo Official Account' },
          { label: 'Live Chat', href: '/san-pham/omnichannel', description: 'Chat trực tiếp trên website' },
          { label: 'WhatsApp', href: '/san-pham/omnichannel', description: 'Nhắn tin WhatsApp Business' },
          { label: 'Email', href: '/san-pham/omnichannel', description: 'Quản lý email khách hàng' },
        ],
      },
      {
        title: 'CRM & Sales',
        items: [
          { label: 'CRM', href: '/san-pham/crm', description: 'Quản lý dữ liệu khách hàng' },
          { label: 'Customer 360', href: '/san-pham/crm', description: 'Tầm nhìn 360° khách hàng' },
          { label: 'Lead Management', href: '/san-pham/crm', description: 'Quản lý khách hàng tiềm năng' },
          { label: 'Sales Pipeline', href: '/san-pham/crm', description: 'Quản lý phễu bán hàng' },
          { label: 'Ticket', href: '/san-pham/contact-center', description: 'Quản lý yêu cầu hỗ trợ' },
          { label: 'Telesales Workspace', href: '/san-pham/telesales', description: 'Bàn làm việc telesales' },
        ],
      },
      {
        title: 'AI',
        items: [
          { label: 'AI Voice Agent', href: '/san-pham/ai-voice-agent', description: 'AI nghe và nói với khách hàng' },
          { label: 'Voicebot', href: '/san-pham/ai-voice-agent', description: 'Trợ lý giọng nói AI' },
          { label: 'AI Chatbot', href: '/san-pham/ai-chatbot', description: 'Trợ lý AI 24/7' },
          { label: 'AI Call Analysis', href: '/san-pham/ai-call-analytics', description: 'Phân tích cuộc gọi bằng AI' },
          { label: 'AI Call Scoring', href: '/san-pham/ai-call-analytics', description: 'Đánh giá chất lượng cuộc gọi' },
          { label: 'AI Assistant', href: '/san-pham/ai-chatbot', description: 'Trợ lý AI thông minh' },
        ],
      },
      {
        title: 'Viễn thông',
        items: [
          { label: 'Đầu số tổng đài', href: '/san-pham/sip-trunk', description: '1900, 1800, Fixed, Mobile SIP' },
          { label: 'SIP Trunk', href: '/san-pham/sip-trunk', description: 'Kết nối hệ thống tổng đài' },
          { label: '1900', href: '/san-pham/sip-trunk', description: 'Hotline chia sẻ cước' },
          { label: '1800', href: '/san-pham/sip-trunk', description: 'Hotline miễn phí cước' },
          { label: 'Voice Brandname', href: '/san-pham/sip-trunk', description: 'Hiển thị thương hiệu khi gọi ra' },
          { label: 'SMS Brandname', href: '/san-pham/sms-brandname', description: 'Gửi SMS thương hiệu' },
          { label: 'Zalo ZNS', href: '/san-pham/zalo-zns', description: 'Thông báo qua Zalo' },
        ],
      },
      {
        title: 'Developer',
        items: [
          { label: 'API', href: '/developers', description: 'Tích hợp hệ thống' },
          { label: 'Web SDK', href: '/developers', description: 'SDK cho web' },
          { label: 'Mobile SDK', href: '/developers', description: 'SDK cho mobile' },
          { label: 'Webhook', href: '/developers', description: 'Nhận sự kiện realtime' },
          { label: 'Integration', href: '/developers', description: 'Kết nối hệ thống' },
        ],
      },
    ],
  },
  solutions: {
    label: 'Giải pháp',
    href: '/giai-phap',
    children: [
      { label: 'Telesales', href: '/giai-phap/telesales' },
      { label: 'Chăm sóc khách hàng', href: '/giai-phap/cham-soc-khach-hang' },
      { label: 'Call Center', href: '/giai-phap/call-center' },
      { label: 'Contact Center', href: '/giai-phap/contact-center' },
      { label: 'Marketing', href: '/giai-phap/marketing' },
      { label: 'Tự động hóa', href: '/giai-phap/tu-dong-hoa' },
      { label: 'AI Customer Service', href: '/giai-phap/ai-customer-service' },
    ],
  },
  pricing: {
    label: 'Bảng giá',
    href: '/bang-gia',
  },
  resources: {
    label: 'Tài nguyên',
    href: '/blog',
    children: [
      { label: 'Blog', href: '/blog' },
      { label: 'Case Study', href: '/case-study' },
      { label: 'Hướng dẫn sử dụng', href: '/blog' },
      { label: 'Tài liệu API', href: '/developers' },
      { label: 'Kiến thức Call Center', href: '/blog' },
      { label: 'Kiến thức CRM', href: '/blog' },
      { label: 'Kiến thức AI', href: '/blog' },
    ],
  },
  about: {
    label: 'Về OnePOS',
    href: '/ve-onepos',
    children: [
      { label: 'Giới thiệu', href: '/ve-onepos' },
      { label: 'Đối tác', href: '/ve-onepos#doi-tac' },
      { label: 'Liên hệ', href: '/lien-he' },
      { label: 'Tuyển dụng', href: '/ve-onepos#tuyen-dung' },
    ],
  },
};
