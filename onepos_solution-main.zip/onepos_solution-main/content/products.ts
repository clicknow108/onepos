export type ProductFeature = {
  label: string;
  description?: string;
};

export type ProductDetail = {
  slug: string;
  name: string;
  shortName?: string;
  tagline: string;
  description: string;
  icon: string;
  category: string;
  features: ProductFeature[];
  benefits: { title: string; description: string }[];
  dashboardType: 'pbx' | 'callcenter' | 'crm' | 'omnichannel' | 'telesales' | 'ai' | 'autocall' | 'telecom' | 'generic';
  faqs: { question: string; answer: string }[];
};

export const Products: ProductDetail[] = [
  {
    slug: 'tong-dai-cloud',
    name: 'Tổng đài ảo Cloud PBX',
    shortName: 'Tổng đài Cloud',
    tagline: 'Tổng đài doanh nghiệp trên nền tảng Cloud, làm việc mọi lúc mọi nơi',
    description:
      'Tổng đài ảo Cloud PBX của OnePOS giúp doanh nghiệp triển khai hệ thống tổng đài mà không cần đầu tư phần cứng phức tạp. Agent có thể làm việc trên trình duyệt, điện thoại di động hoặc IP Phone — mọi lúc, mọi nơi.',
    icon: 'Cloud',
    category: 'Tổng đài & Call Center',
    dashboardType: 'pbx',
    features: [
      { label: 'IVR', description: 'Điều hướng cuộc gọi tự động theo phím bấm' },
      { label: 'Ring Group', description: 'Nhóm đổ chuông nhiều máy lẻ' },
      { label: 'Queue', description: 'Hàng đợi cuộc gọi chuyên nghiệp' },
      { label: 'Call Recording', description: 'Tự động ghi âm mọi cuộc gọi' },
      { label: 'Call Forwarding', description: 'Chuyển cuộc gọi linh hoạt' },
      { label: 'Extension', description: 'Quản lý máy lẻ không giới hạn' },
      { label: 'Realtime Monitoring', description: 'Giám sát cuộc gọi theo thời gian thực' },
      { label: 'Voicemail', description: 'Hộp thư thoại cho mỗi máy lẻ' },
      { label: 'Call Parking', description: 'Gác cuộc gọi và chuyển giữa các agent' },
      { label: 'Call History', description: 'Lịch sử cuộc gọi đầy đủ' },
    ],
    benefits: [
      { title: 'Không cần phần cứng', description: 'Triển khai ngay trên Cloud, không cần mua tổng đài vật lý hay máy chủ riêng.' },
      { title: 'Làm việc từ xa', description: 'Agent làm việc trên trình duyệt, mobile hoặc IP Phone — ở văn phòng hay tại nhà.' },
      { title: 'Mở rộng linh hoạt', description: 'Thêm máy lẻ và agent theo nhu cầu, không giới hạn hạ tầng.' },
      { title: 'Tiết kiệm chi phí', description: 'Trả phí theo sử dụng, không cần bảo trì phần cứng hay nâng cấp hệ thống.' },
    ],
    faqs: [
      { question: 'Tổng đài Cloud có cần lắp đặt phần cứng không?', answer: 'Không. Tổng đài Cloud PBX hoạt động hoàn toàn trên nền tảng Cloud, bạn chỉ cần trình duyệt hoặc ứng dụng để sử dụng.' },
      { question: 'Có thể dùng điện thoại di động làm máy lẻ không?', answer: 'Có. Bạn có thể sử dụng ứng dụng Softphone trên điện thoại di động hoặc máy tính để trở thành máy lẻ của tổng đài.' },
      { question: 'Tổng đài Cloud có ghi âm cuộc gọi không?', answer: 'Có. Mọi cuộc gọi đều được tự động ghi âm và lưu trữ, bạn có thể nghe lại bất cứ lúc nào.' },
    ],
  },
  {
    slug: 'call-center',
    name: 'Call Center',
    tagline: 'Giải pháp quản lý đội ngũ Sales và CSKH chuyên nghiệp',
    description:
      'Call Center OnePOS biến đội ngũ của bạn thành một trung tâm cuộc gọi chuyên nghiệp với đầy đủ tính năng quản lý agent, hàng đợi, giám sát và báo cáo — giúp tối ưu hiệu suất và chất lượng phục vụ.',
    icon: 'Headphones',
    category: 'Tổng đài & Call Center',
    dashboardType: 'callcenter',
    features: [
      { label: 'Agent', description: 'Quản lý agent và phân quyền' },
      { label: 'Queue', description: 'Hàng đợi cuộc gọi thông minh' },
      { label: 'Supervisor', description: 'Giám sát toàn bộ hoạt động' },
      { label: 'Monitor', description: 'Nghe lén cuộc gọi trực tiếp' },
      { label: 'Whisper', description: 'Thì thầm hướng dẫn agent' },
      { label: 'Listen', description: 'Nghe cuộc gọi không can thiệp' },
      { label: 'Wallboard', description: 'Bảng điều khiển realtime' },
      { label: 'Call Recording', description: 'Ghi âm mọi cuộc gọi' },
      { label: 'KPI', description: 'Đo lường hiệu suất agent' },
      { label: 'Inbound / Outbound', description: 'Nhận và gọi ra khách hàng' },
    ],
    benefits: [
      { title: 'Giám sát realtime', description: 'Supervisor theo dõi toàn bộ agent, hàng đợi và cuộc gọi theo thời gian thực.' },
      { title: 'Tối ưu hiệu suất', description: 'Đo lường KPI agent, thời gian đàm thoại, tỷ lệ trả lời và nhiều chỉ số khác.' },
      { title: 'Chất lượng phục vụ', description: 'Nghe, thì thầm, can thiệp cuộc gọi để đảm bảo chất lượng phục vụ khách hàng.' },
      { title: 'Báo cáo chi tiết', description: 'Báo cáo tự động theo ngày, tuần, tháng với đầy đủ chỉ số Call Center.' },
    ],
    faqs: [
      { question: 'Call Center OnePOS phù hợp cho doanh nghiệp nào?', answer: 'Call Center OnePOS phù hợp với mọi doanh nghiệp có đội ngũ Sales hoặc CSKH, từ vài agent đến hàng trăm agent.' },
      { question: 'Có thể giám sát agent realtime không?', answer: 'Có. Supervisor có thể xem trạng thái agent, nghe lén, thì thầm và can thiệp cuộc gọi theo thời gian thực.' },
      { question: 'Wallboard hiển thị những gì?', answer: 'Wallboard hiển thị số agent online, cuộc gọi chờ, SLA, tỷ lệ trả lời, thời gian đàm thoại trung bình và nhiều chỉ số khác.' },
    ],
  },
  {
    slug: 'contact-center',
    name: 'Contact Center',
    tagline: 'Kết nối khách hàng qua thoại và các kênh kỹ thuật số trên một nền tảng',
    description:
      'Contact Center OnePOS hợp nhất kênh thoại và các kênh kỹ thuật số (chat, Zalo, Facebook, email) vào một hệ thống duy nhất — giúp doanh nghiệp chăm sóc khách hàng xuyên suốt trên mọi điểm chạm.',
    icon: 'MessageSquare',
    category: 'Tổng đài & Call Center',
    dashboardType: 'omnichannel',
    features: [
      { label: 'Voice', description: 'Quản lý cuộc gọi thoại' },
      { label: 'Chat', description: 'Chat trực tiếp với khách hàng' },
      { label: 'Zalo', description: 'Kết nối Zalo Official Account' },
      { label: 'Facebook', description: 'Tích hợp Facebook Messenger' },
      { label: 'Livechat', description: 'Chat trên website' },
      { label: 'Email', description: 'Quản lý email khách hàng' },
      { label: 'Ticket', description: 'Quản lý yêu cầu hỗ trợ' },
      { label: 'Customer 360', description: 'Tầm nhìn toàn cảnh khách hàng' },
    ],
    benefits: [
      { title: 'Một hệ thống duy nhất', description: 'Không cần nhiều phần mềm cho từng kênh — tất cả trên một nền tảng.' },
      { title: 'Hành trình khách hàng', description: 'Theo dõi toàn bộ lịch sử tương tác khách hàng trên mọi kênh.' },
      { title: 'Phân công thông minh', description: 'Tự động phân cuộc hội thoại cho agent phù hợp dựa trên kỹ năng và tải.' },
      { title: 'Báo cáo đa kênh', description: 'Đo lường hiệu quả trên từng kênh và tổng thể toàn bộ Contact Center.' },
    ],
    faqs: [
      { question: 'Contact Center khác gì với Call Center?', answer: 'Call Center tập trung vào kênh thoại, trong khi Contact Center hợp nhất cả kênh thoại và các kênh kỹ thuật số như chat, Zalo, Facebook, email.' },
      { question: 'Có thể quản lý nhiều Fanpage Facebook không?', answer: 'Có. Bạn có thể kết nối nhiều Fanpage Facebook và quản lý tất cả tin nhắn trên một inbox chung.' },
      { question: 'Ticket quản lý như thế nào?', answer: 'Mỗi yêu cầu hỗ trợ được tạo thành ticket với trạng thái, mức ưu tiên, người phụ trách và deadline rõ ràng.' },
    ],
  },
  {
    slug: 'omnichannel',
    name: 'Omnichannel',
    tagline: 'Hợp nhất các cuộc hội thoại vào một inbox duy nhất',
    description:
      'Omnichannel OnePOS gom tất cả cuộc trò chuyện từ Facebook, Zalo, Website, WhatsApp, Email và Livechat vào một inbox thống nhất — agent không cần chuyển qua lại giữa nhiều phần mềm.',
    icon: 'MessagesSquare',
    category: 'Omnichannel',
    dashboardType: 'omnichannel',
    features: [
      { label: 'Facebook', description: 'Tích hợp Facebook Messenger' },
      { label: 'Zalo', description: 'Kết nối Zalo Official Account' },
      { label: 'Website', description: 'Live chat trên website' },
      { label: 'WhatsApp', description: 'WhatsApp Business' },
      { label: 'Email', description: 'Quản lý email khách hàng' },
      { label: 'Livechat', description: 'Chat realtime' },
      { label: 'TikTok', description: 'Kết nối TikTok' },
      { label: 'Unified Inbox', description: 'Một inbox cho mọi kênh' },
    ],
    benefits: [
      { title: 'Không bỏ lỡ tin nhắn', description: 'Mọi tin nhắn từ mọi kênh đều hiển thị trên một inbox duy nhất.' },
      { title: 'Agent hiệu quả hơn', description: 'Agent không cần chuyển qua lại giữa nhiều phần mềm, trả lời nhanh hơn.' },
      { title: 'Context xuyên suốt', description: 'Lịch sử trò chuyện trên mọi kênh được lưu trữ cho mỗi khách hàng.' },
      { title: 'Phân công tự động', description: 'Tự động phân cuộc hội thoại cho agent dựa trên quy tắc và kỹ năng.' },
    ],
    faqs: [
      { question: 'Omnichannel hỗ trợ những kênh nào?', answer: 'OnePOS hỗ trợ Facebook Messenger, Zalo, Website Livechat, WhatsApp, Email và TikTok — tất cả trên một inbox chung.' },
      { question: 'Có thể kết nối nhiều Fanpage không?', answer: 'Có. Bạn có thể kết nối nhiều Fanpage Facebook và nhiều Zalo OA cùng lúc.' },
      { question: 'Lịch sử chat có được lưu không?', answer: 'Có. Mọi cuộc hội thoại đều được lưu trữ và gắn với hồ sơ khách hàng trong CRM.' },
    ],
  },
  {
    slug: 'crm',
    name: 'CRM',
    tagline: 'Quản lý toàn bộ dữ liệu khách hàng và lịch sử tương tác',
    description:
      'CRM OnePOS giúp doanh nghiệp quản lý toàn bộ dữ liệu khách hàng, lịch sử tương tác, cơ hội bán hàng và hoạt động trên một hệ thống — không còn dữ liệu nằm rải rác ở nhiều phần mềm.',
    icon: 'Users',
    category: 'CRM & Sales',
    dashboardType: 'crm',
    features: [
      { label: 'Customer 360', description: 'Tầm nhìn 360° khách hàng' },
      { label: 'Lead', description: 'Quản lý khách hàng tiềm năng' },
      { label: 'Contact', description: 'Quản lý danh bạ khách hàng' },
      { label: 'Pipeline', description: 'Quản lý phễu bán hàng' },
      { label: 'Deal', description: 'Theo dõi cơ hội kinh doanh' },
      { label: 'Activity', description: 'Lịch sử hoạt động' },
      { label: 'Notes', description: 'Ghi chú khách hàng' },
      { label: 'Timeline', description: 'Dòng thời gian tương tác' },
    ],
    benefits: [
      { title: 'Dữ liệu tập trung', description: 'Mọi thông tin khách hàng, cuộc gọi, tin nhắn, giao dịch đều ở một nơi.' },
      { title: 'Tầm nhìn 360°', description: 'Hiểu rõ khách hàng trước khi gọi — lịch sử, sở thích, giao dịch, tương tác.' },
      { title: 'Tăng tỷ lệ chốt', description: 'Pipeline và deal giúp Sales theo dõi cơ hội và không bỏ lỡ giao dịch.' },
      { title: 'Tự động hóa', description: 'Tự động phân công lead, nhắc việc, và theo dõi hoạt động Sales.' },
    ],
    faqs: [
      { question: 'CRM OnePOS có tích hợp với tổng đài không?', answer: 'Có. CRM tích hợp sẵn với tổng đài Cloud, bạn có thể gọi trực tiếp từ CRM và xem lịch sử cuộc gọi của khách hàng.' },
      { question: 'Có thể tùy chỉnh pipeline không?', answer: 'Có. Bạn có thể tạo nhiều pipeline với các giai đoạn tùy chỉnh theo quy trình bán hàng của doanh nghiệp.' },
      { question: 'Dữ liệu CRM có an toàn không?', answer: 'Dữ liệu được lưu trữ trên Cloud với phân quyền chi tiết, chỉ người có quyền mới xem được.' },
    ],
  },
  {
    slug: 'telesales',
    name: 'Telesales',
    tagline: 'Không gian làm việc chuyên biệt cho đội ngũ telesales',
    description:
      'Telesales Workspace OnePOS là bàn làm việc dành riêng cho đội ngũ telesales — tích hợp danh sách lead, click-to-call, kịch bản gọi, ghi chú, nhiệm vụ và KPI trên một màn hình duy nhất.',
    icon: 'PhoneCall',
    category: 'CRM & Sales',
    dashboardType: 'telesales',
    features: [
      { label: 'Lead List', description: 'Danh sách khách hàng cần gọi' },
      { label: 'Click-to-Call', description: 'Gọi điện chỉ với một click' },
      { label: 'Call Script', description: 'Kịch bản gọi theo chiến dịch' },
      { label: 'Call History', description: 'Lịch sử cuộc gọi đầy đủ' },
      { label: 'Notes', description: 'Ghi chú sau mỗi cuộc gọi' },
      { label: 'Tasks', description: 'Nhiệm vụ và nhắc việc' },
      { label: 'Pipeline', description: 'Quản lý phễu bán hàng' },
      { label: 'KPI', description: 'Đo lường hiệu suất telesales' },
      { label: 'Campaign', description: 'Quản lý chiến dịch gọi' },
      { label: 'Recording', description: 'Ghi âm cuộc gọi' },
    ],
    benefits: [
      { title: 'Không cần nhiều phần mềm', description: 'Agent gọi, ghi chú, quản lý khách hàng trên cùng một màn hình — không cần chuyển tab.' },
      { title: 'Gọi nhanh hơn', description: 'Click-to-call giúp agent gọi liên tục, không cần bấm số thủ công.' },
      { title: 'Kịch bản chuẩn', description: 'Mỗi chiến dịch có kịch bản riêng, agent luôn biết phải nói gì.' },
      { title: 'Đo lường KPI', description: 'Số cuộc gọi, thời gian gọi, tỷ lệ chuyển đổi — mọi chỉ số được theo dõi realtime.' },
    ],
    faqs: [
      { question: 'Telesales Workspace có cần cài đặt không?', answer: 'Không. Agent chỉ cần trình duyệt để làm việc, không cần cài đặt phần mềm phức tạp.' },
      { question: 'Có thể dùng kịch bản gọi cho từng chiến dịch không?', answer: 'Có. Mỗi chiến dịch telesales có thể có kịch bản riêng, hiển thị trực tiếp khi agent gọi.' },
      { question: 'Agent có thể gọi từ điện thoại không?', answer: 'Có. Agent có thể sử dụng Softphone trên điện thoại di động hoặc gọi qua WebRTC trên trình duyệt.' },
    ],
  },
  {
    slug: 'auto-call',
    name: 'Auto Call',
    tagline: 'Tự động thực hiện các chiến dịch gọi ra theo danh sách khách hàng',
    description:
      'Auto Call OnePOS tự động hóa chiến dịch gọi ra — hệ thống tự quay số theo danh sách khách hàng, chuyển cuộc gọi cho agent hoặc AI khi khách bắt máy, và ghi âm, báo cáo toàn bộ chiến dịch.',
    icon: 'PhoneOutgoing',
    category: 'Tổng đài & Call Center',
    dashboardType: 'autocall',
    features: [
      { label: 'Campaign', description: 'Tạo chiến dịch gọi tự động' },
      { label: 'Call Queue', description: 'Hàng đợi quay số thông minh' },
      { label: 'Retry', description: 'Tự động gọi lại khi không liên lạc' },
      { label: 'Schedule', description: 'Lên lịch gọi theo khung giờ' },
      { label: 'Recording', description: 'Ghi âm mọi cuộc gọi' },
      { label: 'Reports', description: 'Báo cáo chiến dịch chi tiết' },
      { label: 'AI / Agent', description: 'Chuyển cho AI hoặc agent' },
      { label: 'DNC List', description: 'Danh sách không gọi' },
    ],
    benefits: [
      { title: 'Tiết kiệm thời gian', description: 'Agent không cần bấm số thủ công, hệ thống tự quay số liên tục.' },
      { title: 'Tỷ lệ liên lạc cao', description: 'Tự động gọi lại khi khách không bắt máy, tối ưu tỷ lệ tiếp cận.' },
      { title: 'Lên lịch linh hoạt', description: 'Thiết lập khung giờ gọi, tránh giờ nghỉ trưa, cuối tuần.' },
      { title: 'Báo cáo tức thì', description: 'Số cuộc gọi, tỷ lệ bắt máy, tỷ lệ chuyển đổi — cập nhật realtime.' },
    ],
    faqs: [
      { question: 'Auto Call có thể kết hợp với AI không?', answer: 'Có. Khi khách bắt máy, cuộc gọi có thể được chuyển cho AI Voice Agent hoặc agent người thật tùy theo kịch bản.' },
      { question: 'Có thể lên lịch gọi theo khung giờ không?', answer: 'Có. Bạn thiết lập khung giờ gọi cho từng chiến dịch, hệ thống tự động tuân thủ.' },
      { question: 'Danh sách không gọi (DNC) hoạt động thế nào?', answer: 'Bạn có thể thêm số vào danh sách DNC, hệ thống sẽ tự động bỏ qua các số này trong mọi chiến dịch.' },
    ],
  },
  {
    slug: 'ai-voice-agent',
    name: 'AI Voice Agent',
    tagline: 'AI có thể nghe, hiểu và phản hồi khách hàng bằng giọng nói',
    description:
      'AI Voice Agent OnePOS là trợ lý giọng nói AI có thể nghe, hiểu và phản hồi khách hàng bằng giọng nói tự nhiên — xử lý cuộc gọi inbound và outbound, nhận diện ý định và chuyển cho người khi cần.',
    icon: 'Bot',
    category: 'AI',
    dashboardType: 'ai',
    features: [
      { label: 'Voice AI', description: 'AI đàm thoại bằng giọng nói tự nhiên' },
      { label: 'Inbound', description: 'Tiếp nhận cuộc gọi đến' },
      { label: 'Outbound', description: 'Thực hiện cuộc gọi đi' },
      { label: 'Script', description: 'Kịch bản đàm thoại tùy chỉnh' },
      { label: 'Intent Detection', description: 'Nhận diện ý định khách hàng' },
      { label: 'Human Handoff', description: 'Chuyển cho agent khi cần' },
      { label: 'Multi-language', description: 'Hỗ trợ đa ngôn ngữ' },
      { label: 'Recording', description: 'Ghi âm và phân tích' },
    ],
    benefits: [
      { title: 'Phục vụ 24/7', description: 'AI Voice Agent tiếp nhận cuộc gọi bất cứ lúc nào, không cần nghỉ ngơi.' },
      { title: 'Giảm tải agent', description: 'AI xử lý các câu hỏi phổ biến, agent chỉ can thiệp khi cần thiết.' },
      { title: 'Chuyển giao mượt mà', description: 'Khi AI không xử lý được, cuộc gọi được chuyển cho agent với đầy đủ context.' },
      { title: 'Tự nhiên như người', description: 'AI hiểu và phản hồi bằng giọng nói tự nhiên, không máy móc.' },
    ],
    faqs: [
      { question: 'AI Voice Agent có hiểu tiếng Việt không?', answer: 'Có. AI Voice Agent được tối ưu cho tiếng Việt, hiểu được giọng nói tự nhiên của khách hàng Việt Nam.' },
      { question: 'Khi nào AI chuyển cho agent người?', answer: 'Bạn thiết lập kịch bản — khi AI không nhận diện được ý định hoặc khách yêu cầu gặp người, cuộc gọi được chuyển cho agent.' },
      { question: 'AI Voice Agent có thể gọi ra không?', answer: 'Có. AI Voice Agent có thể thực hiện cuộc gọi outbound theo chiến dịch Auto Call.' },
    ],
  },
  {
    slug: 'ai-chatbot',
    name: 'AI Chatbot',
    tagline: 'Trợ lý AI hỗ trợ khách hàng 24/7',
    description:
      'AI Chatbot OnePOS là trợ lý AI trả lời khách hàng tự động trên website, Zalo và Facebook — hiểu câu hỏi, tra cứu cơ sở kiến thức, phân loại khách hàng tiềm năng và chuyển cho agent khi cần.',
    icon: 'MessageCircleBot',
    category: 'AI',
    dashboardType: 'generic',
    features: [
      { label: 'Website', description: 'Chat trên website' },
      { label: 'Zalo', description: 'Chat trên Zalo' },
      { label: 'Facebook', description: 'Chat trên Facebook Messenger' },
      { label: 'Knowledge Base', description: 'Tra cứu cơ sở kiến thức' },
      { label: 'Lead Qualification', description: 'Phân loại khách hàng tiềm năng' },
      { label: 'Human Handoff', description: 'Chuyển cho agent khi cần' },
      { label: 'Multi-language', description: 'Hỗ trợ đa ngôn ngữ' },
      { label: 'Analytics', description: 'Phân tích hiệu quả chatbot' },
    ],
    benefits: [
      { title: 'Trả lời tức thì', description: 'Khách hàng không cần chờ — AI trả lời ngay lập tức, 24/7.' },
      { title: 'Thu lead tự động', description: 'AI thu thập thông tin và phân loại khách hàng tiềm năng.' },
      { title: 'Giảm tải CSKH', description: 'AI xử lý câu hỏi lặp lại, agent tập trung vào trường hợp phức tạp.' },
      { title: 'Đa kênh', description: 'Một chatbot hoạt động trên website, Zalo và Facebook cùng lúc.' },
    ],
    faqs: [
      { question: 'AI Chatbot có cần lập trình không?', answer: 'Không. Bạn cấu hình kịch bản và cơ sở kiến thức qua giao diện trực quan, không cần code.' },
      { question: 'Chatbot có thể tra cứu thông tin sản phẩm không?', answer: 'Có. Bạn tải tài liệu và cơ sở kiến thức, AI sẽ tra cứu và trả lời dựa trên dữ liệu.' },
      { question: 'Khi nào chatbot chuyển cho agent?', answer: 'Bạn thiết lập điều kiện — khi khách yêu cầu, khi câu hỏi ngoài kịch bản, hoặc khi AI không tự tin.' },
    ],
  },
  {
    slug: 'ai-call-analytics',
    name: 'AI Call Analytics',
    tagline: 'Phân tích và đánh giá chất lượng cuộc gọi bằng AI',
    description:
      'AI Call Analytics OnePOS tự động chuyển đổi lời nói thành văn bản, phân tích cảm xúc, tóm tắt cuộc gọi, phát hiện từ khóa và đánh giá chất lượng cuộc gọi — giúp doanh nghiệp nâng cao chất lượng phục vụ.',
    icon: 'AudioLines',
    category: 'AI',
    dashboardType: 'ai',
    features: [
      { label: 'Transcription', description: 'Chuyển giọng nói thành văn bản' },
      { label: 'Sentiment', description: 'Phân tích cảm xúc khách hàng' },
      { label: 'Summary', description: 'Tự động tóm tắt cuộc gọi' },
      { label: 'Keyword', description: 'Phát hiện từ khóa quan trọng' },
      { label: 'Scoring', description: 'Đánh giá chất lượng cuộc gọi' },
      { label: 'QA', description: 'Kiểm tra chất lượng phục vụ' },
      { label: 'Intent', description: 'Nhận diện ý định cuộc gọi' },
      { label: 'Compliance', description: 'Kiểm tra tuân thủ kịch bản' },
    ],
    benefits: [
      { title: 'Tóm tắt tự động', description: 'Không cần nghe lại toàn bộ cuộc gọi — AI tóm tắt nội dung chính.' },
      { title: 'Đánh giá chất lượng', description: 'AI chấm điểm cuộc gọi dựa trên tiêu chí, giúp QA hiệu quả hơn.' },
      { title: 'Phát hiện cảm xúc', description: 'Biết khách hàng đang vui, khó chịu hay tức giận để can thiệp kịp thời.' },
      { title: 'Kiểm tra tuân thủ', description: 'Đảm bảo agent nói đúng kịch bản, không vi phạm quy định.' },
    ],
    faqs: [
      { question: 'AI Call Analytics có hỗ trợ tiếng Việt không?', answer: 'Có. AI được tối ưu cho tiếng Việt, chuyển đổi chính xác giọng nói tự nhiên của khách hàng Việt Nam.' },
      { question: 'Có thể tùy chỉnh tiêu chí chấm điểm không?', answer: 'Có. Bạn định nghĩa tiêu chí đánh giá theo quy trình của doanh nghiệp, AI sẽ chấm điểm theo.' },
      { question: 'AI phân tích bao nhiêu cuộc gọi?', answer: 'AI có thể phân tích hàng loạt cuộc gọi cùng lúc, không giới hạn theo gói dịch vụ.' },
    ],
  },
  {
    slug: 'sip-trunk',
    name: 'SIP Trunk & Đầu số',
    tagline: 'Hạ tầng liên lạc doanh nghiệp — đầu số tổng đài và kết nối viễn thông',
    description:
      'OnePOS cung cấp đầu số tổng đài (1900, 1800, Fixed Number, Mobile SIP), SIP Trunk kết nối hệ thống tổng đài với nhà cung cấp viễn thông, và Voice Brandname hiển thị thương hiệu khi gọi ra.',
    icon: 'Network',
    category: 'Viễn thông',
    dashboardType: 'telecom',
    features: [
      { label: '1900', description: 'Hotline chia sẻ cước với khách hàng' },
      { label: '1800', description: 'Hotline miễn phí cước cho khách' },
      { label: 'Fixed Number', description: 'Số cố định theo khu vực' },
      { label: 'Mobile SIP', description: 'Số di động qua SIP' },
      { label: 'SIP Trunk', description: 'Kết nối tổng đài với nhà mạng' },
      { label: 'Voice Brandname', description: 'Hiển thị tên thương hiệu khi gọi ra' },
      { label: 'Port Number', description: 'Chuyển mang số từ nhà mạng khác' },
      { label: 'Concurrent Calls', description: 'Nhiều cuộc gọi đồng thời' },
    ],
    benefits: [
      { title: 'Đầu số chuyên nghiệp', description: '1900, 1800 giúp doanh nghiệp thể hiện sự chuyên nghiệp và dễ nhớ.' },
      { title: 'Kết nối linh hoạt', description: 'SIP Trunk kết nối hệ thống tổng đài có sẵn với nhà cung cấp viễn thông.' },
      { title: 'Hiển thị thương hiệu', description: 'Voice Brandname hiển thị tên công ty khi gọi ra, tăng tỷ lệ bắt máy.' },
      { title: 'Chuyển mang số', description: 'Giữ nguyên số cũ khi chuyển sang OnePOS, không làm gián đoạn hoạt động.' },
    ],
    faqs: [
      { question: '1900 và 1800 khác nhau thế nào?', answer: '1900 chia sẻ cước — khách hàng trả phí theo тариф, 1800 miễn phí cước cho khách hàng, doanh nghiệp chịu toàn bộ.' },
      { question: 'Có thể giữ số cũ khi chuyển sang OnePOS không?', answer: 'Có. OnePOS hỗ trợ chuyển mang số (port number) từ nhà mạng khác, bạn giữ nguyên số cũ.' },
      { question: 'SIP Trunk có cần hạ tầng riêng không?', answer: 'Không. SIP Trunk kết nối qua Internet, bạn chỉ cần cấu hình trên tổng đài OnePOS.' },
    ],
  },
  {
    slug: 'sms-brandname',
    name: 'SMS Brandname',
    tagline: 'Gửi SMS thương hiệu đến khách hàng',
    description:
      'SMS Brandname OnePOS giúp doanh nghiệp gửi tin nhắn SMS với tên thương hiệu (Brandname) thay vì số điện thoại — tăng uy tín, tỷ lệ đọc và tỷ lệ chuyển đổi.',
    icon: 'MessageSquareText',
    category: 'Viễn thông',
    dashboardType: 'generic',
    features: [
      { label: 'Brandname', description: 'Gửi SMS với tên thương hiệu' },
      { label: 'OTP', description: 'Gửi mã xác thực OTP' },
      { label: 'Marketing', description: 'Gửi SMS marketing theo chiến dịch' },
      { label: 'CSKH', description: 'Gửi SMS chăm sóc khách hàng' },
      { label: 'Lên lịch', description: 'Lên lịch gửi tự động' },
      { label: 'Báo cáo', description: 'Báo cáo tỷ lệ gửi thành công' },
      { label: 'Template', description: 'Mẫu tin nhắn tùy chỉnh' },
      { label: 'API', description: 'Tích hợp qua API' },
    ],
    benefits: [
      { title: 'Uy tín thương hiệu', description: 'Khách hàng nhận SMS từ tên thương hiệu, không phải số lạ — tăng niềm tin.' },
      { title: 'Tỷ lệ đọc cao', description: 'SMS có tỷ lệ mở cao hơn email, phù hợp cho thông báo quan trọng.' },
      { title: 'Gửi hàng loạt', description: 'Gửi SMS cho hàng nghìn khách hàng cùng lúc, nhanh và tin cậy.' },
      { title: 'Tích hợp dễ dàng', description: 'Gửi SMS trực tiếp từ CRM hoặc qua API — tự động hóa hoàn toàn.' },
    ],
    faqs: [
      { question: 'SMS Brandname có cần đăng ký không?', answer: 'Có. Bạn cần đăng ký Brandname với nhà mạng, OnePOS sẽ hỗ trợ thủ tục đăng ký.' },
      { question: 'Có thể gửi SMS quốc tế không?', answer: 'Tùy theo gói dịch vụ. Vui lòng liên hệ để được tư vấn chi tiết.' },
      { question: 'Tốc độ gửi SMS như thế nào?', answer: 'OnePOS gửi SMS hàng loạt với tốc độ cao, báo cáo tỷ lệ gửi thành công chi tiết.' },
    ],
  },
  {
    slug: 'zalo-zns',
    name: 'Zalo ZNS',
    tagline: 'Gửi thông báo và chăm sóc khách hàng qua Zalo',
    description:
      'Zalo ZNS (Zalo Notification Service) OnePOS giúp doanh nghiệp gửi thông báo, chăm sóc khách hàng và marketing qua Zalo Official Account — theo chính sách của nền tảng Zalo.',
    icon: 'Send',
    category: 'Viễn thông',
    dashboardType: 'generic',
    features: [
      { label: 'ZNS', description: 'Gửi thông báo Zalo ZNS' },
      { label: 'OA', description: 'Quản lý Zalo Official Account' },
      { label: 'Template', description: 'Mẫu tin nhắn ZNS' },
      { label: 'Chăm sóc KH', description: 'Chăm sóc khách hàng qua Zalo' },
      { label: 'Marketing', description: 'Marketing qua Zalo' },
      { label: 'Lên lịch', description: 'Lên lịch gửi tự động' },
      { label: 'Báo cáo', description: 'Báo cáo tỷ lệ gửi và đọc' },
      { label: 'API', description: 'Tích hợp qua API' },
    ],
    benefits: [
      { title: 'Tiếp cận nhanh', description: 'Zalo là ứng dụng phổ biến tại Việt Nam, tiếp cận khách hàng nhanh và trực tiếp.' },
      { title: 'Chi phí thấp', description: 'ZNS có chi phí thấp hơn SMS, phù hợp cho chăm sóc khách hàng thường xuyên.' },
      { title: 'Tỷ lệ đọc cao', description: 'Khách hàng nhận thông báo ngay trên Zalo, tỷ lệ đọc cao hơn email.' },
      { title: 'Tự động hóa', description: 'Gửi ZNS tự động theo sự kiện: đơn hàng, lịch hẹn, nhắc sinh nhật.' },
    ],
    faqs: [
      { question: 'Zalo ZNS khác gì với tin nhắn Zalo thường?', answer: 'ZNS là dịch vụ thông báo chính thức từ Zalo, cho phép doanh nghiệp gửi tin nhắn theo mẫu được duyệt đến khách hàng.' },
      { question: 'Có cần Zalo Official Account không?', answer: 'Có. Bạn cần có Zalo OA, OnePOS sẽ hỗ trợ kết nối và quản lý.' },
      { question: 'Có thể tùy chỉnh nội dung ZNS không?', answer: 'Bạn sử dụng mẫu (template) được Zalo duyệt, điền biến số tùy chỉnh cho từng khách hàng.' },
    ],
  },
];

export function getProduct(slug: string): ProductDetail | undefined {
  return Products.find((p) => p.slug === slug);
}
